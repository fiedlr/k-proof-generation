$[ /home/xc93/csl-demo/proof-svm5/module-symbol.mm $]

$( string literal "0" $)
$c "0" "0"-symbol $.
string-literal-0-is-symbol $a #Symbol "0"-symbol $.
string-literal-0-is-pattern $a #Pattern "0" $.
string-literal-0-is-sugar $a #Notation "0" "0"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("0"))) $)
domain-value-0-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ) $.

$( string literal "true" $)
$c "true" "true"-symbol $.
string-literal-1-is-symbol $a #Symbol "true"-symbol $.
string-literal-1-is-pattern $a #Pattern "true" $.
string-literal-1-is-sugar $a #Notation "true" "true"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortBool{}, \equals{SortBool{}, x0}(x1:SortBool{}, \dv{SortBool{}}("true"))) $)
domain-value-1-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) ) $.

$( string literal "r+" $)
$c "r%2B" "r%2B"-symbol $.
string-literal-2-is-symbol $a #Symbol "r%2B"-symbol $.
string-literal-2-is-pattern $a #Pattern "r%2B" $.
string-literal-2-is-sugar $a #Notation "r%2B" "r%2B"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("r+"))) $)
domain-value-2-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "r%2B" ) ) ) ) ) $.

$( string literal "2" $)
$c "2" "2"-symbol $.
string-literal-3-is-symbol $a #Symbol "2"-symbol $.
string-literal-3-is-pattern $a #Pattern "2" $.
string-literal-3-is-sugar $a #Notation "2" "2"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("2"))) $)
domain-value-3-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "2" ) ) ) ) ) $.

$( string literal "1" $)
$c "1" "1"-symbol $.
string-literal-4-is-symbol $a #Symbol "1"-symbol $.
string-literal-4-is-pattern $a #Pattern "1" $.
string-literal-4-is-sugar $a #Notation "1" "1"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("1"))) $)
domain-value-4-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ) $.

$( string literal "false" $)
$c "false" "false"-symbol $.
string-literal-5-is-symbol $a #Symbol "false"-symbol $.
string-literal-5-is-pattern $a #Pattern "false" $.
string-literal-5-is-sugar $a #Notation "false" "false"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortBool{}, \equals{SortBool{}, x0}(x1:SortBool{}, \dv{SortBool{}}("false"))) $)
domain-value-5-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortBool kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortBool "false" ) ) ) ) ) $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("false"))) $)
domain-value-6-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "false" ) ) ) ) ) $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("true"))) $)
domain-value-7-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "true" ) ) ) ) ) $.

$( string literal "" $)
$c "" ""-symbol $.
string-literal-6-is-symbol $a #Symbol ""-symbol $.
string-literal-6-is-pattern $a #Pattern "" $.
string-literal-6-is-sugar $a #Notation "" ""-symbol $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}(""))) $)
domain-value-8-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "" ) ) ) ) ) $.

$( string literal "-1" $)
$c "-1" "-1"-symbol $.
string-literal-7-is-symbol $a #Symbol "-1"-symbol $.
string-literal-7-is-pattern $a #Pattern "-1" $.
string-literal-7-is-sugar $a #Notation "-1" "-1"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-1"))) $)
domain-value-9-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) ) $.

$( string literal "_" $)
$c "_" "_"-symbol $.
string-literal-8-is-symbol $a #Symbol "_"-symbol $.
string-literal-8-is-pattern $a #Pattern "_" $.
string-literal-8-is-sugar $a #Notation "_" "_"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortString{}, \equals{SortString{}, x0}(x1:SortString{}, \dv{SortString{}}("_"))) $)
domain-value-10-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortString kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortString "_" ) ) ) ) ) $.

$( string literal "$PGM" $)
$c "%24PGM" "%24PGM"-symbol $.
string-literal-9-is-symbol $a #Symbol "%24PGM"-symbol $.
string-literal-9-is-pattern $a #Pattern "%24PGM" $.
string-literal-9-is-sugar $a #Notation "%24PGM" "%24PGM"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortKConfigVar{}, \equals{SortKConfigVar{}, x0}(x1:SortKConfigVar{}, \dv{SortKConfigVar{}}("$PGM"))) $)
domain-value-11-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortKConfigVar kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortKConfigVar kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortKConfigVar "%24PGM" ) ) ) ) ) $.

$( string literal "x5" $)
$c "x5" "x5"-symbol $.
string-literal-10-is-symbol $a #Symbol "x5"-symbol $.
string-literal-10-is-pattern $a #Pattern "x5" $.
string-literal-10-is-sugar $a #Notation "x5" "x5"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("x5"))) $)
domain-value-12-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "x5" ) ) ) ) ) $.

$( string literal "x2" $)
$c "x2" "x2"-symbol $.
string-literal-11-is-symbol $a #Symbol "x2"-symbol $.
string-literal-11-is-pattern $a #Pattern "x2" $.
string-literal-11-is-sugar $a #Notation "x2" "x2"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("x2"))) $)
domain-value-13-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "x2" ) ) ) ) ) $.

$( string literal "w1" $)
$c "w1" "w1"-symbol $.
string-literal-12-is-symbol $a #Symbol "w1"-symbol $.
string-literal-12-is-pattern $a #Pattern "w1" $.
string-literal-12-is-sugar $a #Notation "w1" "w1"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("w1"))) $)
domain-value-14-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "w1" ) ) ) ) ) $.

$( string literal "x1" $)
$c "x1" "x1"-symbol $.
string-literal-13-is-symbol $a #Symbol "x1"-symbol $.
string-literal-13-is-pattern $a #Pattern "x1" $.
string-literal-13-is-sugar $a #Notation "x1" "x1"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("x1"))) $)
domain-value-15-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "x1" ) ) ) ) ) $.

$( string literal "x3" $)
$c "x3" "x3"-symbol $.
string-literal-14-is-symbol $a #Symbol "x3"-symbol $.
string-literal-14-is-pattern $a #Pattern "x3" $.
string-literal-14-is-sugar $a #Notation "x3" "x3"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("x3"))) $)
domain-value-16-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "x3" ) ) ) ) ) $.

$( string literal "b" $)
$c "b" "b"-symbol $.
string-literal-15-is-symbol $a #Symbol "b"-symbol $.
string-literal-15-is-pattern $a #Pattern "b" $.
string-literal-15-is-sugar $a #Notation "b" "b"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("b"))) $)
domain-value-17-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "b" ) ) ) ) ) $.

$( string literal "w2" $)
$c "w2" "w2"-symbol $.
string-literal-16-is-symbol $a #Symbol "w2"-symbol $.
string-literal-16-is-pattern $a #Pattern "w2" $.
string-literal-16-is-sugar $a #Notation "w2" "w2"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("w2"))) $)
domain-value-18-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "w2" ) ) ) ) ) $.

$( string literal "w4" $)
$c "w4" "w4"-symbol $.
string-literal-17-is-symbol $a #Symbol "w4"-symbol $.
string-literal-17-is-pattern $a #Pattern "w4" $.
string-literal-17-is-sugar $a #Notation "w4" "w4"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("w4"))) $)
domain-value-19-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "w4" ) ) ) ) ) $.

$( string literal "4" $)
$c "4" "4"-symbol $.
string-literal-18-is-symbol $a #Symbol "4"-symbol $.
string-literal-18-is-pattern $a #Pattern "4" $.
string-literal-18-is-sugar $a #Notation "4" "4"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("4"))) $)
domain-value-20-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "4" ) ) ) ) ) $.

$( string literal "5" $)
$c "5" "5"-symbol $.
string-literal-19-is-symbol $a #Symbol "5"-symbol $.
string-literal-19-is-pattern $a #Pattern "5" $.
string-literal-19-is-sugar $a #Notation "5" "5"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("5"))) $)
domain-value-21-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "5" ) ) ) ) ) $.

$( string literal "x4" $)
$c "x4" "x4"-symbol $.
string-literal-20-is-symbol $a #Symbol "x4"-symbol $.
string-literal-20-is-pattern $a #Pattern "x4" $.
string-literal-20-is-sugar $a #Notation "x4" "x4"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("x4"))) $)
domain-value-22-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "x4" ) ) ) ) ) $.

$( string literal "w3" $)
$c "w3" "w3"-symbol $.
string-literal-21-is-symbol $a #Symbol "w3"-symbol $.
string-literal-21-is-pattern $a #Pattern "w3" $.
string-literal-21-is-sugar $a #Notation "w3" "w3"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("w3"))) $)
domain-value-23-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "w3" ) ) ) ) ) $.

$( string literal "ps" $)
$c "ps" "ps"-symbol $.
string-literal-22-is-symbol $a #Symbol "ps"-symbol $.
string-literal-22-is-pattern $a #Pattern "ps" $.
string-literal-22-is-sugar $a #Notation "ps" "ps"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("ps"))) $)
domain-value-24-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "ps" ) ) ) ) ) $.

$( string literal "w5" $)
$c "w5" "w5"-symbol $.
string-literal-23-is-symbol $a #Symbol "w5"-symbol $.
string-literal-23-is-pattern $a #Pattern "w5" $.
string-literal-23-is-sugar $a #Notation "w5" "w5"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("w5"))) $)
domain-value-25-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "w5" ) ) ) ) ) $.

$( string literal "ret" $)
$c "ret" "ret"-symbol $.
string-literal-24-is-symbol $a #Symbol "ret"-symbol $.
string-literal-24-is-pattern $a #Pattern "ret" $.
string-literal-24-is-sugar $a #Notation "ret" "ret"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortId{}, \equals{SortId{}, x0}(x1:SortId{}, \dv{SortId{}}("ret"))) $)
domain-value-26-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortId kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortId "ret" ) ) ) ) ) $.

$( string literal "3" $)
$c "3" "3"-symbol $.
string-literal-25-is-symbol $a #Symbol "3"-symbol $.
string-literal-25-is-pattern $a #Pattern "3" $.
string-literal-25-is-sugar $a #Notation "3" "3"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("3"))) $)
domain-value-27-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "3" ) ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-2" $)
$c "-2" "-2"-symbol $.
string-literal-26-is-symbol $a #Symbol "-2"-symbol $.
string-literal-26-is-pattern $a #Pattern "-2" $.
string-literal-26-is-sugar $a #Notation "-2" "-2"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-2"))) $)
domain-value-28-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-2" ) ) ) ) ) $.
LblUnds-IntUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "2" ) ) ( \kore-dv \kore-sort-SortInt "-2" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-3" $)
$c "-3" "-3"-symbol $.
string-literal-27-is-symbol $a #Symbol "-3"-symbol $.
string-literal-27-is-pattern $a #Pattern "-3" $.
string-literal-27-is-sugar $a #Notation "-3" "-3"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-3"))) $)
domain-value-29-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-3" ) ) ) ) ) $.
LblUnds-IntUnds-domain-fact-2 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "3" ) ) ( \kore-dv \kore-sort-SortInt "-3" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-4" $)
$c "-4" "-4"-symbol $.
string-literal-28-is-symbol $a #Symbol "-4"-symbol $.
string-literal-28-is-pattern $a #Pattern "-4" $.
string-literal-28-is-sugar $a #Notation "-4" "-4"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-4"))) $)
domain-value-30-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-4" ) ) ) ) ) $.
LblUnds-IntUnds-domain-fact-3 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "4" ) ) ( \kore-dv \kore-sort-SortInt "-4" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-5" $)
$c "-5" "-5"-symbol $.
string-literal-29-is-symbol $a #Symbol "-5"-symbol $.
string-literal-29-is-pattern $a #Pattern "-5" $.
string-literal-29-is-sugar $a #Notation "-5" "-5"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-5"))) $)
domain-value-31-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-5" ) ) ) ) ) $.
LblUnds-IntUnds-domain-fact-4 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "5" ) ) ( \kore-dv \kore-sort-SortInt "-5" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsStarIntUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-1" ) ( \kore-dv \kore-sort-SortInt "1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsStarIntUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-2" ) ( \kore-dv \kore-sort-SortInt "2" ) ) ( \kore-dv \kore-sort-SortInt "-4" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-1" ) ( \kore-dv \kore-sort-SortInt "-4" ) ) ( \kore-dv \kore-sort-SortInt "-5" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-9" $)
$c "-9" "-9"-symbol $.
string-literal-30-is-symbol $a #Symbol "-9"-symbol $.
string-literal-30-is-pattern $a #Pattern "-9" $.
string-literal-30-is-sugar $a #Notation "-9" "-9"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-9"))) $)
domain-value-32-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-9" ) ) ) ) ) $.
LblUndsStarIntUnds-domain-fact-2 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-3" ) ( \kore-dv \kore-sort-SortInt "3" ) ) ( \kore-dv \kore-sort-SortInt "-9" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-14" $)
$c "-14" "-14"-symbol $.
string-literal-31-is-symbol $a #Symbol "-14"-symbol $.
string-literal-31-is-pattern $a #Pattern "-14" $.
string-literal-31-is-sugar $a #Notation "-14" "-14"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-14"))) $)
domain-value-33-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-14" ) ) ) ) ) $.
LblUndsPlusIntUnds-domain-fact-2 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-5" ) ( \kore-dv \kore-sort-SortInt "-9" ) ) ( \kore-dv \kore-sort-SortInt "-14" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-16" $)
$c "-16" "-16"-symbol $.
string-literal-32-is-symbol $a #Symbol "-16"-symbol $.
string-literal-32-is-pattern $a #Pattern "-16" $.
string-literal-32-is-sugar $a #Notation "-16" "-16"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-16"))) $)
domain-value-34-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-16" ) ) ) ) ) $.
LblUndsStarIntUnds-domain-fact-3 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-4" ) ( \kore-dv \kore-sort-SortInt "4" ) ) ( \kore-dv \kore-sort-SortInt "-16" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-30" $)
$c "-30" "-30"-symbol $.
string-literal-33-is-symbol $a #Symbol "-30"-symbol $.
string-literal-33-is-pattern $a #Pattern "-30" $.
string-literal-33-is-sugar $a #Notation "-30" "-30"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-30"))) $)
domain-value-35-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-30" ) ) ) ) ) $.
LblUndsPlusIntUnds-domain-fact-3 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-14" ) ( \kore-dv \kore-sort-SortInt "-16" ) ) ( \kore-dv \kore-sort-SortInt "-30" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-25" $)
$c "-25" "-25"-symbol $.
string-literal-34-is-symbol $a #Symbol "-25"-symbol $.
string-literal-34-is-pattern $a #Pattern "-25" $.
string-literal-34-is-sugar $a #Notation "-25" "-25"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-25"))) $)
domain-value-36-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-25" ) ) ) ) ) $.
LblUndsStarIntUnds-domain-fact-4 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-5" ) ( \kore-dv \kore-sort-SortInt "5" ) ) ( \kore-dv \kore-sort-SortInt "-25" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)

$( string literal "-55" $)
$c "-55" "-55"-symbol $.
string-literal-35-is-symbol $a #Symbol "-55"-symbol $.
string-literal-35-is-pattern $a #Pattern "-55" $.
string-literal-35-is-sugar $a #Notation "-55" "-55"-symbol $.

$( axiom {x0} \exists{x0}(x1:SortInt{}, \equals{SortInt{}, x0}(x1:SortInt{}, \dv{SortInt{}}("-55"))) $)
domain-value-37-functional $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-x0 ) \top ) ( \kore-valid kore-sort-var-x0 ( \kore-exists \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-equals \kore-sort-SortInt kore-sort-var-x0 kore-element-var-x1 ( \kore-dv \kore-sort-SortInt "-55" ) ) ) ) ) $.
LblUndsPlusIntUnds-domain-fact-4 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-30" ) ( \kore-dv \kore-sort-SortInt "-25" ) ) ( \kore-dv \kore-sort-SortInt "-55" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-5 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "-55" ) ( \kore-dv \kore-sort-SortInt "0" ) ) ( \kore-dv \kore-sort-SortInt "-55" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-GT-IntUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds-GT-'Int'Unds' ( \kore-dv \kore-sort-SortInt "-55" ) ( \kore-dv \kore-sort-SortInt "0" ) ) ( \kore-dv \kore-sort-SortBool "false" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-6 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblMapColnlookup-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortKItem kore-sort-var-R ( \kore-symbol-LblMap'Coln'lookup ( \kore-symbol-Lbl'Unds'Map'Unds' \kore-symbol-Lbl'Stop'Map ( \kore-symbol-Lbl'UndsPipe'-'-GT-Unds' ( \kore-inj \kore-sort-SortKConfigVar \kore-sort-SortKItem ( \kore-dv \kore-sort-SortKConfigVar "%24PGM" ) ) ( \kore-inj \kore-sort-SortPgm \kore-sort-SortKItem ( \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x1" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x2" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x3" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x4" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x5" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w1" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w2" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w3" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w4" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w5" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "b" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "ret" ) \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids ) ) ) ) ) ) ) ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x1" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "1" ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x2" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "2" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x3" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "3" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x4" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "4" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x5" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "5" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w1" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w2" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "2" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w3" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "3" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w4" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "4" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w5" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "5" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "b" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w1" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x1" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w2" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x2" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w3" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x3" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w4" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x4" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w5" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x5" ) ) ) ) ) ) ( \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block ( \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ( \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "b" ) ) ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ) ) ) ) ) ) ( \kore-inj \kore-sort-SortKConfigVar \kore-sort-SortKItem ( \kore-dv \kore-sort-SortKConfigVar "%24PGM" ) ) ) ( \kore-inj \kore-sort-SortPgm \kore-sort-SortKItem ( \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x1" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x2" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x3" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x4" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "x5" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w1" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w2" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w3" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w4" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "w5" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "b" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ( \kore-dv \kore-sort-SortId "ret" ) \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids ) ) ) ) ) ) ) ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x1" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "1" ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x2" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "2" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x3" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "3" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x4" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "4" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "x5" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "5" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w1" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w2" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "2" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w3" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "3" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w4" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "4" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "w5" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "5" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "b" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w1" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x1" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w2" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x2" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w3" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x3" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w4" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x4" ) ) ) ) ) ) ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ps" ) ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "w5" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "x5" ) ) ) ) ) ) ( \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block ( \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ( \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "ps" ) ) ( \kore-inj \kore-sort-SortId \kore-sort-SortAExp ( \kore-dv \kore-sort-SortId "b" ) ) ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "0" ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-inj \kore-sort-SortInt \kore-sort-SortAExp ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ( \kore-dv \kore-sort-SortId "ret" ) ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ( \kore-dv \kore-sort-SortInt "1" ) ) ) ) ) ) ) ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-0 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-7 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-2 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-8 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "2" ) ) ( \kore-dv \kore-sort-SortInt "-2" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-3 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-2 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-4 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-9 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "3" ) ) ( \kore-dv \kore-sort-SortInt "-3" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-5 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-3 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-6 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-10 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "4" ) ) ( \kore-dv \kore-sort-SortInt "-4" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-7 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-4 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-8 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-11 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "5" ) ) ( \kore-dv \kore-sort-SortInt "-5" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-9 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-5 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-10 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-6 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-11 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-12 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-13 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-7 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-14 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-8 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-15 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-16 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-17 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-9 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-18 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-19 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsStarIntUnds-domain-fact-5 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-1" ) ( \kore-dv \kore-sort-SortInt "1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-20 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-5 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-21 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-10 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-22 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-11 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-23 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-24 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-25 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-12 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-26 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-13 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-27 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-28 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-29 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-14 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-30 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-31 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsStarIntUnds-domain-fact-6 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-2" ) ( \kore-dv \kore-sort-SortInt "2" ) ) ( \kore-dv \kore-sort-SortInt "-4" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-32 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-6 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-1" ) ( \kore-dv \kore-sort-SortInt "-4" ) ) ( \kore-dv \kore-sort-SortInt "-5" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-33 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-15 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-34 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-16 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-35 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-36 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-37 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-17 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-38 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-18 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-39 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-40 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-41 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-19 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-42 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-43 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsStarIntUnds-domain-fact-7 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-3" ) ( \kore-dv \kore-sort-SortInt "3" ) ) ( \kore-dv \kore-sort-SortInt "-9" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-44 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-7 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-5" ) ( \kore-dv \kore-sort-SortInt "-9" ) ) ( \kore-dv \kore-sort-SortInt "-14" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-45 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-20 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-46 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-21 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-47 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-48 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-49 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-22 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-50 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-23 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-51 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-52 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-53 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-24 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-54 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-55 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsStarIntUnds-domain-fact-8 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-4" ) ( \kore-dv \kore-sort-SortInt "4" ) ) ( \kore-dv \kore-sort-SortInt "-16" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-56 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-8 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-14" ) ( \kore-dv \kore-sort-SortInt "-16" ) ) ( \kore-dv \kore-sort-SortInt "-30" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-57 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-25 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-58 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-26 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-59 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-60 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-61 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-27 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-62 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-28 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-63 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-64 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-65 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-29 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-66 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-67 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsStarIntUnds-domain-fact-9 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsStar'Int'Unds' ( \kore-dv \kore-sort-SortInt "-5" ) ( \kore-dv \kore-sort-SortInt "5" ) ) ( \kore-dv \kore-sort-SortInt "-25" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-68 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsPlusIntUnds-domain-fact-9 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ( \kore-dv \kore-sort-SortInt "-30" ) ( \kore-dv \kore-sort-SortInt "-25" ) ) ( \kore-dv \kore-sort-SortInt "-55" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-69 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-30 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-70 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-31 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-71 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-32 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-72 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-73 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-74 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-33 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-75 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-76 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-12 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "-55" ) ( \kore-dv \kore-sort-SortInt "0" ) ) ( \kore-dv \kore-sort-SortInt "-55" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-77 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-GT-IntUnds-domain-fact-1 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds-GT-'Int'Unds' ( \kore-dv \kore-sort-SortInt "-55" ) ( \kore-dv \kore-sort-SortInt "0" ) ) ( \kore-dv \kore-sort-SortBool "false" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-78 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblnotBoolUnds-domain-fact-34 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-LblnotBool'Unds' ( \kore-dv \kore-sort-SortBool "false" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-79 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUnds-IntUnds-domain-fact-13 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortInt kore-sort-var-R ( \kore-symbol-Lbl'Unds'-Int'Unds' ( \kore-dv \kore-sort-SortInt "0" ) ( \kore-dv \kore-sort-SortInt "1" ) ) ( \kore-dv \kore-sort-SortInt "-1" ) ) ) ) $.

$( NOTE: domain value reasoning checked by external tool $)
LblUndsandBoolUnds-domain-fact-80 $a |- ( \imp ( \and ( \kore-is-sort kore-sort-var-R ) \top ) ( \kore-valid kore-sort-var-R ( \kore-equals \kore-sort-SortBool kore-sort-var-R ( \kore-symbol-Lbl'Unds'andBool'Unds' ( \kore-dv \kore-sort-SortBool "true" ) ( \kore-dv \kore-sort-SortBool "true" ) ) ( \kore-dv \kore-sort-SortBool "true" ) ) ) ) $.
