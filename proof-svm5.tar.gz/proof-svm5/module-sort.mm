$[ /home/xc93/csl-demo/proof-svm5/variable.mm $]

$( sort SortK() $)
$c \kore-sort-SortK \kore-sort-SortK-symbol $.
BASIC-K-sort-0-is-symbol $a #Symbol \kore-sort-SortK-symbol $.
BASIC-K-sort-0-is-pattern $a #Pattern \kore-sort-SortK $.
BASIC-K-sort-0-is-sugar $a #Notation \kore-sort-SortK \kore-sort-SortK-symbol $.
BASIC-K-sort-0-sort $a |- ( \kore-is-sort \kore-sort-SortK ) $.

$( sort SortKItem() $)
$c \kore-sort-SortKItem \kore-sort-SortKItem-symbol $.
BASIC-K-sort-1-is-symbol $a #Symbol \kore-sort-SortKItem-symbol $.
BASIC-K-sort-1-is-pattern $a #Pattern \kore-sort-SortKItem $.
BASIC-K-sort-1-is-sugar $a #Notation \kore-sort-SortKItem \kore-sort-SortKItem-symbol $.
BASIC-K-sort-1-sort $a |- ( \kore-is-sort \kore-sort-SortKItem ) $.

$( sort SortIds() $)
$c \kore-sort-SortIds \kore-sort-SortIds-symbol $.
IMP-sort-0-is-symbol $a #Symbol \kore-sort-SortIds-symbol $.
IMP-sort-0-is-pattern $a #Pattern \kore-sort-SortIds $.
IMP-sort-0-is-sugar $a #Notation \kore-sort-SortIds \kore-sort-SortIds-symbol $.
IMP-sort-0-sort $a |- ( \kore-is-sort \kore-sort-SortIds ) $.

$( sort SortTCellFragment() $)
$c \kore-sort-SortTCellFragment \kore-sort-SortTCellFragment-symbol $.
IMP-sort-1-is-symbol $a #Symbol \kore-sort-SortTCellFragment-symbol $.
IMP-sort-1-is-pattern $a #Pattern \kore-sort-SortTCellFragment $.
IMP-sort-1-is-sugar $a #Notation \kore-sort-SortTCellFragment \kore-sort-SortTCellFragment-symbol $.
IMP-sort-1-sort $a |- ( \kore-is-sort \kore-sort-SortTCellFragment ) $.

$( sort SortKCellOpt() $)
$c \kore-sort-SortKCellOpt \kore-sort-SortKCellOpt-symbol $.
IMP-sort-2-is-symbol $a #Symbol \kore-sort-SortKCellOpt-symbol $.
IMP-sort-2-is-pattern $a #Pattern \kore-sort-SortKCellOpt $.
IMP-sort-2-is-sugar $a #Notation \kore-sort-SortKCellOpt \kore-sort-SortKCellOpt-symbol $.
IMP-sort-2-sort $a |- ( \kore-is-sort \kore-sort-SortKCellOpt ) $.

$( sort SortIOInt() $)
$c \kore-sort-SortIOInt \kore-sort-SortIOInt-symbol $.
IMP-sort-3-is-symbol $a #Symbol \kore-sort-SortIOInt-symbol $.
IMP-sort-3-is-pattern $a #Pattern \kore-sort-SortIOInt $.
IMP-sort-3-is-sugar $a #Notation \kore-sort-SortIOInt \kore-sort-SortIOInt-symbol $.
IMP-sort-3-sort $a |- ( \kore-is-sort \kore-sort-SortIOInt ) $.

$( sort SortGeneratedTopCellFragment() $)
$c \kore-sort-SortGeneratedTopCellFragment \kore-sort-SortGeneratedTopCellFragment-symbol $.
IMP-sort-4-is-symbol $a #Symbol \kore-sort-SortGeneratedTopCellFragment-symbol $.
IMP-sort-4-is-pattern $a #Pattern \kore-sort-SortGeneratedTopCellFragment $.
IMP-sort-4-is-sugar $a #Notation \kore-sort-SortGeneratedTopCellFragment \kore-sort-SortGeneratedTopCellFragment-symbol $.
IMP-sort-4-sort $a |- ( \kore-is-sort \kore-sort-SortGeneratedTopCellFragment ) $.

$( sort SortIOFile() $)
$c \kore-sort-SortIOFile \kore-sort-SortIOFile-symbol $.
IMP-sort-5-is-symbol $a #Symbol \kore-sort-SortIOFile-symbol $.
IMP-sort-5-is-pattern $a #Pattern \kore-sort-SortIOFile $.
IMP-sort-5-is-sugar $a #Notation \kore-sort-SortIOFile \kore-sort-SortIOFile-symbol $.
IMP-sort-5-sort $a |- ( \kore-is-sort \kore-sort-SortIOFile ) $.

$( sort SortList() $)
$c \kore-sort-SortList \kore-sort-SortList-symbol $.
IMP-sort-6-is-symbol $a #Symbol \kore-sort-SortList-symbol $.
IMP-sort-6-is-pattern $a #Pattern \kore-sort-SortList $.
IMP-sort-6-is-sugar $a #Notation \kore-sort-SortList \kore-sort-SortList-symbol $.
IMP-sort-6-sort $a |- ( \kore-is-sort \kore-sort-SortList ) $.

$( sort SortKCell() $)
$c \kore-sort-SortKCell \kore-sort-SortKCell-symbol $.
IMP-sort-7-is-symbol $a #Symbol \kore-sort-SortKCell-symbol $.
IMP-sort-7-is-pattern $a #Pattern \kore-sort-SortKCell $.
IMP-sort-7-is-sugar $a #Notation \kore-sort-SortKCell \kore-sort-SortKCell-symbol $.
IMP-sort-7-sort $a |- ( \kore-is-sort \kore-sort-SortKCell ) $.

$( sort SortGeneratedTopCell() $)
$c \kore-sort-SortGeneratedTopCell \kore-sort-SortGeneratedTopCell-symbol $.
IMP-sort-8-is-symbol $a #Symbol \kore-sort-SortGeneratedTopCell-symbol $.
IMP-sort-8-is-pattern $a #Pattern \kore-sort-SortGeneratedTopCell $.
IMP-sort-8-is-sugar $a #Notation \kore-sort-SortGeneratedTopCell \kore-sort-SortGeneratedTopCell-symbol $.
IMP-sort-8-sort $a |- ( \kore-is-sort \kore-sort-SortGeneratedTopCell ) $.

$( sort SortStateCell() $)
$c \kore-sort-SortStateCell \kore-sort-SortStateCell-symbol $.
IMP-sort-9-is-symbol $a #Symbol \kore-sort-SortStateCell-symbol $.
IMP-sort-9-is-pattern $a #Pattern \kore-sort-SortStateCell $.
IMP-sort-9-is-sugar $a #Notation \kore-sort-SortStateCell \kore-sort-SortStateCell-symbol $.
IMP-sort-9-sort $a |- ( \kore-is-sort \kore-sort-SortStateCell ) $.

$( sort SortGeneratedCounterCell() $)
$c \kore-sort-SortGeneratedCounterCell \kore-sort-SortGeneratedCounterCell-symbol $.
IMP-sort-10-is-symbol $a #Symbol \kore-sort-SortGeneratedCounterCell-symbol $.
IMP-sort-10-is-pattern $a #Pattern \kore-sort-SortGeneratedCounterCell $.
IMP-sort-10-is-sugar $a #Notation \kore-sort-SortGeneratedCounterCell \kore-sort-SortGeneratedCounterCell-symbol $.
IMP-sort-10-sort $a |- ( \kore-is-sort \kore-sort-SortGeneratedCounterCell ) $.

$( sort SortFloat() $)
$c \kore-sort-SortFloat \kore-sort-SortFloat-symbol $.
IMP-sort-11-is-symbol $a #Symbol \kore-sort-SortFloat-symbol $.
IMP-sort-11-is-pattern $a #Pattern \kore-sort-SortFloat $.
IMP-sort-11-is-sugar $a #Notation \kore-sort-SortFloat \kore-sort-SortFloat-symbol $.
IMP-sort-11-sort $a |- ( \kore-is-sort \kore-sort-SortFloat ) $.
IMP-sort-11-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortFloat ) ( \inh \kore-sort-SortList ) ) ) $.

$( sort SortTCellOpt() $)
$c \kore-sort-SortTCellOpt \kore-sort-SortTCellOpt-symbol $.
IMP-sort-12-is-symbol $a #Symbol \kore-sort-SortTCellOpt-symbol $.
IMP-sort-12-is-pattern $a #Pattern \kore-sort-SortTCellOpt $.
IMP-sort-12-is-sugar $a #Notation \kore-sort-SortTCellOpt \kore-sort-SortTCellOpt-symbol $.
IMP-sort-12-sort $a |- ( \kore-is-sort \kore-sort-SortTCellOpt ) $.

$( sort SortAExp() $)
$c \kore-sort-SortAExp \kore-sort-SortAExp-symbol $.
IMP-sort-13-is-symbol $a #Symbol \kore-sort-SortAExp-symbol $.
IMP-sort-13-is-pattern $a #Pattern \kore-sort-SortAExp $.
IMP-sort-13-is-sugar $a #Notation \kore-sort-SortAExp \kore-sort-SortAExp-symbol $.
IMP-sort-13-sort $a |- ( \kore-is-sort \kore-sort-SortAExp ) $.

$( sort SortMap() $)
$c \kore-sort-SortMap \kore-sort-SortMap-symbol $.
IMP-sort-14-is-symbol $a #Symbol \kore-sort-SortMap-symbol $.
IMP-sort-14-is-pattern $a #Pattern \kore-sort-SortMap $.
IMP-sort-14-is-sugar $a #Notation \kore-sort-SortMap \kore-sort-SortMap-symbol $.
IMP-sort-14-sort $a |- ( \kore-is-sort \kore-sort-SortMap ) $.
IMP-sort-14-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortMap ) ( \inh \kore-sort-SortList ) ) ) $.
IMP-sort-14-hooked-sort-disjoint-with-SortFloat $a |- ( \not ( \and ( \inh \kore-sort-SortMap ) ( \inh \kore-sort-SortFloat ) ) ) $.

$( sort SortString() $)
$c \kore-sort-SortString \kore-sort-SortString-symbol $.
IMP-sort-15-is-symbol $a #Symbol \kore-sort-SortString-symbol $.
IMP-sort-15-is-pattern $a #Pattern \kore-sort-SortString $.
IMP-sort-15-is-sugar $a #Notation \kore-sort-SortString \kore-sort-SortString-symbol $.
IMP-sort-15-sort $a |- ( \kore-is-sort \kore-sort-SortString ) $.
IMP-sort-15-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortString ) ( \inh \kore-sort-SortList ) ) ) $.
IMP-sort-15-hooked-sort-disjoint-with-SortFloat $a |- ( \not ( \and ( \inh \kore-sort-SortString ) ( \inh \kore-sort-SortFloat ) ) ) $.
IMP-sort-15-hooked-sort-disjoint-with-SortMap $a |- ( \not ( \and ( \inh \kore-sort-SortString ) ( \inh \kore-sort-SortMap ) ) ) $.

$( sort SortIOString() $)
$c \kore-sort-SortIOString \kore-sort-SortIOString-symbol $.
IMP-sort-16-is-symbol $a #Symbol \kore-sort-SortIOString-symbol $.
IMP-sort-16-is-pattern $a #Pattern \kore-sort-SortIOString $.
IMP-sort-16-is-sugar $a #Notation \kore-sort-SortIOString \kore-sort-SortIOString-symbol $.
IMP-sort-16-sort $a |- ( \kore-is-sort \kore-sort-SortIOString ) $.

$( sort SortId() $)
$c \kore-sort-SortId \kore-sort-SortId-symbol $.
IMP-sort-17-is-symbol $a #Symbol \kore-sort-SortId-symbol $.
IMP-sort-17-is-pattern $a #Pattern \kore-sort-SortId $.
IMP-sort-17-is-sugar $a #Notation \kore-sort-SortId \kore-sort-SortId-symbol $.
IMP-sort-17-sort $a |- ( \kore-is-sort \kore-sort-SortId ) $.
IMP-sort-17-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortId ) ( \inh \kore-sort-SortList ) ) ) $.
IMP-sort-17-hooked-sort-disjoint-with-SortFloat $a |- ( \not ( \and ( \inh \kore-sort-SortId ) ( \inh \kore-sort-SortFloat ) ) ) $.
IMP-sort-17-hooked-sort-disjoint-with-SortMap $a |- ( \not ( \and ( \inh \kore-sort-SortId ) ( \inh \kore-sort-SortMap ) ) ) $.
IMP-sort-17-hooked-sort-disjoint-with-SortString $a |- ( \not ( \and ( \inh \kore-sort-SortId ) ( \inh \kore-sort-SortString ) ) ) $.

$( sort SortBlock() $)
$c \kore-sort-SortBlock \kore-sort-SortBlock-symbol $.
IMP-sort-18-is-symbol $a #Symbol \kore-sort-SortBlock-symbol $.
IMP-sort-18-is-pattern $a #Pattern \kore-sort-SortBlock $.
IMP-sort-18-is-sugar $a #Notation \kore-sort-SortBlock \kore-sort-SortBlock-symbol $.
IMP-sort-18-sort $a |- ( \kore-is-sort \kore-sort-SortBlock ) $.

$( sort SortGeneratedCounterCellOpt() $)
$c \kore-sort-SortGeneratedCounterCellOpt \kore-sort-SortGeneratedCounterCellOpt-symbol $.
IMP-sort-19-is-symbol $a #Symbol \kore-sort-SortGeneratedCounterCellOpt-symbol $.
IMP-sort-19-is-pattern $a #Pattern \kore-sort-SortGeneratedCounterCellOpt $.
IMP-sort-19-is-sugar $a #Notation \kore-sort-SortGeneratedCounterCellOpt \kore-sort-SortGeneratedCounterCellOpt-symbol $.
IMP-sort-19-sort $a |- ( \kore-is-sort \kore-sort-SortGeneratedCounterCellOpt ) $.

$( sort SortKConfigVar() $)
$c \kore-sort-SortKConfigVar \kore-sort-SortKConfigVar-symbol $.
IMP-sort-20-is-symbol $a #Symbol \kore-sort-SortKConfigVar-symbol $.
IMP-sort-20-is-pattern $a #Pattern \kore-sort-SortKConfigVar $.
IMP-sort-20-is-sugar $a #Notation \kore-sort-SortKConfigVar \kore-sort-SortKConfigVar-symbol $.
IMP-sort-20-sort $a |- ( \kore-is-sort \kore-sort-SortKConfigVar ) $.
IMP-sort-20-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortKConfigVar ) ( \inh \kore-sort-SortList ) ) ) $.
IMP-sort-20-hooked-sort-disjoint-with-SortFloat $a |- ( \not ( \and ( \inh \kore-sort-SortKConfigVar ) ( \inh \kore-sort-SortFloat ) ) ) $.
IMP-sort-20-hooked-sort-disjoint-with-SortMap $a |- ( \not ( \and ( \inh \kore-sort-SortKConfigVar ) ( \inh \kore-sort-SortMap ) ) ) $.
IMP-sort-20-hooked-sort-disjoint-with-SortString $a |- ( \not ( \and ( \inh \kore-sort-SortKConfigVar ) ( \inh \kore-sort-SortString ) ) ) $.
IMP-sort-20-hooked-sort-disjoint-with-SortId $a |- ( \not ( \and ( \inh \kore-sort-SortKConfigVar ) ( \inh \kore-sort-SortId ) ) ) $.

$( sort SortArray() $)
$c \kore-sort-SortArray \kore-sort-SortArray-symbol $.
IMP-sort-21-is-symbol $a #Symbol \kore-sort-SortArray-symbol $.
IMP-sort-21-is-pattern $a #Pattern \kore-sort-SortArray $.
IMP-sort-21-is-sugar $a #Notation \kore-sort-SortArray \kore-sort-SortArray-symbol $.
IMP-sort-21-sort $a |- ( \kore-is-sort \kore-sort-SortArray ) $.

$( sort SortBExp() $)
$c \kore-sort-SortBExp \kore-sort-SortBExp-symbol $.
IMP-sort-22-is-symbol $a #Symbol \kore-sort-SortBExp-symbol $.
IMP-sort-22-is-pattern $a #Pattern \kore-sort-SortBExp $.
IMP-sort-22-is-sugar $a #Notation \kore-sort-SortBExp \kore-sort-SortBExp-symbol $.
IMP-sort-22-sort $a |- ( \kore-is-sort \kore-sort-SortBExp ) $.

$( sort SortInt() $)
$c \kore-sort-SortInt \kore-sort-SortInt-symbol $.
IMP-sort-23-is-symbol $a #Symbol \kore-sort-SortInt-symbol $.
IMP-sort-23-is-pattern $a #Pattern \kore-sort-SortInt $.
IMP-sort-23-is-sugar $a #Notation \kore-sort-SortInt \kore-sort-SortInt-symbol $.
IMP-sort-23-sort $a |- ( \kore-is-sort \kore-sort-SortInt ) $.
IMP-sort-23-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortInt ) ( \inh \kore-sort-SortList ) ) ) $.
IMP-sort-23-hooked-sort-disjoint-with-SortFloat $a |- ( \not ( \and ( \inh \kore-sort-SortInt ) ( \inh \kore-sort-SortFloat ) ) ) $.
IMP-sort-23-hooked-sort-disjoint-with-SortMap $a |- ( \not ( \and ( \inh \kore-sort-SortInt ) ( \inh \kore-sort-SortMap ) ) ) $.
IMP-sort-23-hooked-sort-disjoint-with-SortString $a |- ( \not ( \and ( \inh \kore-sort-SortInt ) ( \inh \kore-sort-SortString ) ) ) $.
IMP-sort-23-hooked-sort-disjoint-with-SortId $a |- ( \not ( \and ( \inh \kore-sort-SortInt ) ( \inh \kore-sort-SortId ) ) ) $.
IMP-sort-23-hooked-sort-disjoint-with-SortKConfigVar $a |- ( \not ( \and ( \inh \kore-sort-SortInt ) ( \inh \kore-sort-SortKConfigVar ) ) ) $.

$( sort SortStateCellOpt() $)
$c \kore-sort-SortStateCellOpt \kore-sort-SortStateCellOpt-symbol $.
IMP-sort-24-is-symbol $a #Symbol \kore-sort-SortStateCellOpt-symbol $.
IMP-sort-24-is-pattern $a #Pattern \kore-sort-SortStateCellOpt $.
IMP-sort-24-is-sugar $a #Notation \kore-sort-SortStateCellOpt \kore-sort-SortStateCellOpt-symbol $.
IMP-sort-24-sort $a |- ( \kore-is-sort \kore-sort-SortStateCellOpt ) $.

$( sort SortIOError() $)
$c \kore-sort-SortIOError \kore-sort-SortIOError-symbol $.
IMP-sort-25-is-symbol $a #Symbol \kore-sort-SortIOError-symbol $.
IMP-sort-25-is-pattern $a #Pattern \kore-sort-SortIOError $.
IMP-sort-25-is-sugar $a #Notation \kore-sort-SortIOError \kore-sort-SortIOError-symbol $.
IMP-sort-25-sort $a |- ( \kore-is-sort \kore-sort-SortIOError ) $.

$( sort SortSet() $)
$c \kore-sort-SortSet \kore-sort-SortSet-symbol $.
IMP-sort-26-is-symbol $a #Symbol \kore-sort-SortSet-symbol $.
IMP-sort-26-is-pattern $a #Pattern \kore-sort-SortSet $.
IMP-sort-26-is-sugar $a #Notation \kore-sort-SortSet \kore-sort-SortSet-symbol $.
IMP-sort-26-sort $a |- ( \kore-is-sort \kore-sort-SortSet ) $.
IMP-sort-26-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortSet ) ( \inh \kore-sort-SortList ) ) ) $.
IMP-sort-26-hooked-sort-disjoint-with-SortFloat $a |- ( \not ( \and ( \inh \kore-sort-SortSet ) ( \inh \kore-sort-SortFloat ) ) ) $.
IMP-sort-26-hooked-sort-disjoint-with-SortMap $a |- ( \not ( \and ( \inh \kore-sort-SortSet ) ( \inh \kore-sort-SortMap ) ) ) $.
IMP-sort-26-hooked-sort-disjoint-with-SortString $a |- ( \not ( \and ( \inh \kore-sort-SortSet ) ( \inh \kore-sort-SortString ) ) ) $.
IMP-sort-26-hooked-sort-disjoint-with-SortId $a |- ( \not ( \and ( \inh \kore-sort-SortSet ) ( \inh \kore-sort-SortId ) ) ) $.
IMP-sort-26-hooked-sort-disjoint-with-SortKConfigVar $a |- ( \not ( \and ( \inh \kore-sort-SortSet ) ( \inh \kore-sort-SortKConfigVar ) ) ) $.
IMP-sort-26-hooked-sort-disjoint-with-SortInt $a |- ( \not ( \and ( \inh \kore-sort-SortSet ) ( \inh \kore-sort-SortInt ) ) ) $.

$( sort SortPgm() $)
$c \kore-sort-SortPgm \kore-sort-SortPgm-symbol $.
IMP-sort-27-is-symbol $a #Symbol \kore-sort-SortPgm-symbol $.
IMP-sort-27-is-pattern $a #Pattern \kore-sort-SortPgm $.
IMP-sort-27-is-sugar $a #Notation \kore-sort-SortPgm \kore-sort-SortPgm-symbol $.
IMP-sort-27-sort $a |- ( \kore-is-sort \kore-sort-SortPgm ) $.

$( sort SortKResult() $)
$c \kore-sort-SortKResult \kore-sort-SortKResult-symbol $.
IMP-sort-28-is-symbol $a #Symbol \kore-sort-SortKResult-symbol $.
IMP-sort-28-is-pattern $a #Pattern \kore-sort-SortKResult $.
IMP-sort-28-is-sugar $a #Notation \kore-sort-SortKResult \kore-sort-SortKResult-symbol $.
IMP-sort-28-sort $a |- ( \kore-is-sort \kore-sort-SortKResult ) $.

$( sort SortStream() $)
$c \kore-sort-SortStream \kore-sort-SortStream-symbol $.
IMP-sort-29-is-symbol $a #Symbol \kore-sort-SortStream-symbol $.
IMP-sort-29-is-pattern $a #Pattern \kore-sort-SortStream $.
IMP-sort-29-is-sugar $a #Notation \kore-sort-SortStream \kore-sort-SortStream-symbol $.
IMP-sort-29-sort $a |- ( \kore-is-sort \kore-sort-SortStream ) $.

$( sort SortTCell() $)
$c \kore-sort-SortTCell \kore-sort-SortTCell-symbol $.
IMP-sort-30-is-symbol $a #Symbol \kore-sort-SortTCell-symbol $.
IMP-sort-30-is-pattern $a #Pattern \kore-sort-SortTCell $.
IMP-sort-30-is-sugar $a #Notation \kore-sort-SortTCell \kore-sort-SortTCell-symbol $.
IMP-sort-30-sort $a |- ( \kore-is-sort \kore-sort-SortTCell ) $.

$( sort SortStmt() $)
$c \kore-sort-SortStmt \kore-sort-SortStmt-symbol $.
IMP-sort-31-is-symbol $a #Symbol \kore-sort-SortStmt-symbol $.
IMP-sort-31-is-pattern $a #Pattern \kore-sort-SortStmt $.
IMP-sort-31-is-sugar $a #Notation \kore-sort-SortStmt \kore-sort-SortStmt-symbol $.
IMP-sort-31-sort $a |- ( \kore-is-sort \kore-sort-SortStmt ) $.

$( sort SortBool() $)
$c \kore-sort-SortBool \kore-sort-SortBool-symbol $.
IMP-sort-32-is-symbol $a #Symbol \kore-sort-SortBool-symbol $.
IMP-sort-32-is-pattern $a #Pattern \kore-sort-SortBool $.
IMP-sort-32-is-sugar $a #Notation \kore-sort-SortBool \kore-sort-SortBool-symbol $.
IMP-sort-32-sort $a |- ( \kore-is-sort \kore-sort-SortBool ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortList $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortList ) ) ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortFloat $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortFloat ) ) ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortMap $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortMap ) ) ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortString $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortString ) ) ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortId $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortId ) ) ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortKConfigVar $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortKConfigVar ) ) ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortInt $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortInt ) ) ) $.
IMP-sort-32-hooked-sort-disjoint-with-SortSet $a |- ( \not ( \and ( \inh \kore-sort-SortBool ) ( \inh \kore-sort-SortSet ) ) ) $.
