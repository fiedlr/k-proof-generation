$[ /home/xc93/csl-demo/proof-svm5/module-sort.mm $]

$( symbol kseq(SortKItem{}, SortK{}): SortK{} $)
$c \kore-symbol-kseq \kore-symbol-kseq-symbol $.
KSEQ-symbol-0-is-symbol $a #Symbol \kore-symbol-kseq-symbol $.
KSEQ-symbol-0-is-pattern $a #Pattern ( \kore-symbol-kseq ptn0 ptn1 ) $.
KSEQ-symbol-0-is-sugar $a #Notation ( \kore-symbol-kseq ptn0 ptn1 ) ( \app ( \app \kore-symbol-kseq-symbol ptn0 ) ptn1 ) $.
KSEQ-symbol-0-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortKItem ) ( \in-sort ptn1 \kore-sort-SortK ) ) ( \in-sort ( \kore-symbol-kseq ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol dotk(): SortK{} $)
$c \kore-symbol-dotk \kore-symbol-dotk-symbol $.
KSEQ-symbol-1-is-symbol $a #Symbol \kore-symbol-dotk-symbol $.
KSEQ-symbol-1-is-pattern $a #Pattern \kore-symbol-dotk $.
KSEQ-symbol-1-is-sugar $a #Notation \kore-symbol-dotk \kore-symbol-dotk-symbol $.
KSEQ-symbol-1-sorting $a |- ( \in-sort \kore-symbol-dotk \kore-sort-SortK ) $.

$( symbol append(SortK{}, SortK{}): SortK{} $)
$c \kore-symbol-append \kore-symbol-append-symbol $.
KSEQ-symbol-2-is-symbol $a #Symbol \kore-symbol-append-symbol $.
KSEQ-symbol-2-is-pattern $a #Pattern ( \kore-symbol-append ptn0 ptn1 ) $.
KSEQ-symbol-2-is-sugar $a #Notation ( \kore-symbol-append ptn0 ptn1 ) ( \app ( \app \kore-symbol-append-symbol ptn0 ) ptn1 ) $.
KSEQ-symbol-2-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ptn1 \kore-sort-SortK ) ) ( \in-sort ( \kore-symbol-append ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol inj(From): To $)
INJ-symbol-0-sorting $a |- ( \imp ( \and ( \and ( \kore-is-sort ptn0 ) ( \kore-is-sort ptn1 ) ) ( \in-sort ptn2 ptn0 ) ) ( \in-sort ( \kore-inj ptn0 ptn1 ptn2 ) ptn1 ) ) $.

$( symbol Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp(SortBExp{}): SortBExp{} $)
$c \kore-symbol-Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp \kore-symbol-Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp-symbol $.
IMP-symbol-0-is-symbol $a #Symbol \kore-symbol-Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp-symbol $.
IMP-symbol-0-is-pattern $a #Pattern ( \kore-symbol-Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp ptn0 ) $.
IMP-symbol-0-is-sugar $a #Notation ( \kore-symbol-Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp ptn0 ) ( \app \kore-symbol-Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp-symbol ptn0 ) $.
IMP-symbol-0-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortBExp ) ( \in-sort ( \kore-symbol-Lbl'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp ptn0 ) \kore-sort-SortBExp ) ) $.

$( symbol Lbl'Hash'E2BIG(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'E2BIG \kore-symbol-Lbl'Hash'E2BIG-symbol $.
IMP-symbol-1-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'E2BIG-symbol $.
IMP-symbol-1-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'E2BIG $.
IMP-symbol-1-is-sugar $a #Notation \kore-symbol-Lbl'Hash'E2BIG \kore-symbol-Lbl'Hash'E2BIG-symbol $.
IMP-symbol-1-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'E2BIG \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EACCES(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EACCES \kore-symbol-Lbl'Hash'EACCES-symbol $.
IMP-symbol-2-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EACCES-symbol $.
IMP-symbol-2-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EACCES $.
IMP-symbol-2-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EACCES \kore-symbol-Lbl'Hash'EACCES-symbol $.
IMP-symbol-2-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EACCES \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EADDRINUSE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EADDRINUSE \kore-symbol-Lbl'Hash'EADDRINUSE-symbol $.
IMP-symbol-3-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EADDRINUSE-symbol $.
IMP-symbol-3-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EADDRINUSE $.
IMP-symbol-3-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EADDRINUSE \kore-symbol-Lbl'Hash'EADDRINUSE-symbol $.
IMP-symbol-3-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EADDRINUSE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EADDRNOTAVAIL(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EADDRNOTAVAIL \kore-symbol-Lbl'Hash'EADDRNOTAVAIL-symbol $.
IMP-symbol-4-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EADDRNOTAVAIL-symbol $.
IMP-symbol-4-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EADDRNOTAVAIL $.
IMP-symbol-4-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EADDRNOTAVAIL \kore-symbol-Lbl'Hash'EADDRNOTAVAIL-symbol $.
IMP-symbol-4-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EADDRNOTAVAIL \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EAFNOSUPPORT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EAFNOSUPPORT \kore-symbol-Lbl'Hash'EAFNOSUPPORT-symbol $.
IMP-symbol-5-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EAFNOSUPPORT-symbol $.
IMP-symbol-5-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EAFNOSUPPORT $.
IMP-symbol-5-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EAFNOSUPPORT \kore-symbol-Lbl'Hash'EAFNOSUPPORT-symbol $.
IMP-symbol-5-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EAFNOSUPPORT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EAGAIN(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EAGAIN \kore-symbol-Lbl'Hash'EAGAIN-symbol $.
IMP-symbol-6-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EAGAIN-symbol $.
IMP-symbol-6-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EAGAIN $.
IMP-symbol-6-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EAGAIN \kore-symbol-Lbl'Hash'EAGAIN-symbol $.
IMP-symbol-6-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EAGAIN \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EALREADY(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EALREADY \kore-symbol-Lbl'Hash'EALREADY-symbol $.
IMP-symbol-7-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EALREADY-symbol $.
IMP-symbol-7-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EALREADY $.
IMP-symbol-7-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EALREADY \kore-symbol-Lbl'Hash'EALREADY-symbol $.
IMP-symbol-7-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EALREADY \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EBADF(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EBADF \kore-symbol-Lbl'Hash'EBADF-symbol $.
IMP-symbol-8-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EBADF-symbol $.
IMP-symbol-8-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EBADF $.
IMP-symbol-8-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EBADF \kore-symbol-Lbl'Hash'EBADF-symbol $.
IMP-symbol-8-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EBADF \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EBUSY(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EBUSY \kore-symbol-Lbl'Hash'EBUSY-symbol $.
IMP-symbol-9-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EBUSY-symbol $.
IMP-symbol-9-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EBUSY $.
IMP-symbol-9-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EBUSY \kore-symbol-Lbl'Hash'EBUSY-symbol $.
IMP-symbol-9-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EBUSY \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ECHILD(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ECHILD \kore-symbol-Lbl'Hash'ECHILD-symbol $.
IMP-symbol-10-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ECHILD-symbol $.
IMP-symbol-10-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ECHILD $.
IMP-symbol-10-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ECHILD \kore-symbol-Lbl'Hash'ECHILD-symbol $.
IMP-symbol-10-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ECHILD \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ECONNABORTED(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ECONNABORTED \kore-symbol-Lbl'Hash'ECONNABORTED-symbol $.
IMP-symbol-11-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ECONNABORTED-symbol $.
IMP-symbol-11-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ECONNABORTED $.
IMP-symbol-11-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ECONNABORTED \kore-symbol-Lbl'Hash'ECONNABORTED-symbol $.
IMP-symbol-11-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ECONNABORTED \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ECONNREFUSED(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ECONNREFUSED \kore-symbol-Lbl'Hash'ECONNREFUSED-symbol $.
IMP-symbol-12-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ECONNREFUSED-symbol $.
IMP-symbol-12-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ECONNREFUSED $.
IMP-symbol-12-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ECONNREFUSED \kore-symbol-Lbl'Hash'ECONNREFUSED-symbol $.
IMP-symbol-12-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ECONNREFUSED \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ECONNRESET(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ECONNRESET \kore-symbol-Lbl'Hash'ECONNRESET-symbol $.
IMP-symbol-13-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ECONNRESET-symbol $.
IMP-symbol-13-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ECONNRESET $.
IMP-symbol-13-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ECONNRESET \kore-symbol-Lbl'Hash'ECONNRESET-symbol $.
IMP-symbol-13-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ECONNRESET \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EDEADLK(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EDEADLK \kore-symbol-Lbl'Hash'EDEADLK-symbol $.
IMP-symbol-14-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EDEADLK-symbol $.
IMP-symbol-14-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EDEADLK $.
IMP-symbol-14-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EDEADLK \kore-symbol-Lbl'Hash'EDEADLK-symbol $.
IMP-symbol-14-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EDEADLK \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EDESTADDRREQ(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EDESTADDRREQ \kore-symbol-Lbl'Hash'EDESTADDRREQ-symbol $.
IMP-symbol-15-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EDESTADDRREQ-symbol $.
IMP-symbol-15-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EDESTADDRREQ $.
IMP-symbol-15-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EDESTADDRREQ \kore-symbol-Lbl'Hash'EDESTADDRREQ-symbol $.
IMP-symbol-15-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EDESTADDRREQ \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EDOM(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EDOM \kore-symbol-Lbl'Hash'EDOM-symbol $.
IMP-symbol-16-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EDOM-symbol $.
IMP-symbol-16-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EDOM $.
IMP-symbol-16-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EDOM \kore-symbol-Lbl'Hash'EDOM-symbol $.
IMP-symbol-16-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EDOM \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EEXIST(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EEXIST \kore-symbol-Lbl'Hash'EEXIST-symbol $.
IMP-symbol-17-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EEXIST-symbol $.
IMP-symbol-17-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EEXIST $.
IMP-symbol-17-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EEXIST \kore-symbol-Lbl'Hash'EEXIST-symbol $.
IMP-symbol-17-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EEXIST \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EFAULT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EFAULT \kore-symbol-Lbl'Hash'EFAULT-symbol $.
IMP-symbol-18-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EFAULT-symbol $.
IMP-symbol-18-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EFAULT $.
IMP-symbol-18-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EFAULT \kore-symbol-Lbl'Hash'EFAULT-symbol $.
IMP-symbol-18-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EFAULT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EFBIG(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EFBIG \kore-symbol-Lbl'Hash'EFBIG-symbol $.
IMP-symbol-19-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EFBIG-symbol $.
IMP-symbol-19-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EFBIG $.
IMP-symbol-19-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EFBIG \kore-symbol-Lbl'Hash'EFBIG-symbol $.
IMP-symbol-19-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EFBIG \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EHOSTDOWN(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EHOSTDOWN \kore-symbol-Lbl'Hash'EHOSTDOWN-symbol $.
IMP-symbol-20-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EHOSTDOWN-symbol $.
IMP-symbol-20-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EHOSTDOWN $.
IMP-symbol-20-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EHOSTDOWN \kore-symbol-Lbl'Hash'EHOSTDOWN-symbol $.
IMP-symbol-20-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EHOSTDOWN \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EHOSTUNREACH(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EHOSTUNREACH \kore-symbol-Lbl'Hash'EHOSTUNREACH-symbol $.
IMP-symbol-21-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EHOSTUNREACH-symbol $.
IMP-symbol-21-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EHOSTUNREACH $.
IMP-symbol-21-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EHOSTUNREACH \kore-symbol-Lbl'Hash'EHOSTUNREACH-symbol $.
IMP-symbol-21-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EHOSTUNREACH \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EINPROGRESS(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EINPROGRESS \kore-symbol-Lbl'Hash'EINPROGRESS-symbol $.
IMP-symbol-22-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EINPROGRESS-symbol $.
IMP-symbol-22-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EINPROGRESS $.
IMP-symbol-22-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EINPROGRESS \kore-symbol-Lbl'Hash'EINPROGRESS-symbol $.
IMP-symbol-22-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EINPROGRESS \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EINTR(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EINTR \kore-symbol-Lbl'Hash'EINTR-symbol $.
IMP-symbol-23-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EINTR-symbol $.
IMP-symbol-23-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EINTR $.
IMP-symbol-23-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EINTR \kore-symbol-Lbl'Hash'EINTR-symbol $.
IMP-symbol-23-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EINTR \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EINVAL(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EINVAL \kore-symbol-Lbl'Hash'EINVAL-symbol $.
IMP-symbol-24-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EINVAL-symbol $.
IMP-symbol-24-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EINVAL $.
IMP-symbol-24-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EINVAL \kore-symbol-Lbl'Hash'EINVAL-symbol $.
IMP-symbol-24-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EINVAL \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EIO(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EIO \kore-symbol-Lbl'Hash'EIO-symbol $.
IMP-symbol-25-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EIO-symbol $.
IMP-symbol-25-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EIO $.
IMP-symbol-25-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EIO \kore-symbol-Lbl'Hash'EIO-symbol $.
IMP-symbol-25-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EIO \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EISCONN(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EISCONN \kore-symbol-Lbl'Hash'EISCONN-symbol $.
IMP-symbol-26-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EISCONN-symbol $.
IMP-symbol-26-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EISCONN $.
IMP-symbol-26-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EISCONN \kore-symbol-Lbl'Hash'EISCONN-symbol $.
IMP-symbol-26-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EISCONN \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EISDIR(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EISDIR \kore-symbol-Lbl'Hash'EISDIR-symbol $.
IMP-symbol-27-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EISDIR-symbol $.
IMP-symbol-27-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EISDIR $.
IMP-symbol-27-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EISDIR \kore-symbol-Lbl'Hash'EISDIR-symbol $.
IMP-symbol-27-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EISDIR \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ELOOP(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ELOOP \kore-symbol-Lbl'Hash'ELOOP-symbol $.
IMP-symbol-28-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ELOOP-symbol $.
IMP-symbol-28-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ELOOP $.
IMP-symbol-28-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ELOOP \kore-symbol-Lbl'Hash'ELOOP-symbol $.
IMP-symbol-28-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ELOOP \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EMFILE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EMFILE \kore-symbol-Lbl'Hash'EMFILE-symbol $.
IMP-symbol-29-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EMFILE-symbol $.
IMP-symbol-29-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EMFILE $.
IMP-symbol-29-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EMFILE \kore-symbol-Lbl'Hash'EMFILE-symbol $.
IMP-symbol-29-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EMFILE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EMLINK(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EMLINK \kore-symbol-Lbl'Hash'EMLINK-symbol $.
IMP-symbol-30-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EMLINK-symbol $.
IMP-symbol-30-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EMLINK $.
IMP-symbol-30-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EMLINK \kore-symbol-Lbl'Hash'EMLINK-symbol $.
IMP-symbol-30-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EMLINK \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EMSGSIZE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EMSGSIZE \kore-symbol-Lbl'Hash'EMSGSIZE-symbol $.
IMP-symbol-31-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EMSGSIZE-symbol $.
IMP-symbol-31-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EMSGSIZE $.
IMP-symbol-31-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EMSGSIZE \kore-symbol-Lbl'Hash'EMSGSIZE-symbol $.
IMP-symbol-31-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EMSGSIZE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENAMETOOLONG(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENAMETOOLONG \kore-symbol-Lbl'Hash'ENAMETOOLONG-symbol $.
IMP-symbol-32-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENAMETOOLONG-symbol $.
IMP-symbol-32-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENAMETOOLONG $.
IMP-symbol-32-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENAMETOOLONG \kore-symbol-Lbl'Hash'ENAMETOOLONG-symbol $.
IMP-symbol-32-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENAMETOOLONG \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENETDOWN(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENETDOWN \kore-symbol-Lbl'Hash'ENETDOWN-symbol $.
IMP-symbol-33-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENETDOWN-symbol $.
IMP-symbol-33-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENETDOWN $.
IMP-symbol-33-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENETDOWN \kore-symbol-Lbl'Hash'ENETDOWN-symbol $.
IMP-symbol-33-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENETDOWN \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENETRESET(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENETRESET \kore-symbol-Lbl'Hash'ENETRESET-symbol $.
IMP-symbol-34-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENETRESET-symbol $.
IMP-symbol-34-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENETRESET $.
IMP-symbol-34-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENETRESET \kore-symbol-Lbl'Hash'ENETRESET-symbol $.
IMP-symbol-34-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENETRESET \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENETUNREACH(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENETUNREACH \kore-symbol-Lbl'Hash'ENETUNREACH-symbol $.
IMP-symbol-35-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENETUNREACH-symbol $.
IMP-symbol-35-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENETUNREACH $.
IMP-symbol-35-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENETUNREACH \kore-symbol-Lbl'Hash'ENETUNREACH-symbol $.
IMP-symbol-35-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENETUNREACH \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENFILE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENFILE \kore-symbol-Lbl'Hash'ENFILE-symbol $.
IMP-symbol-36-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENFILE-symbol $.
IMP-symbol-36-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENFILE $.
IMP-symbol-36-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENFILE \kore-symbol-Lbl'Hash'ENFILE-symbol $.
IMP-symbol-36-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENFILE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOBUFS(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOBUFS \kore-symbol-Lbl'Hash'ENOBUFS-symbol $.
IMP-symbol-37-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOBUFS-symbol $.
IMP-symbol-37-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOBUFS $.
IMP-symbol-37-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOBUFS \kore-symbol-Lbl'Hash'ENOBUFS-symbol $.
IMP-symbol-37-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOBUFS \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENODEV(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENODEV \kore-symbol-Lbl'Hash'ENODEV-symbol $.
IMP-symbol-38-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENODEV-symbol $.
IMP-symbol-38-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENODEV $.
IMP-symbol-38-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENODEV \kore-symbol-Lbl'Hash'ENODEV-symbol $.
IMP-symbol-38-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENODEV \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOENT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOENT \kore-symbol-Lbl'Hash'ENOENT-symbol $.
IMP-symbol-39-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOENT-symbol $.
IMP-symbol-39-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOENT $.
IMP-symbol-39-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOENT \kore-symbol-Lbl'Hash'ENOENT-symbol $.
IMP-symbol-39-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOENT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOEXEC(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOEXEC \kore-symbol-Lbl'Hash'ENOEXEC-symbol $.
IMP-symbol-40-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOEXEC-symbol $.
IMP-symbol-40-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOEXEC $.
IMP-symbol-40-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOEXEC \kore-symbol-Lbl'Hash'ENOEXEC-symbol $.
IMP-symbol-40-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOEXEC \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOLCK(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOLCK \kore-symbol-Lbl'Hash'ENOLCK-symbol $.
IMP-symbol-41-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOLCK-symbol $.
IMP-symbol-41-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOLCK $.
IMP-symbol-41-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOLCK \kore-symbol-Lbl'Hash'ENOLCK-symbol $.
IMP-symbol-41-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOLCK \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOMEM(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOMEM \kore-symbol-Lbl'Hash'ENOMEM-symbol $.
IMP-symbol-42-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOMEM-symbol $.
IMP-symbol-42-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOMEM $.
IMP-symbol-42-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOMEM \kore-symbol-Lbl'Hash'ENOMEM-symbol $.
IMP-symbol-42-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOMEM \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOPROTOOPT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOPROTOOPT \kore-symbol-Lbl'Hash'ENOPROTOOPT-symbol $.
IMP-symbol-43-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOPROTOOPT-symbol $.
IMP-symbol-43-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOPROTOOPT $.
IMP-symbol-43-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOPROTOOPT \kore-symbol-Lbl'Hash'ENOPROTOOPT-symbol $.
IMP-symbol-43-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOPROTOOPT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOSPC(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOSPC \kore-symbol-Lbl'Hash'ENOSPC-symbol $.
IMP-symbol-44-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOSPC-symbol $.
IMP-symbol-44-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOSPC $.
IMP-symbol-44-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOSPC \kore-symbol-Lbl'Hash'ENOSPC-symbol $.
IMP-symbol-44-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOSPC \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOSYS(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOSYS \kore-symbol-Lbl'Hash'ENOSYS-symbol $.
IMP-symbol-45-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOSYS-symbol $.
IMP-symbol-45-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOSYS $.
IMP-symbol-45-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOSYS \kore-symbol-Lbl'Hash'ENOSYS-symbol $.
IMP-symbol-45-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOSYS \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOTCONN(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOTCONN \kore-symbol-Lbl'Hash'ENOTCONN-symbol $.
IMP-symbol-46-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOTCONN-symbol $.
IMP-symbol-46-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOTCONN $.
IMP-symbol-46-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOTCONN \kore-symbol-Lbl'Hash'ENOTCONN-symbol $.
IMP-symbol-46-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOTCONN \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOTDIR(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOTDIR \kore-symbol-Lbl'Hash'ENOTDIR-symbol $.
IMP-symbol-47-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOTDIR-symbol $.
IMP-symbol-47-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOTDIR $.
IMP-symbol-47-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOTDIR \kore-symbol-Lbl'Hash'ENOTDIR-symbol $.
IMP-symbol-47-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOTDIR \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOTEMPTY(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOTEMPTY \kore-symbol-Lbl'Hash'ENOTEMPTY-symbol $.
IMP-symbol-48-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOTEMPTY-symbol $.
IMP-symbol-48-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOTEMPTY $.
IMP-symbol-48-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOTEMPTY \kore-symbol-Lbl'Hash'ENOTEMPTY-symbol $.
IMP-symbol-48-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOTEMPTY \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOTSOCK(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOTSOCK \kore-symbol-Lbl'Hash'ENOTSOCK-symbol $.
IMP-symbol-49-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOTSOCK-symbol $.
IMP-symbol-49-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOTSOCK $.
IMP-symbol-49-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOTSOCK \kore-symbol-Lbl'Hash'ENOTSOCK-symbol $.
IMP-symbol-49-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOTSOCK \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENOTTY(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENOTTY \kore-symbol-Lbl'Hash'ENOTTY-symbol $.
IMP-symbol-50-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENOTTY-symbol $.
IMP-symbol-50-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENOTTY $.
IMP-symbol-50-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENOTTY \kore-symbol-Lbl'Hash'ENOTTY-symbol $.
IMP-symbol-50-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENOTTY \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ENXIO(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ENXIO \kore-symbol-Lbl'Hash'ENXIO-symbol $.
IMP-symbol-51-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ENXIO-symbol $.
IMP-symbol-51-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ENXIO $.
IMP-symbol-51-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ENXIO \kore-symbol-Lbl'Hash'ENXIO-symbol $.
IMP-symbol-51-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ENXIO \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EOF(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EOF \kore-symbol-Lbl'Hash'EOF-symbol $.
IMP-symbol-52-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EOF-symbol $.
IMP-symbol-52-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EOF $.
IMP-symbol-52-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EOF \kore-symbol-Lbl'Hash'EOF-symbol $.
IMP-symbol-52-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EOF \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EOPNOTSUPP(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EOPNOTSUPP \kore-symbol-Lbl'Hash'EOPNOTSUPP-symbol $.
IMP-symbol-53-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EOPNOTSUPP-symbol $.
IMP-symbol-53-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EOPNOTSUPP $.
IMP-symbol-53-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EOPNOTSUPP \kore-symbol-Lbl'Hash'EOPNOTSUPP-symbol $.
IMP-symbol-53-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EOPNOTSUPP \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EOVERFLOW(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EOVERFLOW \kore-symbol-Lbl'Hash'EOVERFLOW-symbol $.
IMP-symbol-54-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EOVERFLOW-symbol $.
IMP-symbol-54-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EOVERFLOW $.
IMP-symbol-54-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EOVERFLOW \kore-symbol-Lbl'Hash'EOVERFLOW-symbol $.
IMP-symbol-54-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EOVERFLOW \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EPERM(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EPERM \kore-symbol-Lbl'Hash'EPERM-symbol $.
IMP-symbol-55-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EPERM-symbol $.
IMP-symbol-55-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EPERM $.
IMP-symbol-55-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EPERM \kore-symbol-Lbl'Hash'EPERM-symbol $.
IMP-symbol-55-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EPERM \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EPFNOSUPPORT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EPFNOSUPPORT \kore-symbol-Lbl'Hash'EPFNOSUPPORT-symbol $.
IMP-symbol-56-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EPFNOSUPPORT-symbol $.
IMP-symbol-56-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EPFNOSUPPORT $.
IMP-symbol-56-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EPFNOSUPPORT \kore-symbol-Lbl'Hash'EPFNOSUPPORT-symbol $.
IMP-symbol-56-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EPFNOSUPPORT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EPIPE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EPIPE \kore-symbol-Lbl'Hash'EPIPE-symbol $.
IMP-symbol-57-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EPIPE-symbol $.
IMP-symbol-57-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EPIPE $.
IMP-symbol-57-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EPIPE \kore-symbol-Lbl'Hash'EPIPE-symbol $.
IMP-symbol-57-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EPIPE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EPROTONOSUPPORT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EPROTONOSUPPORT \kore-symbol-Lbl'Hash'EPROTONOSUPPORT-symbol $.
IMP-symbol-58-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EPROTONOSUPPORT-symbol $.
IMP-symbol-58-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EPROTONOSUPPORT $.
IMP-symbol-58-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EPROTONOSUPPORT \kore-symbol-Lbl'Hash'EPROTONOSUPPORT-symbol $.
IMP-symbol-58-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EPROTONOSUPPORT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EPROTOTYPE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EPROTOTYPE \kore-symbol-Lbl'Hash'EPROTOTYPE-symbol $.
IMP-symbol-59-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EPROTOTYPE-symbol $.
IMP-symbol-59-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EPROTOTYPE $.
IMP-symbol-59-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EPROTOTYPE \kore-symbol-Lbl'Hash'EPROTOTYPE-symbol $.
IMP-symbol-59-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EPROTOTYPE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ERANGE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ERANGE \kore-symbol-Lbl'Hash'ERANGE-symbol $.
IMP-symbol-60-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ERANGE-symbol $.
IMP-symbol-60-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ERANGE $.
IMP-symbol-60-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ERANGE \kore-symbol-Lbl'Hash'ERANGE-symbol $.
IMP-symbol-60-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ERANGE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EROFS(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EROFS \kore-symbol-Lbl'Hash'EROFS-symbol $.
IMP-symbol-61-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EROFS-symbol $.
IMP-symbol-61-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EROFS $.
IMP-symbol-61-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EROFS \kore-symbol-Lbl'Hash'EROFS-symbol $.
IMP-symbol-61-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EROFS \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ESHUTDOWN(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ESHUTDOWN \kore-symbol-Lbl'Hash'ESHUTDOWN-symbol $.
IMP-symbol-62-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ESHUTDOWN-symbol $.
IMP-symbol-62-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ESHUTDOWN $.
IMP-symbol-62-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ESHUTDOWN \kore-symbol-Lbl'Hash'ESHUTDOWN-symbol $.
IMP-symbol-62-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ESHUTDOWN \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ESOCKTNOSUPPORT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ESOCKTNOSUPPORT \kore-symbol-Lbl'Hash'ESOCKTNOSUPPORT-symbol $.
IMP-symbol-63-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ESOCKTNOSUPPORT-symbol $.
IMP-symbol-63-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ESOCKTNOSUPPORT $.
IMP-symbol-63-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ESOCKTNOSUPPORT \kore-symbol-Lbl'Hash'ESOCKTNOSUPPORT-symbol $.
IMP-symbol-63-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ESOCKTNOSUPPORT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ESPIPE(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ESPIPE \kore-symbol-Lbl'Hash'ESPIPE-symbol $.
IMP-symbol-64-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ESPIPE-symbol $.
IMP-symbol-64-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ESPIPE $.
IMP-symbol-64-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ESPIPE \kore-symbol-Lbl'Hash'ESPIPE-symbol $.
IMP-symbol-64-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ESPIPE \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ESRCH(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ESRCH \kore-symbol-Lbl'Hash'ESRCH-symbol $.
IMP-symbol-65-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ESRCH-symbol $.
IMP-symbol-65-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ESRCH $.
IMP-symbol-65-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ESRCH \kore-symbol-Lbl'Hash'ESRCH-symbol $.
IMP-symbol-65-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ESRCH \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ETIMEDOUT(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ETIMEDOUT \kore-symbol-Lbl'Hash'ETIMEDOUT-symbol $.
IMP-symbol-66-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ETIMEDOUT-symbol $.
IMP-symbol-66-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ETIMEDOUT $.
IMP-symbol-66-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ETIMEDOUT \kore-symbol-Lbl'Hash'ETIMEDOUT-symbol $.
IMP-symbol-66-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ETIMEDOUT \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'ETOOMANYREFS(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'ETOOMANYREFS \kore-symbol-Lbl'Hash'ETOOMANYREFS-symbol $.
IMP-symbol-67-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'ETOOMANYREFS-symbol $.
IMP-symbol-67-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'ETOOMANYREFS $.
IMP-symbol-67-is-sugar $a #Notation \kore-symbol-Lbl'Hash'ETOOMANYREFS \kore-symbol-Lbl'Hash'ETOOMANYREFS-symbol $.
IMP-symbol-67-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'ETOOMANYREFS \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EWOULDBLOCK(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EWOULDBLOCK \kore-symbol-Lbl'Hash'EWOULDBLOCK-symbol $.
IMP-symbol-68-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EWOULDBLOCK-symbol $.
IMP-symbol-68-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EWOULDBLOCK $.
IMP-symbol-68-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EWOULDBLOCK \kore-symbol-Lbl'Hash'EWOULDBLOCK-symbol $.
IMP-symbol-68-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EWOULDBLOCK \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'EXDEV(): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'EXDEV \kore-symbol-Lbl'Hash'EXDEV-symbol $.
IMP-symbol-69-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'EXDEV-symbol $.
IMP-symbol-69-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'EXDEV $.
IMP-symbol-69-is-sugar $a #Notation \kore-symbol-Lbl'Hash'EXDEV \kore-symbol-Lbl'Hash'EXDEV-symbol $.
IMP-symbol-69-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'EXDEV \kore-sort-SortIOError ) $.

$( symbol Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int(SortInt{}): SortIOInt{} $)
$c \kore-symbol-Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int \kore-symbol-Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol $.
IMP-symbol-70-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol $.
IMP-symbol-70-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) $.
IMP-symbol-70-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) ( \app \kore-symbol-Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol ptn0 ) $.
IMP-symbol-70-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'Hash'accept'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) \kore-sort-SortIOInt ) ) $.

$( symbol Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K(SortK{}): SortStream{} $)
$c \kore-symbol-Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K \kore-symbol-Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K-symbol $.
IMP-symbol-71-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K-symbol $.
IMP-symbol-71-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K ptn0 ) $.
IMP-symbol-71-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K ptn0 ) ( \app \kore-symbol-Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K-symbol ptn0 ) $.
IMP-symbol-71-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'buffer'LParUndsRParUnds'K-IO'Unds'Stream'Unds'K ptn0 ) \kore-sort-SortStream ) ) $.

$( symbol Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int(SortInt{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int \kore-symbol-Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int-symbol $.
IMP-symbol-72-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int-symbol $.
IMP-symbol-72-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int ptn0 ) $.
IMP-symbol-72-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int ptn0 ) ( \app \kore-symbol-Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int-symbol ptn0 ) $.
IMP-symbol-72-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'Hash'close'LParUndsRParUnds'K-IO'Unds'K'Unds'Int ptn0 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds'(): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds' \kore-symbol-Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds'-symbol $.
IMP-symbol-73-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds'-symbol $.
IMP-symbol-73-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds' $.
IMP-symbol-73-is-sugar $a #Notation \kore-symbol-Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds' \kore-symbol-Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds'-symbol $.
IMP-symbol-73-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'freezer'BangUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp0'Unds' \kore-sort-SortKItem ) $.

$( symbol Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-74-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-74-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-74-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-74-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-75-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-75-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-75-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-75-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds' \kore-symbol-Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds'-symbol $.
IMP-symbol-76-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds'-symbol $.
IMP-symbol-76-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds' ptn0 ) $.
IMP-symbol-76-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-76-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-77-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-77-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-77-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-77-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-78-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-78-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-78-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-78-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-79-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-79-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-79-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-79-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-80-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-80-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-80-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-80-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-81-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-81-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-81-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-81-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-82-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-82-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-82-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-82-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-83-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-83-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-83-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-83-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-84-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-84-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-84-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-84-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-85-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-85-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-85-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-85-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-86-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-86-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-86-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-86-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-87-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-87-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-87-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-87-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-88-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-88-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-88-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-88-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-89-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-89-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-89-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-89-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-90-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-90-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-90-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-90-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds'-symbol $.
IMP-symbol-91-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds'-symbol $.
IMP-symbol-91-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-91-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-91-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-92-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-92-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-92-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-92-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-93-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-93-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-93-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-93-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-94-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol $.
IMP-symbol-94-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) $.
IMP-symbol-94-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds'-symbol ptn0 ) $.
IMP-symbol-94-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp0'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'(SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-95-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol $.
IMP-symbol-95-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) $.
IMP-symbol-95-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds'-symbol ptn0 ) $.
IMP-symbol-95-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezer'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp1'Unds' ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds'(SortK{}, SortK{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds' \kore-symbol-Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds'-symbol $.
IMP-symbol-96-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds'-symbol $.
IMP-symbol-96-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds' ptn0 ptn1 ) $.
IMP-symbol-96-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-96-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ptn1 \kore-sort-SortK ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'freezerif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block0'Unds' ptn0 ptn1 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int(SortInt{}): SortIOInt{} $)
$c \kore-symbol-Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int \kore-symbol-Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol $.
IMP-symbol-97-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol $.
IMP-symbol-97-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) $.
IMP-symbol-97-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) ( \app \kore-symbol-Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol ptn0 ) $.
IMP-symbol-97-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'Hash'getc'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) \kore-sort-SortIOInt ) ) $.

$( symbol Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort(SortBool{}, SortSort, SortSort): SortSort $)
$c \kore-symbol-Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort \kore-symbol-Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort-symbol $.
IMP-symbol-98-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort-symbol $.
IMP-symbol-98-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort ptn0 ptn1 ptn2 ptn3 ) $.
IMP-symbol-98-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort ptn0 ptn1 ptn2 ptn3 ) ( \app ( \app ( \app ( \app \kore-symbol-Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort-symbol ptn0 ) ptn1 ) ptn2 ) ptn3 ) $.
IMP-symbol-98-sorting $a |- ( \imp ( \and ( \and ( \and ( \kore-is-sort ptn0 ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ptn2 ptn0 ) ) ( \in-sort ptn3 ptn0 ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'if'UndsHash'then'UndsHash'else'UndsHash'fi'Unds'K-EQUAL-SYNTAX'Unds'Sort'Unds'Bool'Unds'Sort'Unds'Sort ptn0 ptn1 ptn2 ptn3 ) ptn0 ) ) $.

$( symbol Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int \kore-symbol-Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-99-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-99-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-99-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-99-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'lock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'logToFile(SortString{}, SortString{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'logToFile \kore-symbol-Lbl'Hash'logToFile-symbol $.
IMP-symbol-100-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'logToFile-symbol $.
IMP-symbol-100-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'logToFile ptn0 ptn1 ) $.
IMP-symbol-100-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'logToFile ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'logToFile-symbol ptn0 ) ptn1 ) $.
IMP-symbol-100-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'logToFile ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String(SortString{}): SortIOFile{} $)
$c \kore-symbol-Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String \kore-symbol-Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String-symbol $.
IMP-symbol-101-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String-symbol $.
IMP-symbol-101-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String ptn0 ) $.
IMP-symbol-101-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String ptn0 ) ( \app \kore-symbol-Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String-symbol ptn0 ) $.
IMP-symbol-101-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-Lbl'Hash'mkstemp'LParUndsRParUnds'K-IO'Unds'IOFile'Unds'String ptn0 ) \kore-sort-SortIOFile ) ) $.

$( symbol Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String(SortString{}): SortIOInt{} $)
$c \kore-symbol-Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String \kore-symbol-Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String-symbol $.
IMP-symbol-102-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String-symbol $.
IMP-symbol-102-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String ptn0 ) $.
IMP-symbol-102-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String ptn0 ) ( \app \kore-symbol-Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String-symbol ptn0 ) $.
IMP-symbol-102-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-Lbl'Hash'open'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'String ptn0 ) \kore-sort-SortIOInt ) ) $.

$( symbol Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String(SortString{}, SortString{}): SortIOInt{} $)
$c \kore-symbol-Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String \kore-symbol-Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String-symbol $.
IMP-symbol-103-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String-symbol $.
IMP-symbol-103-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-103-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-103-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'open'LParUndsCommUndsRParUnds'K-IO'Unds'IOInt'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortIOInt ) ) $.

$( symbol Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int \kore-symbol-Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-104-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-104-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-104-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-104-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'putc'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortIOString{} $)
$c \kore-symbol-Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int \kore-symbol-Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int-symbol $.
IMP-symbol-105-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int-symbol $.
IMP-symbol-105-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-105-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-105-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'read'LParUndsCommUndsRParUnds'K-IO'Unds'IOString'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortIOString ) ) $.

$( symbol Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String(SortString{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String \kore-symbol-Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String-symbol $.
IMP-symbol-106-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String-symbol $.
IMP-symbol-106-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String ptn0 ) $.
IMP-symbol-106-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String ptn0 ) ( \app \kore-symbol-Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String-symbol ptn0 ) $.
IMP-symbol-106-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-Lbl'Hash'remove'LParUndsRParUnds'K-IO'Unds'K'Unds'String ptn0 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int \kore-symbol-Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-107-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-107-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-107-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-107-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'seek'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int \kore-symbol-Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-108-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-108-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-108-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-108-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'seekEnd'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int(SortInt{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int \kore-symbol-Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int-symbol $.
IMP-symbol-109-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int-symbol $.
IMP-symbol-109-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int ptn0 ) $.
IMP-symbol-109-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int ptn0 ) ( \app \kore-symbol-Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int-symbol ptn0 ) $.
IMP-symbol-109-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'Hash'shutdownWrite'LParUndsRParUnds'K-IO'Unds'K'Unds'Int ptn0 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'stderr'Unds'K-IO'Unds'Int(): SortInt{} $)
$c \kore-symbol-Lbl'Hash'stderr'Unds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'stderr'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-110-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'stderr'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-110-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'stderr'Unds'K-IO'Unds'Int $.
IMP-symbol-110-is-sugar $a #Notation \kore-symbol-Lbl'Hash'stderr'Unds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'stderr'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-110-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'stderr'Unds'K-IO'Unds'Int \kore-sort-SortInt ) $.

$( symbol Lbl'Hash'stdin'Unds'K-IO'Unds'Int(): SortInt{} $)
$c \kore-symbol-Lbl'Hash'stdin'Unds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'stdin'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-111-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'stdin'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-111-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'stdin'Unds'K-IO'Unds'Int $.
IMP-symbol-111-is-sugar $a #Notation \kore-symbol-Lbl'Hash'stdin'Unds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'stdin'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-111-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'stdin'Unds'K-IO'Unds'Int \kore-sort-SortInt ) $.

$( symbol Lbl'Hash'stdout'Unds'K-IO'Unds'Int(): SortInt{} $)
$c \kore-symbol-Lbl'Hash'stdout'Unds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'stdout'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-112-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'stdout'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-112-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'stdout'Unds'K-IO'Unds'Int $.
IMP-symbol-112-is-sugar $a #Notation \kore-symbol-Lbl'Hash'stdout'Unds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'stdout'Unds'K-IO'Unds'Int-symbol $.
IMP-symbol-112-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'stdout'Unds'K-IO'Unds'Int \kore-sort-SortInt ) $.

$( symbol Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String(SortString{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String \kore-symbol-Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String-symbol $.
IMP-symbol-113-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String-symbol $.
IMP-symbol-113-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String ptn0 ) $.
IMP-symbol-113-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String ptn0 ) ( \app \kore-symbol-Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String-symbol ptn0 ) $.
IMP-symbol-113-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-Lbl'Hash'system'LParUndsRParUnds'K-IO'Unds'KItem'Unds'String ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'systemResult(SortInt{}, SortString{}, SortString{}): SortKItem{} $)
$c \kore-symbol-Lbl'Hash'systemResult \kore-symbol-Lbl'Hash'systemResult-symbol $.
IMP-symbol-114-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'systemResult-symbol $.
IMP-symbol-114-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'systemResult ptn0 ptn1 ptn2 ) $.
IMP-symbol-114-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'systemResult ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-Lbl'Hash'systemResult-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-114-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'systemResult ptn0 ptn1 ptn2 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int(SortInt{}): SortIOInt{} $)
$c \kore-symbol-Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int \kore-symbol-Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol $.
IMP-symbol-115-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol $.
IMP-symbol-115-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) $.
IMP-symbol-115-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) ( \app \kore-symbol-Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int-symbol ptn0 ) $.
IMP-symbol-115-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'Hash'tell'LParUndsRParUnds'K-IO'Unds'IOInt'Unds'Int ptn0 ) \kore-sort-SortIOInt ) ) $.

$( symbol Lbl'Hash'tempFile(SortString{}, SortInt{}): SortIOFile{} $)
$c \kore-symbol-Lbl'Hash'tempFile \kore-symbol-Lbl'Hash'tempFile-symbol $.
IMP-symbol-116-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'tempFile-symbol $.
IMP-symbol-116-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'tempFile ptn0 ptn1 ) $.
IMP-symbol-116-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'tempFile ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'tempFile-symbol ptn0 ) ptn1 ) $.
IMP-symbol-116-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'tempFile ptn0 ptn1 ) \kore-sort-SortIOFile ) ) $.

$( symbol Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int(): SortInt{} $)
$c \kore-symbol-Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int-symbol $.
IMP-symbol-117-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int-symbol $.
IMP-symbol-117-is-pattern $a #Pattern \kore-symbol-Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int $.
IMP-symbol-117-is-sugar $a #Notation \kore-symbol-Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int \kore-symbol-Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int-symbol $.
IMP-symbol-117-sorting $a |- ( \in-sort \kore-symbol-Lbl'Hash'time'LParRParUnds'K-IO'Unds'Int \kore-sort-SortInt ) $.

$( symbol Lbl'Hash'unknownIOError(SortInt{}): SortIOError{} $)
$c \kore-symbol-Lbl'Hash'unknownIOError \kore-symbol-Lbl'Hash'unknownIOError-symbol $.
IMP-symbol-118-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'unknownIOError-symbol $.
IMP-symbol-118-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'unknownIOError ptn0 ) $.
IMP-symbol-118-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'unknownIOError ptn0 ) ( \app \kore-symbol-Lbl'Hash'unknownIOError-symbol ptn0 ) $.
IMP-symbol-118-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'Hash'unknownIOError ptn0 ) \kore-sort-SortIOError ) ) $.

$( symbol Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int \kore-symbol-Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-119-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol $.
IMP-symbol-119-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-119-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-119-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'unlock'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String(SortInt{}, SortString{}): SortK{} $)
$c \kore-symbol-Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String \kore-symbol-Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String-symbol $.
IMP-symbol-120-is-symbol $a #Symbol \kore-symbol-Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String-symbol $.
IMP-symbol-120-is-pattern $a #Pattern ( \kore-symbol-Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String ptn0 ptn1 ) $.
IMP-symbol-120-is-sugar $a #Notation ( \kore-symbol-Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-120-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Hash'write'LParUndsCommUndsRParUnds'K-IO'Unds'K'Unds'Int'Unds'String ptn0 ptn1 ) \kore-sort-SortK ) ) $.

$( symbol Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int(SortInt{}): SortAExp{} $)
$c \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int-symbol $.
IMP-symbol-121-is-symbol $a #Symbol \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int-symbol $.
IMP-symbol-121-is-pattern $a #Pattern ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ptn0 ) $.
IMP-symbol-121-is-sugar $a #Notation ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ptn0 ) ( \app \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int-symbol ptn0 ) $.
IMP-symbol-121-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'Int ptn0 ) \kore-sort-SortAExp ) ) $.

$( symbol Lbl'Stop'List(): SortList{} $)
$c \kore-symbol-Lbl'Stop'List \kore-symbol-Lbl'Stop'List-symbol $.
IMP-symbol-122-is-symbol $a #Symbol \kore-symbol-Lbl'Stop'List-symbol $.
IMP-symbol-122-is-pattern $a #Pattern \kore-symbol-Lbl'Stop'List $.
IMP-symbol-122-is-sugar $a #Notation \kore-symbol-Lbl'Stop'List \kore-symbol-Lbl'Stop'List-symbol $.
IMP-symbol-122-sorting $a |- ( \in-sort \kore-symbol-Lbl'Stop'List \kore-sort-SortList ) $.

$( symbol Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids(): SortIds{} $)
$c \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids-symbol $.
IMP-symbol-123-is-symbol $a #Symbol \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids-symbol $.
IMP-symbol-123-is-pattern $a #Pattern \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids $.
IMP-symbol-123-is-sugar $a #Notation \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids-symbol $.
IMP-symbol-123-sorting $a |- ( \in-sort \kore-symbol-Lbl'Stop'List'LBraQuotUndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids'QuotRBraUnds'Ids \kore-sort-SortIds ) $.

$( symbol Lbl'Stop'Map(): SortMap{} $)
$c \kore-symbol-Lbl'Stop'Map \kore-symbol-Lbl'Stop'Map-symbol $.
IMP-symbol-124-is-symbol $a #Symbol \kore-symbol-Lbl'Stop'Map-symbol $.
IMP-symbol-124-is-pattern $a #Pattern \kore-symbol-Lbl'Stop'Map $.
IMP-symbol-124-is-sugar $a #Notation \kore-symbol-Lbl'Stop'Map \kore-symbol-Lbl'Stop'Map-symbol $.
IMP-symbol-124-sorting $a |- ( \in-sort \kore-symbol-Lbl'Stop'Map \kore-sort-SortMap ) $.

$( symbol Lbl'Stop'Set(): SortSet{} $)
$c \kore-symbol-Lbl'Stop'Set \kore-symbol-Lbl'Stop'Set-symbol $.
IMP-symbol-125-is-symbol $a #Symbol \kore-symbol-Lbl'Stop'Set-symbol $.
IMP-symbol-125-is-pattern $a #Pattern \kore-symbol-Lbl'Stop'Set $.
IMP-symbol-125-is-sugar $a #Notation \kore-symbol-Lbl'Stop'Set \kore-symbol-Lbl'Stop'Set-symbol $.
IMP-symbol-125-sorting $a |- ( \in-sort \kore-symbol-Lbl'Stop'Set \kore-sort-SortSet ) $.

$( symbol Lbl'-LT-'T'-GT-'(SortKCell{}, SortStateCell{}): SortTCell{} $)
$c \kore-symbol-Lbl'-LT-'T'-GT-' \kore-symbol-Lbl'-LT-'T'-GT-'-symbol $.
IMP-symbol-126-is-symbol $a #Symbol \kore-symbol-Lbl'-LT-'T'-GT-'-symbol $.
IMP-symbol-126-is-pattern $a #Pattern ( \kore-symbol-Lbl'-LT-'T'-GT-' ptn0 ptn1 ) $.
IMP-symbol-126-is-sugar $a #Notation ( \kore-symbol-Lbl'-LT-'T'-GT-' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'-LT-'T'-GT-'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-126-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortKCell ) ( \in-sort ptn1 \kore-sort-SortStateCell ) ) ( \in-sort ( \kore-symbol-Lbl'-LT-'T'-GT-' ptn0 ptn1 ) \kore-sort-SortTCell ) ) $.

$( symbol Lbl'-LT-'T'-GT-'-fragment(SortKCellOpt{}, SortStateCellOpt{}): SortTCellFragment{} $)
$c \kore-symbol-Lbl'-LT-'T'-GT-'-fragment \kore-symbol-Lbl'-LT-'T'-GT-'-fragment-symbol $.
IMP-symbol-127-is-symbol $a #Symbol \kore-symbol-Lbl'-LT-'T'-GT-'-fragment-symbol $.
IMP-symbol-127-is-pattern $a #Pattern ( \kore-symbol-Lbl'-LT-'T'-GT-'-fragment ptn0 ptn1 ) $.
IMP-symbol-127-is-sugar $a #Notation ( \kore-symbol-Lbl'-LT-'T'-GT-'-fragment ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'-LT-'T'-GT-'-fragment-symbol ptn0 ) ptn1 ) $.
IMP-symbol-127-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortKCellOpt ) ( \in-sort ptn1 \kore-sort-SortStateCellOpt ) ) ( \in-sort ( \kore-symbol-Lbl'-LT-'T'-GT-'-fragment ptn0 ptn1 ) \kore-sort-SortTCellFragment ) ) $.

$( symbol Lbl'-LT-'generatedCounter'-GT-'(SortInt{}): SortGeneratedCounterCell{} $)
$c \kore-symbol-Lbl'-LT-'generatedCounter'-GT-' \kore-symbol-Lbl'-LT-'generatedCounter'-GT-'-symbol $.
IMP-symbol-128-is-symbol $a #Symbol \kore-symbol-Lbl'-LT-'generatedCounter'-GT-'-symbol $.
IMP-symbol-128-is-pattern $a #Pattern ( \kore-symbol-Lbl'-LT-'generatedCounter'-GT-' ptn0 ) $.
IMP-symbol-128-is-sugar $a #Notation ( \kore-symbol-Lbl'-LT-'generatedCounter'-GT-' ptn0 ) ( \app \kore-symbol-Lbl'-LT-'generatedCounter'-GT-'-symbol ptn0 ) $.
IMP-symbol-128-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'-LT-'generatedCounter'-GT-' ptn0 ) \kore-sort-SortGeneratedCounterCell ) ) $.

$( symbol Lbl'-LT-'generatedTop'-GT-'(SortTCell{}, SortGeneratedCounterCell{}): SortGeneratedTopCell{} $)
$c \kore-symbol-Lbl'-LT-'generatedTop'-GT-' \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-symbol $.
IMP-symbol-129-is-symbol $a #Symbol \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-symbol $.
IMP-symbol-129-is-pattern $a #Pattern ( \kore-symbol-Lbl'-LT-'generatedTop'-GT-' ptn0 ptn1 ) $.
IMP-symbol-129-is-sugar $a #Notation ( \kore-symbol-Lbl'-LT-'generatedTop'-GT-' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-129-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortTCell ) ( \in-sort ptn1 \kore-sort-SortGeneratedCounterCell ) ) ( \in-sort ( \kore-symbol-Lbl'-LT-'generatedTop'-GT-' ptn0 ptn1 ) \kore-sort-SortGeneratedTopCell ) ) $.

$( symbol Lbl'-LT-'generatedTop'-GT-'-fragment(SortTCellOpt{}, SortGeneratedCounterCellOpt{}): SortGeneratedTopCellFragment{} $)
$c \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-fragment \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-fragment-symbol $.
IMP-symbol-130-is-symbol $a #Symbol \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-fragment-symbol $.
IMP-symbol-130-is-pattern $a #Pattern ( \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-fragment ptn0 ptn1 ) $.
IMP-symbol-130-is-sugar $a #Notation ( \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-fragment ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-fragment-symbol ptn0 ) ptn1 ) $.
IMP-symbol-130-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortTCellOpt ) ( \in-sort ptn1 \kore-sort-SortGeneratedCounterCellOpt ) ) ( \in-sort ( \kore-symbol-Lbl'-LT-'generatedTop'-GT-'-fragment ptn0 ptn1 ) \kore-sort-SortGeneratedTopCellFragment ) ) $.

$( symbol Lbl'-LT-'k'-GT-'(SortK{}): SortKCell{} $)
$c \kore-symbol-Lbl'-LT-'k'-GT-' \kore-symbol-Lbl'-LT-'k'-GT-'-symbol $.
IMP-symbol-131-is-symbol $a #Symbol \kore-symbol-Lbl'-LT-'k'-GT-'-symbol $.
IMP-symbol-131-is-pattern $a #Pattern ( \kore-symbol-Lbl'-LT-'k'-GT-' ptn0 ) $.
IMP-symbol-131-is-sugar $a #Notation ( \kore-symbol-Lbl'-LT-'k'-GT-' ptn0 ) ( \app \kore-symbol-Lbl'-LT-'k'-GT-'-symbol ptn0 ) $.
IMP-symbol-131-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lbl'-LT-'k'-GT-' ptn0 ) \kore-sort-SortKCell ) ) $.

$( symbol Lbl'-LT-'state'-GT-'(SortMap{}): SortStateCell{} $)
$c \kore-symbol-Lbl'-LT-'state'-GT-' \kore-symbol-Lbl'-LT-'state'-GT-'-symbol $.
IMP-symbol-132-is-symbol $a #Symbol \kore-symbol-Lbl'-LT-'state'-GT-'-symbol $.
IMP-symbol-132-is-pattern $a #Pattern ( \kore-symbol-Lbl'-LT-'state'-GT-' ptn0 ) $.
IMP-symbol-132-is-sugar $a #Notation ( \kore-symbol-Lbl'-LT-'state'-GT-' ptn0 ) ( \app \kore-symbol-Lbl'-LT-'state'-GT-'-symbol ptn0 ) $.
IMP-symbol-132-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-Lbl'-LT-'state'-GT-' ptn0 ) \kore-sort-SortStateCell ) ) $.

$( symbol LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortString{} $)
$c \kore-symbol-LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int \kore-symbol-LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int-symbol $.
IMP-symbol-133-is-symbol $a #Symbol \kore-symbol-LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int-symbol $.
IMP-symbol-133-is-pattern $a #Pattern ( \kore-symbol-LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-133-is-sugar $a #Notation ( \kore-symbol-LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-133-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblBase2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortString ) ) $.

$( symbol LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool(SortBool{}): SortString{} $)
$c \kore-symbol-LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool \kore-symbol-LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool-symbol $.
IMP-symbol-134-is-symbol $a #Symbol \kore-symbol-LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool-symbol $.
IMP-symbol-134-is-pattern $a #Pattern ( \kore-symbol-LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool ptn0 ) $.
IMP-symbol-134-is-sugar $a #Notation ( \kore-symbol-LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool ptn0 ) ( \app \kore-symbol-LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool-symbol ptn0 ) $.
IMP-symbol-134-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ( \kore-symbol-LblBool2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Bool ptn0 ) \kore-sort-SortString ) ) $.

$( symbol LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float(SortFloat{}): SortString{} $)
$c \kore-symbol-LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float \kore-symbol-LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float-symbol $.
IMP-symbol-135-is-symbol $a #Symbol \kore-symbol-LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float-symbol $.
IMP-symbol-135-is-pattern $a #Pattern ( \kore-symbol-LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float ptn0 ) $.
IMP-symbol-135-is-sugar $a #Notation ( \kore-symbol-LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float ptn0 ) ( \app \kore-symbol-LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float-symbol ptn0 ) $.
IMP-symbol-135-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortFloat ) ( \in-sort ( \kore-symbol-LblFloat2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float ptn0 ) \kore-sort-SortString ) ) $.

$( symbol LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String(SortFloat{}, SortString{}): SortString{} $)
$c \kore-symbol-LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String \kore-symbol-LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String-symbol $.
IMP-symbol-136-is-symbol $a #Symbol \kore-symbol-LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String-symbol $.
IMP-symbol-136-is-pattern $a #Pattern ( \kore-symbol-LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String ptn0 ptn1 ) $.
IMP-symbol-136-is-sugar $a #Notation ( \kore-symbol-LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-136-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortFloat ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-LblFloat2String'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'Float'Unds'String ptn0 ptn1 ) \kore-sort-SortString ) ) $.

$( symbol LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id(SortId{}): SortString{} $)
$c \kore-symbol-LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id \kore-symbol-LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id-symbol $.
IMP-symbol-137-is-symbol $a #Symbol \kore-symbol-LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id-symbol $.
IMP-symbol-137-is-pattern $a #Pattern ( \kore-symbol-LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id ptn0 ) $.
IMP-symbol-137-is-sugar $a #Notation ( \kore-symbol-LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id ptn0 ) ( \app \kore-symbol-LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id-symbol ptn0 ) $.
IMP-symbol-137-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortId ) ( \in-sort ( \kore-symbol-LblId2String'LParUndsRParUnds'ID-COMMON'Unds'String'Unds'Id ptn0 ) \kore-sort-SortString ) ) $.

$( symbol LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int(SortInt{}): SortString{} $)
$c \kore-symbol-LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int \kore-symbol-LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int-symbol $.
IMP-symbol-138-is-symbol $a #Symbol \kore-symbol-LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int-symbol $.
IMP-symbol-138-is-pattern $a #Pattern ( \kore-symbol-LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int ptn0 ) $.
IMP-symbol-138-is-sugar $a #Notation ( \kore-symbol-LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int ptn0 ) ( \app \kore-symbol-LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int-symbol ptn0 ) $.
IMP-symbol-138-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-LblInt2String'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int ptn0 ) \kore-sort-SortString ) ) $.

$( symbol LblList'Coln'get(SortList{}, SortInt{}): SortKItem{} $)
$c \kore-symbol-LblList'Coln'get \kore-symbol-LblList'Coln'get-symbol $.
IMP-symbol-139-is-symbol $a #Symbol \kore-symbol-LblList'Coln'get-symbol $.
IMP-symbol-139-is-pattern $a #Pattern ( \kore-symbol-LblList'Coln'get ptn0 ptn1 ) $.
IMP-symbol-139-is-sugar $a #Notation ( \kore-symbol-LblList'Coln'get ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblList'Coln'get-symbol ptn0 ) ptn1 ) $.
IMP-symbol-139-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblList'Coln'get ptn0 ptn1 ) \kore-sort-SortKItem ) ) $.

$( symbol LblList'Coln'range(SortList{}, SortInt{}, SortInt{}): SortList{} $)
$c \kore-symbol-LblList'Coln'range \kore-symbol-LblList'Coln'range-symbol $.
IMP-symbol-140-is-symbol $a #Symbol \kore-symbol-LblList'Coln'range-symbol $.
IMP-symbol-140-is-pattern $a #Pattern ( \kore-symbol-LblList'Coln'range ptn0 ptn1 ptn2 ) $.
IMP-symbol-140-is-sugar $a #Notation ( \kore-symbol-LblList'Coln'range ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblList'Coln'range-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-140-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblList'Coln'range ptn0 ptn1 ptn2 ) \kore-sort-SortList ) ) $.

$( symbol LblListItem(SortKItem{}): SortList{} $)
$c \kore-symbol-LblListItem \kore-symbol-LblListItem-symbol $.
IMP-symbol-141-is-symbol $a #Symbol \kore-symbol-LblListItem-symbol $.
IMP-symbol-141-is-pattern $a #Pattern ( \kore-symbol-LblListItem ptn0 ) $.
IMP-symbol-141-is-sugar $a #Notation ( \kore-symbol-LblListItem ptn0 ) ( \app \kore-symbol-LblListItem-symbol ptn0 ) $.
IMP-symbol-141-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortKItem ) ( \in-sort ( \kore-symbol-LblListItem ptn0 ) \kore-sort-SortList ) ) $.

$( symbol LblMap'Coln'lookup(SortMap{}, SortKItem{}): SortKItem{} $)
$c \kore-symbol-LblMap'Coln'lookup \kore-symbol-LblMap'Coln'lookup-symbol $.
IMP-symbol-142-is-symbol $a #Symbol \kore-symbol-LblMap'Coln'lookup-symbol $.
IMP-symbol-142-is-pattern $a #Pattern ( \kore-symbol-LblMap'Coln'lookup ptn0 ptn1 ) $.
IMP-symbol-142-is-sugar $a #Notation ( \kore-symbol-LblMap'Coln'lookup ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblMap'Coln'lookup-symbol ptn0 ) ptn1 ) $.
IMP-symbol-142-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-LblMap'Coln'lookup ptn0 ptn1 ) \kore-sort-SortKItem ) ) $.

$( symbol LblMap'Coln'update(SortMap{}, SortKItem{}, SortKItem{}): SortMap{} $)
$c \kore-symbol-LblMap'Coln'update \kore-symbol-LblMap'Coln'update-symbol $.
IMP-symbol-143-is-symbol $a #Symbol \kore-symbol-LblMap'Coln'update-symbol $.
IMP-symbol-143-is-pattern $a #Pattern ( \kore-symbol-LblMap'Coln'update ptn0 ptn1 ptn2 ) $.
IMP-symbol-143-is-sugar $a #Notation ( \kore-symbol-LblMap'Coln'update ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblMap'Coln'update-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-143-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortKItem ) ) ( \in-sort ptn2 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-LblMap'Coln'update ptn0 ptn1 ptn2 ) \kore-sort-SortMap ) ) $.

$( symbol LblSet'Coln'difference(SortSet{}, SortSet{}): SortSet{} $)
$c \kore-symbol-LblSet'Coln'difference \kore-symbol-LblSet'Coln'difference-symbol $.
IMP-symbol-144-is-symbol $a #Symbol \kore-symbol-LblSet'Coln'difference-symbol $.
IMP-symbol-144-is-pattern $a #Pattern ( \kore-symbol-LblSet'Coln'difference ptn0 ptn1 ) $.
IMP-symbol-144-is-sugar $a #Notation ( \kore-symbol-LblSet'Coln'difference ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblSet'Coln'difference-symbol ptn0 ) ptn1 ) $.
IMP-symbol-144-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortSet ) ( \in-sort ptn1 \kore-sort-SortSet ) ) ( \in-sort ( \kore-symbol-LblSet'Coln'difference ptn0 ptn1 ) \kore-sort-SortSet ) ) $.

$( symbol LblSet'Coln'in(SortKItem{}, SortSet{}): SortBool{} $)
$c \kore-symbol-LblSet'Coln'in \kore-symbol-LblSet'Coln'in-symbol $.
IMP-symbol-145-is-symbol $a #Symbol \kore-symbol-LblSet'Coln'in-symbol $.
IMP-symbol-145-is-pattern $a #Pattern ( \kore-symbol-LblSet'Coln'in ptn0 ptn1 ) $.
IMP-symbol-145-is-sugar $a #Notation ( \kore-symbol-LblSet'Coln'in ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblSet'Coln'in-symbol ptn0 ) ptn1 ) $.
IMP-symbol-145-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortKItem ) ( \in-sort ptn1 \kore-sort-SortSet ) ) ( \in-sort ( \kore-symbol-LblSet'Coln'in ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol LblSetItem(SortKItem{}): SortSet{} $)
$c \kore-symbol-LblSetItem \kore-symbol-LblSetItem-symbol $.
IMP-symbol-146-is-symbol $a #Symbol \kore-symbol-LblSetItem-symbol $.
IMP-symbol-146-is-pattern $a #Pattern ( \kore-symbol-LblSetItem ptn0 ) $.
IMP-symbol-146-is-sugar $a #Notation ( \kore-symbol-LblSetItem ptn0 ) ( \app \kore-symbol-LblSetItem-symbol ptn0 ) $.
IMP-symbol-146-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortKItem ) ( \in-sort ( \kore-symbol-LblSetItem ptn0 ) \kore-sort-SortSet ) ) $.

$( symbol LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int(SortString{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int \kore-symbol-LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int-symbol $.
IMP-symbol-147-is-symbol $a #Symbol \kore-symbol-LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int-symbol $.
IMP-symbol-147-is-pattern $a #Pattern ( \kore-symbol-LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-147-is-sugar $a #Notation ( \kore-symbol-LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-147-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblString2Base'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'Int ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String(SortString{}): SortBool{} $)
$c \kore-symbol-LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String \kore-symbol-LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String-symbol $.
IMP-symbol-148-is-symbol $a #Symbol \kore-symbol-LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String-symbol $.
IMP-symbol-148-is-pattern $a #Pattern ( \kore-symbol-LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String ptn0 ) $.
IMP-symbol-148-is-sugar $a #Notation ( \kore-symbol-LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String ptn0 ) ( \app \kore-symbol-LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String-symbol ptn0 ) $.
IMP-symbol-148-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LblString2Bool'LParUndsRParUnds'STRING-COMMON'Unds'Bool'Unds'String ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String(SortString{}): SortFloat{} $)
$c \kore-symbol-LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String \kore-symbol-LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String-symbol $.
IMP-symbol-149-is-symbol $a #Symbol \kore-symbol-LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String-symbol $.
IMP-symbol-149-is-pattern $a #Pattern ( \kore-symbol-LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String ptn0 ) $.
IMP-symbol-149-is-sugar $a #Notation ( \kore-symbol-LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String ptn0 ) ( \app \kore-symbol-LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String-symbol ptn0 ) $.
IMP-symbol-149-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LblString2Float'LParUndsRParUnds'STRING-COMMON'Unds'Float'Unds'String ptn0 ) \kore-sort-SortFloat ) ) $.

$( symbol LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String(SortString{}): SortId{} $)
$c \kore-symbol-LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String \kore-symbol-LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String-symbol $.
IMP-symbol-150-is-symbol $a #Symbol \kore-symbol-LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String-symbol $.
IMP-symbol-150-is-pattern $a #Pattern ( \kore-symbol-LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String ptn0 ) $.
IMP-symbol-150-is-sugar $a #Notation ( \kore-symbol-LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String ptn0 ) ( \app \kore-symbol-LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String-symbol ptn0 ) $.
IMP-symbol-150-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LblString2Id'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'String ptn0 ) \kore-sort-SortId ) ) $.

$( symbol LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String(SortString{}): SortInt{} $)
$c \kore-symbol-LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String \kore-symbol-LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol $.
IMP-symbol-151-is-symbol $a #Symbol \kore-symbol-LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol $.
IMP-symbol-151-is-pattern $a #Pattern ( \kore-symbol-LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) $.
IMP-symbol-151-is-sugar $a #Notation ( \kore-symbol-LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) ( \app \kore-symbol-LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol ptn0 ) $.
IMP-symbol-151-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LblString2Int'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsPerc'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsPerc'Int'Unds' \kore-symbol-Lbl'UndsPerc'Int'Unds'-symbol $.
IMP-symbol-152-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPerc'Int'Unds'-symbol $.
IMP-symbol-152-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPerc'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-152-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPerc'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPerc'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-152-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPerc'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortAExp{} $)
$c \kore-symbol-Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-153-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-153-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-153-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-153-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPercUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortAExp ) ) $.

$( symbol Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp(SortBExp{}, SortBExp{}): SortBExp{} $)
$c \kore-symbol-Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp \kore-symbol-Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp-symbol $.
IMP-symbol-154-is-symbol $a #Symbol \kore-symbol-Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp-symbol $.
IMP-symbol-154-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp ptn0 ptn1 ) $.
IMP-symbol-154-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-154-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBExp ) ( \in-sort ptn1 \kore-sort-SortBExp ) ) ( \in-sort ( \kore-symbol-Lbl'UndsAnd-And-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'BExp'Unds'BExp ptn0 ptn1 ) \kore-sort-SortBExp ) ) $.

$( symbol Lbl'UndsAnd-'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsAnd-'Int'Unds' \kore-symbol-Lbl'UndsAnd-'Int'Unds'-symbol $.
IMP-symbol-155-is-symbol $a #Symbol \kore-symbol-Lbl'UndsAnd-'Int'Unds'-symbol $.
IMP-symbol-155-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsAnd-'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-155-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsAnd-'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsAnd-'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-155-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsAnd-'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsStar'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsStar'Int'Unds' \kore-symbol-Lbl'UndsStar'Int'Unds'-symbol $.
IMP-symbol-156-is-symbol $a #Symbol \kore-symbol-Lbl'UndsStar'Int'Unds'-symbol $.
IMP-symbol-156-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsStar'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-156-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsStar'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsStar'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-156-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsStar'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortAExp{} $)
$c \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-157-is-symbol $a #Symbol \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-157-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-157-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-157-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'UndsStarUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortAExp ) ) $.

$( symbol Lbl'UndsPlus'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsPlus'Int'Unds' \kore-symbol-Lbl'UndsPlus'Int'Unds'-symbol $.
IMP-symbol-158-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPlus'Int'Unds'-symbol $.
IMP-symbol-158-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-158-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPlus'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-158-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPlus'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String(SortString{}, SortString{}): SortString{} $)
$c \kore-symbol-Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String \kore-symbol-Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String-symbol $.
IMP-symbol-159-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String-symbol $.
IMP-symbol-159-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-159-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-159-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPlus'String'UndsUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortString ) ) $.

$( symbol Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortAExp{} $)
$c \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-160-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-160-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-160-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-160-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPlusUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortAExp ) ) $.

$( symbol Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids(SortId{}, SortIds{}): SortIds{} $)
$c \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids-symbol $.
IMP-symbol-161-is-symbol $a #Symbol \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids-symbol $.
IMP-symbol-161-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ptn0 ptn1 ) $.
IMP-symbol-161-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids-symbol ptn0 ) ptn1 ) $.
IMP-symbol-161-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortId ) ( \in-sort ptn1 \kore-sort-SortIds ) ) ( \in-sort ( \kore-symbol-Lbl'UndsCommUndsUnds'IMP-SYNTAX'Unds'Ids'Unds'Id'Unds'Ids ptn0 ptn1 ) \kore-sort-SortIds ) ) $.

$( symbol Lbl'Unds'-Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'Unds'-Int'Unds' \kore-symbol-Lbl'Unds'-Int'Unds'-symbol $.
IMP-symbol-162-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'-Int'Unds'-symbol $.
IMP-symbol-162-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'-Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-162-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'-Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'-Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-162-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'-Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map(SortMap{}, SortMap{}): SortMap{} $)
$c \kore-symbol-Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map \kore-symbol-Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map-symbol $.
IMP-symbol-163-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map-symbol $.
IMP-symbol-163-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map ptn0 ptn1 ) $.
IMP-symbol-163-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map-symbol ptn0 ) ptn1 ) $.
IMP-symbol-163-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortMap ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'-Map'UndsUnds'MAP'Unds'Map'Unds'Map'Unds'Map ptn0 ptn1 ) \kore-sort-SortMap ) ) $.

$( symbol Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortAExp{} $)
$c \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-164-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-164-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-164-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-164-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'-'UndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortAExp ) ) $.

$( symbol Lbl'UndsSlsh'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsSlsh'Int'Unds' \kore-symbol-Lbl'UndsSlsh'Int'Unds'-symbol $.
IMP-symbol-165-is-symbol $a #Symbol \kore-symbol-Lbl'UndsSlsh'Int'Unds'-symbol $.
IMP-symbol-165-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsSlsh'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-165-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsSlsh'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsSlsh'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-165-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsSlsh'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortAExp{} $)
$c \kore-symbol-Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-166-is-symbol $a #Symbol \kore-symbol-Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-166-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-166-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-166-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'UndsSlshUndsUnds'IMP-SYNTAX'Unds'AExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortAExp ) ) $.

$( symbol Lbl'Unds-LT--LT-'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'Unds-LT--LT-'Int'Unds' \kore-symbol-Lbl'Unds-LT--LT-'Int'Unds'-symbol $.
IMP-symbol-167-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT--LT-'Int'Unds'-symbol $.
IMP-symbol-167-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT--LT-'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-167-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT--LT-'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT--LT-'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-167-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT--LT-'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'Unds-LT-Eqls'Int'Unds'(SortInt{}, SortInt{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-LT-Eqls'Int'Unds' \kore-symbol-Lbl'Unds-LT-Eqls'Int'Unds'-symbol $.
IMP-symbol-168-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-Eqls'Int'Unds'-symbol $.
IMP-symbol-168-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-Eqls'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-168-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-Eqls'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-Eqls'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-168-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-Eqls'Int'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map(SortMap{}, SortMap{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map \kore-symbol-Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map-symbol $.
IMP-symbol-169-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map-symbol $.
IMP-symbol-169-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map ptn0 ptn1 ) $.
IMP-symbol-169-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map-symbol ptn0 ) ptn1 ) $.
IMP-symbol-169-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortMap ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-Eqls'Map'UndsUnds'MAP'Unds'Bool'Unds'Map'Unds'Map ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set(SortSet{}, SortSet{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set \kore-symbol-Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set-symbol $.
IMP-symbol-170-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set-symbol $.
IMP-symbol-170-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set ptn0 ptn1 ) $.
IMP-symbol-170-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set-symbol ptn0 ) ptn1 ) $.
IMP-symbol-170-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortSet ) ( \in-sort ptn1 \kore-sort-SortSet ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-Eqls'Set'UndsUnds'SET'Unds'Bool'Unds'Set'Unds'Set ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String(SortString{}, SortString{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String \kore-symbol-Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-171-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-171-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-171-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-171-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortBExp{} $)
$c \kore-symbol-Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-172-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-172-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-172-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-172-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortBExp ) ) $.

$( symbol Lbl'Unds-LT-'Int'Unds'(SortInt{}, SortInt{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-LT-'Int'Unds' \kore-symbol-Lbl'Unds-LT-'Int'Unds'-symbol $.
IMP-symbol-173-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-'Int'Unds'-symbol $.
IMP-symbol-173-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-173-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-173-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-'Int'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String(SortString{}, SortString{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String \kore-symbol-Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-174-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-174-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-174-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-174-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortBExp{} $)
$c \kore-symbol-Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-175-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-175-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-175-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-175-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-LT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortBExp ) ) $.

$( symbol Lbl'UndsEqlsSlshEqls'Bool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsSlshEqls'Bool'Unds' \kore-symbol-Lbl'UndsEqlsSlshEqls'Bool'Unds'-symbol $.
IMP-symbol-176-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsSlshEqls'Bool'Unds'-symbol $.
IMP-symbol-176-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsSlshEqls'Bool'Unds' ptn0 ptn1 ) $.
IMP-symbol-176-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsSlshEqls'Bool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsSlshEqls'Bool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-176-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsSlshEqls'Bool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsSlshEqls'Int'Unds'(SortInt{}, SortInt{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsSlshEqls'Int'Unds' \kore-symbol-Lbl'UndsEqlsSlshEqls'Int'Unds'-symbol $.
IMP-symbol-177-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsSlshEqls'Int'Unds'-symbol $.
IMP-symbol-177-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsSlshEqls'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-177-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsSlshEqls'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsSlshEqls'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-177-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsSlshEqls'Int'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsSlshEqls'K'Unds'(SortK{}, SortK{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsSlshEqls'K'Unds' \kore-symbol-Lbl'UndsEqlsSlshEqls'K'Unds'-symbol $.
IMP-symbol-178-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsSlshEqls'K'Unds'-symbol $.
IMP-symbol-178-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsSlshEqls'K'Unds' ptn0 ptn1 ) $.
IMP-symbol-178-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsSlshEqls'K'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsSlshEqls'K'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-178-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ptn1 \kore-sort-SortK ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsSlshEqls'K'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String(SortString{}, SortString{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String \kore-symbol-Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-179-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-179-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-179-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-179-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsSlshEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsEqls'Bool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsEqls'Bool'Unds' \kore-symbol-Lbl'UndsEqlsEqls'Bool'Unds'-symbol $.
IMP-symbol-180-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsEqls'Bool'Unds'-symbol $.
IMP-symbol-180-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsEqls'Bool'Unds' ptn0 ptn1 ) $.
IMP-symbol-180-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsEqls'Bool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsEqls'Bool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-180-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsEqls'Bool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsEqls'Int'Unds'(SortInt{}, SortInt{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsEqls'Int'Unds' \kore-symbol-Lbl'UndsEqlsEqls'Int'Unds'-symbol $.
IMP-symbol-181-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsEqls'Int'Unds'-symbol $.
IMP-symbol-181-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsEqls'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-181-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsEqls'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsEqls'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-181-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsEqls'Int'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsEqls'K'Unds'(SortK{}, SortK{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsEqls'K'Unds' \kore-symbol-Lbl'UndsEqlsEqls'K'Unds'-symbol $.
IMP-symbol-182-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsEqls'K'Unds'-symbol $.
IMP-symbol-182-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsEqls'K'Unds' ptn0 ptn1 ) $.
IMP-symbol-182-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsEqls'K'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsEqls'K'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-182-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ptn1 \kore-sort-SortK ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsEqls'K'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String(SortString{}, SortString{}): SortBool{} $)
$c \kore-symbol-Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String \kore-symbol-Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-183-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-183-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-183-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-183-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsEqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortBExp{} $)
$c \kore-symbol-Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-184-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-184-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-184-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-184-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsEqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortBExp ) ) $.

$( symbol Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp(SortId{}, SortAExp{}): SortStmt{} $)
$c \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp-symbol $.
IMP-symbol-185-is-symbol $a #Symbol \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp-symbol $.
IMP-symbol-185-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-185-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-185-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortId ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'UndsEqlsUndsSClnUnds'IMP-SYNTAX'Unds'Stmt'Unds'Id'Unds'AExp ptn0 ptn1 ) \kore-sort-SortStmt ) ) $.

$( symbol Lbl'Unds-GT-Eqls'Int'Unds'(SortInt{}, SortInt{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-GT-Eqls'Int'Unds' \kore-symbol-Lbl'Unds-GT-Eqls'Int'Unds'-symbol $.
IMP-symbol-186-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-GT-Eqls'Int'Unds'-symbol $.
IMP-symbol-186-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-GT-Eqls'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-186-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-GT-Eqls'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-GT-Eqls'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-186-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-GT-Eqls'Int'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String(SortString{}, SortString{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String \kore-symbol-Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-187-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-187-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-187-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-187-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-GT-Eqls'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortBExp{} $)
$c \kore-symbol-Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-188-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-188-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-188-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-188-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-GT-EqlsUndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortBExp ) ) $.

$( symbol Lbl'Unds-GT--GT-'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'Unds-GT--GT-'Int'Unds' \kore-symbol-Lbl'Unds-GT--GT-'Int'Unds'-symbol $.
IMP-symbol-189-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-GT--GT-'Int'Unds'-symbol $.
IMP-symbol-189-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-GT--GT-'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-189-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-GT--GT-'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-GT--GT-'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-189-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-GT--GT-'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'Unds-GT-'Int'Unds'(SortInt{}, SortInt{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-GT-'Int'Unds' \kore-symbol-Lbl'Unds-GT-'Int'Unds'-symbol $.
IMP-symbol-190-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-GT-'Int'Unds'-symbol $.
IMP-symbol-190-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-GT-'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-190-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-GT-'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-GT-'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-190-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-GT-'Int'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String(SortString{}, SortString{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String \kore-symbol-Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-191-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol $.
IMP-symbol-191-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-191-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-191-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-GT-'String'UndsUnds'STRING-COMMON'Unds'Bool'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp(SortAExp{}, SortAExp{}): SortBExp{} $)
$c \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-192-is-symbol $a #Symbol \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol $.
IMP-symbol-192-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) $.
IMP-symbol-192-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp-symbol ptn0 ) ptn1 ) $.
IMP-symbol-192-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortAExp ) ( \in-sort ptn1 \kore-sort-SortAExp ) ) ( \in-sort ( \kore-symbol-Lbl'Unds-GT-UndsUnds'IMP-SYNTAX'Unds'BExp'Unds'AExp'Unds'AExp ptn0 ptn1 ) \kore-sort-SortBExp ) ) $.

$( symbol Lbl'Unds'List'Unds'(SortList{}, SortList{}): SortList{} $)
$c \kore-symbol-Lbl'Unds'List'Unds' \kore-symbol-Lbl'Unds'List'Unds'-symbol $.
IMP-symbol-193-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'List'Unds'-symbol $.
IMP-symbol-193-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'List'Unds' ptn0 ptn1 ) $.
IMP-symbol-193-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'List'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'List'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-193-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortList ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'List'Unds' ptn0 ptn1 ) \kore-sort-SortList ) ) $.

$( symbol Lbl'Unds'Map'Unds'(SortMap{}, SortMap{}): SortMap{} $)
$c \kore-symbol-Lbl'Unds'Map'Unds' \kore-symbol-Lbl'Unds'Map'Unds'-symbol $.
IMP-symbol-194-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'Map'Unds'-symbol $.
IMP-symbol-194-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'Map'Unds' ptn0 ptn1 ) $.
IMP-symbol-194-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'Map'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'Map'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-194-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortMap ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'Map'Unds' ptn0 ptn1 ) \kore-sort-SortMap ) ) $.

$( symbol Lbl'Unds'Set'Unds'(SortSet{}, SortSet{}): SortSet{} $)
$c \kore-symbol-Lbl'Unds'Set'Unds' \kore-symbol-Lbl'Unds'Set'Unds'-symbol $.
IMP-symbol-195-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'Set'Unds'-symbol $.
IMP-symbol-195-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'Set'Unds' ptn0 ptn1 ) $.
IMP-symbol-195-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'Set'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'Set'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-195-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortSet ) ( \in-sort ptn1 \kore-sort-SortSet ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'Set'Unds' ptn0 ptn1 ) \kore-sort-SortSet ) ) $.

$( symbol Lbl'UndsLSqBUnds-LT-'-'UndsRSqB'(SortArray{}, SortInt{}, SortKItem{}): SortArray{} $)
$c \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqB' \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqB'-symbol $.
IMP-symbol-196-is-symbol $a #Symbol \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqB'-symbol $.
IMP-symbol-196-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqB' ptn0 ptn1 ptn2 ) $.
IMP-symbol-196-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqB' ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqB'-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-196-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortArray ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqB' ptn0 ptn1 ptn2 ) \kore-sort-SortArray ) ) $.

$( symbol Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem(SortList{}, SortInt{}, SortKItem{}): SortList{} $)
$c \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-197-is-symbol $a #Symbol \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-197-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) $.
IMP-symbol-197-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-197-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-'UndsRSqBUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) \kore-sort-SortList ) ) $.

$( symbol Lbl'UndsLSqBUnds-LT-'-undef'RSqB'(SortMap{}, SortKItem{}): SortMap{} $)
$c \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqB' \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqB'-symbol $.
IMP-symbol-198-is-symbol $a #Symbol \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqB'-symbol $.
IMP-symbol-198-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqB' ptn0 ptn1 ) $.
IMP-symbol-198-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqB' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqB'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-198-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqB' ptn0 ptn1 ) \kore-sort-SortMap ) ) $.

$( symbol Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int(SortArray{}, SortInt{}): SortArray{} $)
$c \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int-symbol $.
IMP-symbol-199-is-symbol $a #Symbol \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int-symbol $.
IMP-symbol-199-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-199-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-199-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortArray ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsLSqBUnds-LT-'-undef'RSqBUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int ptn0 ptn1 ) \kore-sort-SortArray ) ) $.

$( symbol Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int(SortArray{}, SortInt{}): SortKItem{} $)
$c \kore-symbol-Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int \kore-symbol-Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int-symbol $.
IMP-symbol-200-is-symbol $a #Symbol \kore-symbol-Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int-symbol $.
IMP-symbol-200-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-200-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-200-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortArray ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsLSqBUndsRSqBUnds'ARRAY-SYNTAX'Unds'KItem'Unds'Array'Unds'Int ptn0 ptn1 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem(SortMap{}, SortKItem{}, SortKItem{}): SortKItem{} $)
$c \kore-symbol-Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem \kore-symbol-Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem-symbol $.
IMP-symbol-201-is-symbol $a #Symbol \kore-symbol-Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem-symbol $.
IMP-symbol-201-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem ptn0 ptn1 ptn2 ) $.
IMP-symbol-201-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-201-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortKItem ) ) ( \in-sort ptn2 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-Lbl'UndsLSqBUndsRSqB'orDefault'UndsUnds'MAP'Unds'KItem'Unds'Map'Unds'KItem'Unds'KItem ptn0 ptn1 ptn2 ) \kore-sort-SortKItem ) ) $.

$( symbol Lbl'UndsXor-Perc'Int'UndsUnds'(SortInt{}, SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsXor-Perc'Int'UndsUnds' \kore-symbol-Lbl'UndsXor-Perc'Int'UndsUnds'-symbol $.
IMP-symbol-202-is-symbol $a #Symbol \kore-symbol-Lbl'UndsXor-Perc'Int'UndsUnds'-symbol $.
IMP-symbol-202-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsXor-Perc'Int'UndsUnds' ptn0 ptn1 ptn2 ) $.
IMP-symbol-202-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsXor-Perc'Int'UndsUnds' ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-Lbl'UndsXor-Perc'Int'UndsUnds'-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-202-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsXor-Perc'Int'UndsUnds' ptn0 ptn1 ptn2 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsXor-'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsXor-'Int'Unds' \kore-symbol-Lbl'UndsXor-'Int'Unds'-symbol $.
IMP-symbol-203-is-symbol $a #Symbol \kore-symbol-Lbl'UndsXor-'Int'Unds'-symbol $.
IMP-symbol-203-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsXor-'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-203-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsXor-'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsXor-'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-203-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsXor-'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt(SortStmt{}, SortStmt{}): SortStmt{} $)
$c \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt-symbol $.
IMP-symbol-204-is-symbol $a #Symbol \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt-symbol $.
IMP-symbol-204-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ptn0 ptn1 ) $.
IMP-symbol-204-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt-symbol ptn0 ) ptn1 ) $.
IMP-symbol-204-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortStmt ) ( \in-sort ptn1 \kore-sort-SortStmt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'Stmt'Unds'Stmt ptn0 ptn1 ) \kore-sort-SortStmt ) ) $.

$( symbol Lbl'Unds'andBool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'andBool'Unds' \kore-symbol-Lbl'Unds'andBool'Unds'-symbol $.
IMP-symbol-205-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'andBool'Unds'-symbol $.
IMP-symbol-205-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'andBool'Unds' ptn0 ptn1 ) $.
IMP-symbol-205-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'andBool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'andBool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-205-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'andBool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'andThenBool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'andThenBool'Unds' \kore-symbol-Lbl'Unds'andThenBool'Unds'-symbol $.
IMP-symbol-206-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'andThenBool'Unds'-symbol $.
IMP-symbol-206-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'andThenBool'Unds' ptn0 ptn1 ) $.
IMP-symbol-206-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'andThenBool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'andThenBool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-206-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'andThenBool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'divInt'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'Unds'divInt'Unds' \kore-symbol-Lbl'Unds'divInt'Unds'-symbol $.
IMP-symbol-207-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'divInt'Unds'-symbol $.
IMP-symbol-207-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'divInt'Unds' ptn0 ptn1 ) $.
IMP-symbol-207-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'divInt'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'divInt'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-207-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'divInt'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int \kore-symbol-Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int-symbol $.
IMP-symbol-208-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int-symbol $.
IMP-symbol-208-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-208-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-208-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'dividesInt'UndsUnds'INT-COMMON'Unds'Bool'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'impliesBool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'impliesBool'Unds' \kore-symbol-Lbl'Unds'impliesBool'Unds'-symbol $.
IMP-symbol-209-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'impliesBool'Unds'-symbol $.
IMP-symbol-209-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'impliesBool'Unds' ptn0 ptn1 ) $.
IMP-symbol-209-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'impliesBool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'impliesBool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-209-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'impliesBool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List(SortKItem{}, SortList{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List \kore-symbol-Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List-symbol $.
IMP-symbol-210-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List-symbol $.
IMP-symbol-210-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List ptn0 ptn1 ) $.
IMP-symbol-210-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List-symbol ptn0 ) ptn1 ) $.
IMP-symbol-210-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortKItem ) ( \in-sort ptn1 \kore-sort-SortList ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'in'UndsUnds'LIST'Unds'Bool'Unds'KItem'Unds'List ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array(SortInt{}, SortArray{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array-symbol $.
IMP-symbol-211-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array-symbol $.
IMP-symbol-211-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array ptn0 ptn1 ) $.
IMP-symbol-211-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array-symbol ptn0 ) ptn1 ) $.
IMP-symbol-211-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortArray ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'ARRAY-SYNTAX'Unds'Bool'Unds'Int'Unds'Array ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map(SortKItem{}, SortMap{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map-symbol $.
IMP-symbol-212-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map-symbol $.
IMP-symbol-212-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map ptn0 ptn1 ) $.
IMP-symbol-212-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map-symbol ptn0 ) ptn1 ) $.
IMP-symbol-212-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortKItem ) ( \in-sort ptn1 \kore-sort-SortMap ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'in'Unds'keys'LParUndsRParUnds'MAP'Unds'Bool'Unds'KItem'Unds'Map ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'modInt'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'Unds'modInt'Unds' \kore-symbol-Lbl'Unds'modInt'Unds'-symbol $.
IMP-symbol-213-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'modInt'Unds'-symbol $.
IMP-symbol-213-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'modInt'Unds' ptn0 ptn1 ) $.
IMP-symbol-213-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'modInt'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'modInt'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-213-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'modInt'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'Unds'orBool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'orBool'Unds' \kore-symbol-Lbl'Unds'orBool'Unds'-symbol $.
IMP-symbol-214-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'orBool'Unds'-symbol $.
IMP-symbol-214-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'orBool'Unds' ptn0 ptn1 ) $.
IMP-symbol-214-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'orBool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'orBool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-214-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'orBool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'orElseBool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'orElseBool'Unds' \kore-symbol-Lbl'Unds'orElseBool'Unds'-symbol $.
IMP-symbol-215-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'orElseBool'Unds'-symbol $.
IMP-symbol-215-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'orElseBool'Unds' ptn0 ptn1 ) $.
IMP-symbol-215-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'orElseBool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'orElseBool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-215-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'orElseBool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'xorBool'Unds'(SortBool{}, SortBool{}): SortBool{} $)
$c \kore-symbol-Lbl'Unds'xorBool'Unds' \kore-symbol-Lbl'Unds'xorBool'Unds'-symbol $.
IMP-symbol-216-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'xorBool'Unds'-symbol $.
IMP-symbol-216-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'xorBool'Unds' ptn0 ptn1 ) $.
IMP-symbol-216-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'xorBool'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'xorBool'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-216-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ptn1 \kore-sort-SortBool ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'xorBool'Unds' ptn0 ptn1 ) \kore-sort-SortBool ) ) $.

$( symbol Lbl'Unds'xorInt'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'Unds'xorInt'Unds' \kore-symbol-Lbl'Unds'xorInt'Unds'-symbol $.
IMP-symbol-217-is-symbol $a #Symbol \kore-symbol-Lbl'Unds'xorInt'Unds'-symbol $.
IMP-symbol-217-is-pattern $a #Pattern ( \kore-symbol-Lbl'Unds'xorInt'Unds' ptn0 ptn1 ) $.
IMP-symbol-217-is-sugar $a #Notation ( \kore-symbol-Lbl'Unds'xorInt'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'Unds'xorInt'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-217-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'Unds'xorInt'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsPipe'-'-GT-Unds'(SortKItem{}, SortKItem{}): SortMap{} $)
$c \kore-symbol-Lbl'UndsPipe'-'-GT-Unds' \kore-symbol-Lbl'UndsPipe'-'-GT-Unds'-symbol $.
IMP-symbol-218-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPipe'-'-GT-Unds'-symbol $.
IMP-symbol-218-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPipe'-'-GT-Unds' ptn0 ptn1 ) $.
IMP-symbol-218-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPipe'-'-GT-Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPipe'-'-GT-Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-218-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortKItem ) ( \in-sort ptn1 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPipe'-'-GT-Unds' ptn0 ptn1 ) \kore-sort-SortMap ) ) $.

$( symbol Lbl'UndsPipe'Int'Unds'(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'UndsPipe'Int'Unds' \kore-symbol-Lbl'UndsPipe'Int'Unds'-symbol $.
IMP-symbol-219-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPipe'Int'Unds'-symbol $.
IMP-symbol-219-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPipe'Int'Unds' ptn0 ptn1 ) $.
IMP-symbol-219-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPipe'Int'Unds' ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPipe'Int'Unds'-symbol ptn0 ) ptn1 ) $.
IMP-symbol-219-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPipe'Int'Unds' ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set(SortSet{}, SortSet{}): SortSet{} $)
$c \kore-symbol-Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set \kore-symbol-Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set-symbol $.
IMP-symbol-220-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set-symbol $.
IMP-symbol-220-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set ptn0 ptn1 ) $.
IMP-symbol-220-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set-symbol ptn0 ) ptn1 ) $.
IMP-symbol-220-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortSet ) ( \in-sort ptn1 \kore-sort-SortSet ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPipe'Set'UndsUnds'SET'Unds'Set'Unds'Set'Unds'Set ptn0 ptn1 ) \kore-sort-SortSet ) ) $.

$( symbol Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id(SortId{}, SortId{}): SortAExp{} $)
$c \kore-symbol-Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id \kore-symbol-Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id-symbol $.
IMP-symbol-221-is-symbol $a #Symbol \kore-symbol-Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id-symbol $.
IMP-symbol-221-is-pattern $a #Pattern ( \kore-symbol-Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id ptn0 ptn1 ) $.
IMP-symbol-221-is-sugar $a #Notation ( \kore-symbol-Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id-symbol ptn0 ) ptn1 ) $.
IMP-symbol-221-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortId ) ( \in-sort ptn1 \kore-sort-SortId ) ) ( \in-sort ( \kore-symbol-Lbl'UndsPipeUndsPipeUnds'IMP-SYNTAX'Unds'AExp'Unds'Id'Unds'Id ptn0 ptn1 ) \kore-sort-SortAExp ) ) $.

$( symbol LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int(SortInt{}): SortInt{} $)
$c \kore-symbol-LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int \kore-symbol-LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int-symbol $.
IMP-symbol-222-is-symbol $a #Symbol \kore-symbol-LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int-symbol $.
IMP-symbol-222-is-pattern $a #Pattern ( \kore-symbol-LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int ptn0 ) $.
IMP-symbol-222-is-sugar $a #Notation ( \kore-symbol-LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int ptn0 ) ( \app \kore-symbol-LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int-symbol ptn0 ) $.
IMP-symbol-222-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-LblabsInt'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem(SortList{}, SortInt{}, SortKItem{}): SortArray{} $)
$c \kore-symbol-Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem \kore-symbol-Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-223-is-symbol $a #Symbol \kore-symbol-Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-223-is-pattern $a #Pattern ( \kore-symbol-Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) $.
IMP-symbol-223-is-sugar $a #Notation ( \kore-symbol-Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-223-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-Lblarr'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) \kore-sort-SortArray ) ) $.

$( symbol LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int(SortInt{}, SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int \kore-symbol-LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-224-is-symbol $a #Symbol \kore-symbol-LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-224-is-pattern $a #Pattern ( \kore-symbol-LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) $.
IMP-symbol-224-is-sugar $a #Notation ( \kore-symbol-LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-224-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblbitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) \kore-sort-SortInt ) ) $.

$( symbol LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String(SortString{}): SortString{} $)
$c \kore-symbol-LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String \kore-symbol-LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String-symbol $.
IMP-symbol-225-is-symbol $a #Symbol \kore-symbol-LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String-symbol $.
IMP-symbol-225-is-pattern $a #Pattern ( \kore-symbol-LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String ptn0 ) $.
IMP-symbol-225-is-sugar $a #Notation ( \kore-symbol-LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String ptn0 ) ( \app \kore-symbol-LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String-symbol ptn0 ) $.
IMP-symbol-225-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LblcategoryChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String ptn0 ) \kore-sort-SortString ) ) $.

$( symbol Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map(SortMap{}): SortKItem{} $)
$c \kore-symbol-Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map \kore-symbol-Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map-symbol $.
IMP-symbol-226-is-symbol $a #Symbol \kore-symbol-Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map-symbol $.
IMP-symbol-226-is-pattern $a #Pattern ( \kore-symbol-Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map ptn0 ) $.
IMP-symbol-226-is-sugar $a #Notation ( \kore-symbol-Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map ptn0 ) ( \app \kore-symbol-Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map-symbol ptn0 ) $.
IMP-symbol-226-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-Lblchoice'LParUndsRParUnds'MAP'Unds'KItem'Unds'Map ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set(SortSet{}): SortKItem{} $)
$c \kore-symbol-Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set \kore-symbol-Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set-symbol $.
IMP-symbol-227-is-symbol $a #Symbol \kore-symbol-Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set-symbol $.
IMP-symbol-227-is-pattern $a #Pattern ( \kore-symbol-Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set ptn0 ) $.
IMP-symbol-227-is-sugar $a #Notation ( \kore-symbol-Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set ptn0 ) ( \app \kore-symbol-Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set-symbol ptn0 ) $.
IMP-symbol-227-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortSet ) ( \in-sort ( \kore-symbol-Lblchoice'LParUndsRParUnds'SET'Unds'KItem'Unds'Set ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int(SortInt{}): SortString{} $)
$c \kore-symbol-LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int \kore-symbol-LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int-symbol $.
IMP-symbol-228-is-symbol $a #Symbol \kore-symbol-LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int-symbol $.
IMP-symbol-228-is-pattern $a #Pattern ( \kore-symbol-LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int ptn0 ) $.
IMP-symbol-228-is-sugar $a #Notation ( \kore-symbol-LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int ptn0 ) ( \app \kore-symbol-LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int-symbol ptn0 ) $.
IMP-symbol-228-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-LblchrChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'Int ptn0 ) \kore-sort-SortString ) ) $.

$( symbol LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String(SortString{}, SortString{}): SortInt{} $)
$c \kore-symbol-LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String \kore-symbol-LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String-symbol $.
IMP-symbol-229-is-symbol $a #Symbol \kore-symbol-LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String-symbol $.
IMP-symbol-229-is-pattern $a #Pattern ( \kore-symbol-LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String ptn0 ptn1 ) $.
IMP-symbol-229-is-sugar $a #Notation ( \kore-symbol-LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) $.
IMP-symbol-229-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-LblcountAllOccurrences'LParUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String(SortString{}): SortString{} $)
$c \kore-symbol-LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String \kore-symbol-LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String-symbol $.
IMP-symbol-230-is-symbol $a #Symbol \kore-symbol-LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String-symbol $.
IMP-symbol-230-is-pattern $a #Pattern ( \kore-symbol-LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String ptn0 ) $.
IMP-symbol-230-is-sugar $a #Notation ( \kore-symbol-LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String ptn0 ) ( \app \kore-symbol-LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String-symbol ptn0 ) $.
IMP-symbol-230-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LbldirectionalityChar'LParUndsRParUnds'STRING-COMMON'Unds'String'Unds'String ptn0 ) \kore-sort-SortString ) ) $.

$( symbol LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem(SortList{}, SortInt{}, SortKItem{}): SortList{} $)
$c \kore-symbol-LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem \kore-symbol-LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-231-is-symbol $a #Symbol \kore-symbol-LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-231-is-pattern $a #Pattern ( \kore-symbol-LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) $.
IMP-symbol-231-is-sugar $a #Notation ( \kore-symbol-LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-231-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-LblensureOffsetList'LParUndsCommUndsCommUndsRParUnds'ARRAY-IN-K'Unds'List'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ) \kore-sort-SortList ) ) $.

$( symbol Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int \kore-symbol-Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-232-is-symbol $a #Symbol \kore-symbol-Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-232-is-pattern $a #Pattern ( \kore-symbol-Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-232-is-sugar $a #Notation ( \kore-symbol-Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-232-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lblexp'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem(SortArray{}, SortInt{}, SortInt{}, SortKItem{}): SortArray{} $)
$c \kore-symbol-LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem \kore-symbol-LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-233-is-symbol $a #Symbol \kore-symbol-LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-233-is-pattern $a #Pattern ( \kore-symbol-LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ptn3 ) $.
IMP-symbol-233-is-sugar $a #Notation ( \kore-symbol-LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ptn3 ) ( \app ( \app ( \app ( \app \kore-symbol-LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem-symbol ptn0 ) ptn1 ) ptn2 ) ptn3 ) $.
IMP-symbol-233-sorting $a |- ( \imp ( \and ( \and ( \and ( \in-sort ptn0 \kore-sort-SortArray ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ptn3 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-LblfillArray'LParUndsCommUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ptn3 ) \kore-sort-SortArray ) ) $.

$( symbol LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem(SortList{}, SortInt{}, SortInt{}, SortKItem{}): SortList{} $)
$c \kore-symbol-LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem \kore-symbol-LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-234-is-symbol $a #Symbol \kore-symbol-LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-234-is-pattern $a #Pattern ( \kore-symbol-LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ptn3 ) $.
IMP-symbol-234-is-sugar $a #Notation ( \kore-symbol-LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ptn3 ) ( \app ( \app ( \app ( \app \kore-symbol-LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem-symbol ptn0 ) ptn1 ) ptn2 ) ptn3 ) $.
IMP-symbol-234-sorting $a |- ( \imp ( \and ( \and ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ptn3 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-LblfillList'LParUndsCommUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'Int'Unds'KItem ptn0 ptn1 ptn2 ptn3 ) \kore-sort-SortList ) ) $.

$( symbol LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int(SortString{}, SortString{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int \kore-symbol-LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-235-is-symbol $a #Symbol \kore-symbol-LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-235-is-pattern $a #Pattern ( \kore-symbol-LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) $.
IMP-symbol-235-is-sugar $a #Notation ( \kore-symbol-LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-235-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) \kore-sort-SortInt ) ) $.

$( symbol LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int(SortString{}, SortString{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int \kore-symbol-LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-236-is-symbol $a #Symbol \kore-symbol-LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-236-is-pattern $a #Pattern ( \kore-symbol-LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) $.
IMP-symbol-236-is-sugar $a #Notation ( \kore-symbol-LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-236-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) \kore-sort-SortInt ) ) $.

$( symbol LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int(SortInt{}): SortId{} $)
$c \kore-symbol-LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int \kore-symbol-LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int-symbol $.
IMP-symbol-237-is-symbol $a #Symbol \kore-symbol-LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int-symbol $.
IMP-symbol-237-is-pattern $a #Pattern ( \kore-symbol-LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int ptn0 ) $.
IMP-symbol-237-is-sugar $a #Notation ( \kore-symbol-LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int ptn0 ) ( \app \kore-symbol-LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int-symbol ptn0 ) $.
IMP-symbol-237-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-LblfreshId'LParUndsRParUnds'ID-COMMON'Unds'Id'Unds'Int ptn0 ) \kore-sort-SortId ) ) $.

$( symbol LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int(SortInt{}): SortInt{} $)
$c \kore-symbol-LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int \kore-symbol-LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int-symbol $.
IMP-symbol-238-is-symbol $a #Symbol \kore-symbol-LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int-symbol $.
IMP-symbol-238-is-pattern $a #Pattern ( \kore-symbol-LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int ptn0 ) $.
IMP-symbol-238-is-sugar $a #Notation ( \kore-symbol-LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int ptn0 ) ( \app \kore-symbol-LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int-symbol ptn0 ) $.
IMP-symbol-238-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-LblfreshInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int \kore-symbol-Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-239-is-symbol $a #Symbol \kore-symbol-Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-239-is-pattern $a #Pattern ( \kore-symbol-Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-239-is-sugar $a #Notation ( \kore-symbol-Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-239-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lblgcd'LParUndsCommUndsRParUnds'VERIFICAITON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol LblgetGeneratedCounterCell(SortGeneratedTopCell{}): SortGeneratedCounterCell{} $)
$c \kore-symbol-LblgetGeneratedCounterCell \kore-symbol-LblgetGeneratedCounterCell-symbol $.
IMP-symbol-240-is-symbol $a #Symbol \kore-symbol-LblgetGeneratedCounterCell-symbol $.
IMP-symbol-240-is-pattern $a #Pattern ( \kore-symbol-LblgetGeneratedCounterCell ptn0 ) $.
IMP-symbol-240-is-sugar $a #Notation ( \kore-symbol-LblgetGeneratedCounterCell ptn0 ) ( \app \kore-symbol-LblgetGeneratedCounterCell-symbol ptn0 ) $.
IMP-symbol-240-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortGeneratedTopCell ) ( \in-sort ( \kore-symbol-LblgetGeneratedCounterCell ptn0 ) \kore-sort-SortGeneratedCounterCell ) ) $.

$( symbol Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block(SortBExp{}, SortBlock{}, SortBlock{}): SortStmt{} $)
$c \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block-symbol $.
IMP-symbol-241-is-symbol $a #Symbol \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block-symbol $.
IMP-symbol-241-is-pattern $a #Pattern ( \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block ptn0 ptn1 ptn2 ) $.
IMP-symbol-241-is-sugar $a #Notation ( \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-241-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortBExp ) ( \in-sort ptn1 \kore-sort-SortBlock ) ) ( \in-sort ptn2 \kore-sort-SortBlock ) ) ( \in-sort ( \kore-symbol-Lblif'LParUndsRParUnds'else'UndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block'Unds'Block ptn0 ptn1 ptn2 ) \kore-sort-SortStmt ) ) $.

$( symbol LblinitGeneratedCounterCell(): SortGeneratedCounterCell{} $)
$c \kore-symbol-LblinitGeneratedCounterCell \kore-symbol-LblinitGeneratedCounterCell-symbol $.
IMP-symbol-242-is-symbol $a #Symbol \kore-symbol-LblinitGeneratedCounterCell-symbol $.
IMP-symbol-242-is-pattern $a #Pattern \kore-symbol-LblinitGeneratedCounterCell $.
IMP-symbol-242-is-sugar $a #Notation \kore-symbol-LblinitGeneratedCounterCell \kore-symbol-LblinitGeneratedCounterCell-symbol $.
IMP-symbol-242-sorting $a |- ( \in-sort \kore-symbol-LblinitGeneratedCounterCell \kore-sort-SortGeneratedCounterCell ) $.

$( symbol LblinitGeneratedTopCell(SortMap{}): SortGeneratedTopCell{} $)
$c \kore-symbol-LblinitGeneratedTopCell \kore-symbol-LblinitGeneratedTopCell-symbol $.
IMP-symbol-243-is-symbol $a #Symbol \kore-symbol-LblinitGeneratedTopCell-symbol $.
IMP-symbol-243-is-pattern $a #Pattern ( \kore-symbol-LblinitGeneratedTopCell ptn0 ) $.
IMP-symbol-243-is-sugar $a #Notation ( \kore-symbol-LblinitGeneratedTopCell ptn0 ) ( \app \kore-symbol-LblinitGeneratedTopCell-symbol ptn0 ) $.
IMP-symbol-243-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-LblinitGeneratedTopCell ptn0 ) \kore-sort-SortGeneratedTopCell ) ) $.

$( symbol LblinitKCell(SortMap{}): SortKCell{} $)
$c \kore-symbol-LblinitKCell \kore-symbol-LblinitKCell-symbol $.
IMP-symbol-244-is-symbol $a #Symbol \kore-symbol-LblinitKCell-symbol $.
IMP-symbol-244-is-pattern $a #Pattern ( \kore-symbol-LblinitKCell ptn0 ) $.
IMP-symbol-244-is-sugar $a #Notation ( \kore-symbol-LblinitKCell ptn0 ) ( \app \kore-symbol-LblinitKCell-symbol ptn0 ) $.
IMP-symbol-244-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-LblinitKCell ptn0 ) \kore-sort-SortKCell ) ) $.

$( symbol LblinitStateCell(): SortStateCell{} $)
$c \kore-symbol-LblinitStateCell \kore-symbol-LblinitStateCell-symbol $.
IMP-symbol-245-is-symbol $a #Symbol \kore-symbol-LblinitStateCell-symbol $.
IMP-symbol-245-is-pattern $a #Pattern \kore-symbol-LblinitStateCell $.
IMP-symbol-245-is-sugar $a #Notation \kore-symbol-LblinitStateCell \kore-symbol-LblinitStateCell-symbol $.
IMP-symbol-245-sorting $a |- ( \in-sort \kore-symbol-LblinitStateCell \kore-sort-SortStateCell ) $.

$( symbol LblinitTCell(SortMap{}): SortTCell{} $)
$c \kore-symbol-LblinitTCell \kore-symbol-LblinitTCell-symbol $.
IMP-symbol-246-is-symbol $a #Symbol \kore-symbol-LblinitTCell-symbol $.
IMP-symbol-246-is-pattern $a #Pattern ( \kore-symbol-LblinitTCell ptn0 ) $.
IMP-symbol-246-is-sugar $a #Notation ( \kore-symbol-LblinitTCell ptn0 ) ( \app \kore-symbol-LblinitTCell-symbol ptn0 ) $.
IMP-symbol-246-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-LblinitTCell ptn0 ) \kore-sort-SortTCell ) ) $.

$( symbol Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt(SortIds{}, SortStmt{}): SortPgm{} $)
$c \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt-symbol $.
IMP-symbol-247-is-symbol $a #Symbol \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt-symbol $.
IMP-symbol-247-is-pattern $a #Pattern ( \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt ptn0 ptn1 ) $.
IMP-symbol-247-is-sugar $a #Notation ( \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt-symbol ptn0 ) ptn1 ) $.
IMP-symbol-247-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortIds ) ( \in-sort ptn1 \kore-sort-SortStmt ) ) ( \in-sort ( \kore-symbol-Lblint'UndsSClnUndsUnds'IMP-SYNTAX'Unds'Pgm'Unds'Ids'Unds'Stmt ptn0 ptn1 ) \kore-sort-SortPgm ) ) $.

$( symbol LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set(SortSet{}, SortSet{}): SortSet{} $)
$c \kore-symbol-LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set \kore-symbol-LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set-symbol $.
IMP-symbol-248-is-symbol $a #Symbol \kore-symbol-LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set-symbol $.
IMP-symbol-248-is-pattern $a #Pattern ( \kore-symbol-LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set ptn0 ptn1 ) $.
IMP-symbol-248-is-sugar $a #Notation ( \kore-symbol-LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set-symbol ptn0 ) ptn1 ) $.
IMP-symbol-248-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortSet ) ( \in-sort ptn1 \kore-sort-SortSet ) ) ( \in-sort ( \kore-symbol-LblintersectSet'LParUndsCommUndsRParUnds'SET'Unds'Set'Unds'Set'Unds'Set ptn0 ptn1 ) \kore-sort-SortSet ) ) $.

$( symbol LblisAExp(SortK{}): SortBool{} $)
$c \kore-symbol-LblisAExp \kore-symbol-LblisAExp-symbol $.
IMP-symbol-249-is-symbol $a #Symbol \kore-symbol-LblisAExp-symbol $.
IMP-symbol-249-is-pattern $a #Pattern ( \kore-symbol-LblisAExp ptn0 ) $.
IMP-symbol-249-is-sugar $a #Notation ( \kore-symbol-LblisAExp ptn0 ) ( \app \kore-symbol-LblisAExp-symbol ptn0 ) $.
IMP-symbol-249-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisAExp ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisArray(SortK{}): SortBool{} $)
$c \kore-symbol-LblisArray \kore-symbol-LblisArray-symbol $.
IMP-symbol-250-is-symbol $a #Symbol \kore-symbol-LblisArray-symbol $.
IMP-symbol-250-is-pattern $a #Pattern ( \kore-symbol-LblisArray ptn0 ) $.
IMP-symbol-250-is-sugar $a #Notation ( \kore-symbol-LblisArray ptn0 ) ( \app \kore-symbol-LblisArray-symbol ptn0 ) $.
IMP-symbol-250-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisArray ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisBExp(SortK{}): SortBool{} $)
$c \kore-symbol-LblisBExp \kore-symbol-LblisBExp-symbol $.
IMP-symbol-251-is-symbol $a #Symbol \kore-symbol-LblisBExp-symbol $.
IMP-symbol-251-is-pattern $a #Pattern ( \kore-symbol-LblisBExp ptn0 ) $.
IMP-symbol-251-is-sugar $a #Notation ( \kore-symbol-LblisBExp ptn0 ) ( \app \kore-symbol-LblisBExp-symbol ptn0 ) $.
IMP-symbol-251-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisBExp ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisBlock(SortK{}): SortBool{} $)
$c \kore-symbol-LblisBlock \kore-symbol-LblisBlock-symbol $.
IMP-symbol-252-is-symbol $a #Symbol \kore-symbol-LblisBlock-symbol $.
IMP-symbol-252-is-pattern $a #Pattern ( \kore-symbol-LblisBlock ptn0 ) $.
IMP-symbol-252-is-sugar $a #Notation ( \kore-symbol-LblisBlock ptn0 ) ( \app \kore-symbol-LblisBlock-symbol ptn0 ) $.
IMP-symbol-252-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisBlock ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisBool(SortK{}): SortBool{} $)
$c \kore-symbol-LblisBool \kore-symbol-LblisBool-symbol $.
IMP-symbol-253-is-symbol $a #Symbol \kore-symbol-LblisBool-symbol $.
IMP-symbol-253-is-pattern $a #Pattern ( \kore-symbol-LblisBool ptn0 ) $.
IMP-symbol-253-is-sugar $a #Notation ( \kore-symbol-LblisBool ptn0 ) ( \app \kore-symbol-LblisBool-symbol ptn0 ) $.
IMP-symbol-253-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisBool ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisFloat(SortK{}): SortBool{} $)
$c \kore-symbol-LblisFloat \kore-symbol-LblisFloat-symbol $.
IMP-symbol-254-is-symbol $a #Symbol \kore-symbol-LblisFloat-symbol $.
IMP-symbol-254-is-pattern $a #Pattern ( \kore-symbol-LblisFloat ptn0 ) $.
IMP-symbol-254-is-sugar $a #Notation ( \kore-symbol-LblisFloat ptn0 ) ( \app \kore-symbol-LblisFloat-symbol ptn0 ) $.
IMP-symbol-254-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisFloat ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisGeneratedCounterCell(SortK{}): SortBool{} $)
$c \kore-symbol-LblisGeneratedCounterCell \kore-symbol-LblisGeneratedCounterCell-symbol $.
IMP-symbol-255-is-symbol $a #Symbol \kore-symbol-LblisGeneratedCounterCell-symbol $.
IMP-symbol-255-is-pattern $a #Pattern ( \kore-symbol-LblisGeneratedCounterCell ptn0 ) $.
IMP-symbol-255-is-sugar $a #Notation ( \kore-symbol-LblisGeneratedCounterCell ptn0 ) ( \app \kore-symbol-LblisGeneratedCounterCell-symbol ptn0 ) $.
IMP-symbol-255-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisGeneratedCounterCell ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisGeneratedCounterCellOpt(SortK{}): SortBool{} $)
$c \kore-symbol-LblisGeneratedCounterCellOpt \kore-symbol-LblisGeneratedCounterCellOpt-symbol $.
IMP-symbol-256-is-symbol $a #Symbol \kore-symbol-LblisGeneratedCounterCellOpt-symbol $.
IMP-symbol-256-is-pattern $a #Pattern ( \kore-symbol-LblisGeneratedCounterCellOpt ptn0 ) $.
IMP-symbol-256-is-sugar $a #Notation ( \kore-symbol-LblisGeneratedCounterCellOpt ptn0 ) ( \app \kore-symbol-LblisGeneratedCounterCellOpt-symbol ptn0 ) $.
IMP-symbol-256-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisGeneratedCounterCellOpt ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisGeneratedTopCell(SortK{}): SortBool{} $)
$c \kore-symbol-LblisGeneratedTopCell \kore-symbol-LblisGeneratedTopCell-symbol $.
IMP-symbol-257-is-symbol $a #Symbol \kore-symbol-LblisGeneratedTopCell-symbol $.
IMP-symbol-257-is-pattern $a #Pattern ( \kore-symbol-LblisGeneratedTopCell ptn0 ) $.
IMP-symbol-257-is-sugar $a #Notation ( \kore-symbol-LblisGeneratedTopCell ptn0 ) ( \app \kore-symbol-LblisGeneratedTopCell-symbol ptn0 ) $.
IMP-symbol-257-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisGeneratedTopCell ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisGeneratedTopCellFragment(SortK{}): SortBool{} $)
$c \kore-symbol-LblisGeneratedTopCellFragment \kore-symbol-LblisGeneratedTopCellFragment-symbol $.
IMP-symbol-258-is-symbol $a #Symbol \kore-symbol-LblisGeneratedTopCellFragment-symbol $.
IMP-symbol-258-is-pattern $a #Pattern ( \kore-symbol-LblisGeneratedTopCellFragment ptn0 ) $.
IMP-symbol-258-is-sugar $a #Notation ( \kore-symbol-LblisGeneratedTopCellFragment ptn0 ) ( \app \kore-symbol-LblisGeneratedTopCellFragment-symbol ptn0 ) $.
IMP-symbol-258-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisGeneratedTopCellFragment ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisIOError(SortK{}): SortBool{} $)
$c \kore-symbol-LblisIOError \kore-symbol-LblisIOError-symbol $.
IMP-symbol-259-is-symbol $a #Symbol \kore-symbol-LblisIOError-symbol $.
IMP-symbol-259-is-pattern $a #Pattern ( \kore-symbol-LblisIOError ptn0 ) $.
IMP-symbol-259-is-sugar $a #Notation ( \kore-symbol-LblisIOError ptn0 ) ( \app \kore-symbol-LblisIOError-symbol ptn0 ) $.
IMP-symbol-259-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisIOError ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisIOFile(SortK{}): SortBool{} $)
$c \kore-symbol-LblisIOFile \kore-symbol-LblisIOFile-symbol $.
IMP-symbol-260-is-symbol $a #Symbol \kore-symbol-LblisIOFile-symbol $.
IMP-symbol-260-is-pattern $a #Pattern ( \kore-symbol-LblisIOFile ptn0 ) $.
IMP-symbol-260-is-sugar $a #Notation ( \kore-symbol-LblisIOFile ptn0 ) ( \app \kore-symbol-LblisIOFile-symbol ptn0 ) $.
IMP-symbol-260-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisIOFile ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisIOInt(SortK{}): SortBool{} $)
$c \kore-symbol-LblisIOInt \kore-symbol-LblisIOInt-symbol $.
IMP-symbol-261-is-symbol $a #Symbol \kore-symbol-LblisIOInt-symbol $.
IMP-symbol-261-is-pattern $a #Pattern ( \kore-symbol-LblisIOInt ptn0 ) $.
IMP-symbol-261-is-sugar $a #Notation ( \kore-symbol-LblisIOInt ptn0 ) ( \app \kore-symbol-LblisIOInt-symbol ptn0 ) $.
IMP-symbol-261-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisIOInt ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisIOString(SortK{}): SortBool{} $)
$c \kore-symbol-LblisIOString \kore-symbol-LblisIOString-symbol $.
IMP-symbol-262-is-symbol $a #Symbol \kore-symbol-LblisIOString-symbol $.
IMP-symbol-262-is-pattern $a #Pattern ( \kore-symbol-LblisIOString ptn0 ) $.
IMP-symbol-262-is-sugar $a #Notation ( \kore-symbol-LblisIOString ptn0 ) ( \app \kore-symbol-LblisIOString-symbol ptn0 ) $.
IMP-symbol-262-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisIOString ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisId(SortK{}): SortBool{} $)
$c \kore-symbol-LblisId \kore-symbol-LblisId-symbol $.
IMP-symbol-263-is-symbol $a #Symbol \kore-symbol-LblisId-symbol $.
IMP-symbol-263-is-pattern $a #Pattern ( \kore-symbol-LblisId ptn0 ) $.
IMP-symbol-263-is-sugar $a #Notation ( \kore-symbol-LblisId ptn0 ) ( \app \kore-symbol-LblisId-symbol ptn0 ) $.
IMP-symbol-263-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisId ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisIds(SortK{}): SortBool{} $)
$c \kore-symbol-LblisIds \kore-symbol-LblisIds-symbol $.
IMP-symbol-264-is-symbol $a #Symbol \kore-symbol-LblisIds-symbol $.
IMP-symbol-264-is-pattern $a #Pattern ( \kore-symbol-LblisIds ptn0 ) $.
IMP-symbol-264-is-sugar $a #Notation ( \kore-symbol-LblisIds ptn0 ) ( \app \kore-symbol-LblisIds-symbol ptn0 ) $.
IMP-symbol-264-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisIds ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisInt(SortK{}): SortBool{} $)
$c \kore-symbol-LblisInt \kore-symbol-LblisInt-symbol $.
IMP-symbol-265-is-symbol $a #Symbol \kore-symbol-LblisInt-symbol $.
IMP-symbol-265-is-pattern $a #Pattern ( \kore-symbol-LblisInt ptn0 ) $.
IMP-symbol-265-is-sugar $a #Notation ( \kore-symbol-LblisInt ptn0 ) ( \app \kore-symbol-LblisInt-symbol ptn0 ) $.
IMP-symbol-265-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisInt ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisK(SortK{}): SortBool{} $)
$c \kore-symbol-LblisK \kore-symbol-LblisK-symbol $.
IMP-symbol-266-is-symbol $a #Symbol \kore-symbol-LblisK-symbol $.
IMP-symbol-266-is-pattern $a #Pattern ( \kore-symbol-LblisK ptn0 ) $.
IMP-symbol-266-is-sugar $a #Notation ( \kore-symbol-LblisK ptn0 ) ( \app \kore-symbol-LblisK-symbol ptn0 ) $.
IMP-symbol-266-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisK ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisKCell(SortK{}): SortBool{} $)
$c \kore-symbol-LblisKCell \kore-symbol-LblisKCell-symbol $.
IMP-symbol-267-is-symbol $a #Symbol \kore-symbol-LblisKCell-symbol $.
IMP-symbol-267-is-pattern $a #Pattern ( \kore-symbol-LblisKCell ptn0 ) $.
IMP-symbol-267-is-sugar $a #Notation ( \kore-symbol-LblisKCell ptn0 ) ( \app \kore-symbol-LblisKCell-symbol ptn0 ) $.
IMP-symbol-267-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisKCell ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisKCellOpt(SortK{}): SortBool{} $)
$c \kore-symbol-LblisKCellOpt \kore-symbol-LblisKCellOpt-symbol $.
IMP-symbol-268-is-symbol $a #Symbol \kore-symbol-LblisKCellOpt-symbol $.
IMP-symbol-268-is-pattern $a #Pattern ( \kore-symbol-LblisKCellOpt ptn0 ) $.
IMP-symbol-268-is-sugar $a #Notation ( \kore-symbol-LblisKCellOpt ptn0 ) ( \app \kore-symbol-LblisKCellOpt-symbol ptn0 ) $.
IMP-symbol-268-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisKCellOpt ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisKConfigVar(SortK{}): SortBool{} $)
$c \kore-symbol-LblisKConfigVar \kore-symbol-LblisKConfigVar-symbol $.
IMP-symbol-269-is-symbol $a #Symbol \kore-symbol-LblisKConfigVar-symbol $.
IMP-symbol-269-is-pattern $a #Pattern ( \kore-symbol-LblisKConfigVar ptn0 ) $.
IMP-symbol-269-is-sugar $a #Notation ( \kore-symbol-LblisKConfigVar ptn0 ) ( \app \kore-symbol-LblisKConfigVar-symbol ptn0 ) $.
IMP-symbol-269-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisKConfigVar ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisKItem(SortK{}): SortBool{} $)
$c \kore-symbol-LblisKItem \kore-symbol-LblisKItem-symbol $.
IMP-symbol-270-is-symbol $a #Symbol \kore-symbol-LblisKItem-symbol $.
IMP-symbol-270-is-pattern $a #Pattern ( \kore-symbol-LblisKItem ptn0 ) $.
IMP-symbol-270-is-sugar $a #Notation ( \kore-symbol-LblisKItem ptn0 ) ( \app \kore-symbol-LblisKItem-symbol ptn0 ) $.
IMP-symbol-270-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisKItem ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisKResult(SortK{}): SortBool{} $)
$c \kore-symbol-LblisKResult \kore-symbol-LblisKResult-symbol $.
IMP-symbol-271-is-symbol $a #Symbol \kore-symbol-LblisKResult-symbol $.
IMP-symbol-271-is-pattern $a #Pattern ( \kore-symbol-LblisKResult ptn0 ) $.
IMP-symbol-271-is-sugar $a #Notation ( \kore-symbol-LblisKResult ptn0 ) ( \app \kore-symbol-LblisKResult-symbol ptn0 ) $.
IMP-symbol-271-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisKResult ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisList(SortK{}): SortBool{} $)
$c \kore-symbol-LblisList \kore-symbol-LblisList-symbol $.
IMP-symbol-272-is-symbol $a #Symbol \kore-symbol-LblisList-symbol $.
IMP-symbol-272-is-pattern $a #Pattern ( \kore-symbol-LblisList ptn0 ) $.
IMP-symbol-272-is-sugar $a #Notation ( \kore-symbol-LblisList ptn0 ) ( \app \kore-symbol-LblisList-symbol ptn0 ) $.
IMP-symbol-272-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisList ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisMap(SortK{}): SortBool{} $)
$c \kore-symbol-LblisMap \kore-symbol-LblisMap-symbol $.
IMP-symbol-273-is-symbol $a #Symbol \kore-symbol-LblisMap-symbol $.
IMP-symbol-273-is-pattern $a #Pattern ( \kore-symbol-LblisMap ptn0 ) $.
IMP-symbol-273-is-sugar $a #Notation ( \kore-symbol-LblisMap ptn0 ) ( \app \kore-symbol-LblisMap-symbol ptn0 ) $.
IMP-symbol-273-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisMap ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisPgm(SortK{}): SortBool{} $)
$c \kore-symbol-LblisPgm \kore-symbol-LblisPgm-symbol $.
IMP-symbol-274-is-symbol $a #Symbol \kore-symbol-LblisPgm-symbol $.
IMP-symbol-274-is-pattern $a #Pattern ( \kore-symbol-LblisPgm ptn0 ) $.
IMP-symbol-274-is-sugar $a #Notation ( \kore-symbol-LblisPgm ptn0 ) ( \app \kore-symbol-LblisPgm-symbol ptn0 ) $.
IMP-symbol-274-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisPgm ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisSet(SortK{}): SortBool{} $)
$c \kore-symbol-LblisSet \kore-symbol-LblisSet-symbol $.
IMP-symbol-275-is-symbol $a #Symbol \kore-symbol-LblisSet-symbol $.
IMP-symbol-275-is-pattern $a #Pattern ( \kore-symbol-LblisSet ptn0 ) $.
IMP-symbol-275-is-sugar $a #Notation ( \kore-symbol-LblisSet ptn0 ) ( \app \kore-symbol-LblisSet-symbol ptn0 ) $.
IMP-symbol-275-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisSet ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisStateCell(SortK{}): SortBool{} $)
$c \kore-symbol-LblisStateCell \kore-symbol-LblisStateCell-symbol $.
IMP-symbol-276-is-symbol $a #Symbol \kore-symbol-LblisStateCell-symbol $.
IMP-symbol-276-is-pattern $a #Pattern ( \kore-symbol-LblisStateCell ptn0 ) $.
IMP-symbol-276-is-sugar $a #Notation ( \kore-symbol-LblisStateCell ptn0 ) ( \app \kore-symbol-LblisStateCell-symbol ptn0 ) $.
IMP-symbol-276-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisStateCell ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisStateCellOpt(SortK{}): SortBool{} $)
$c \kore-symbol-LblisStateCellOpt \kore-symbol-LblisStateCellOpt-symbol $.
IMP-symbol-277-is-symbol $a #Symbol \kore-symbol-LblisStateCellOpt-symbol $.
IMP-symbol-277-is-pattern $a #Pattern ( \kore-symbol-LblisStateCellOpt ptn0 ) $.
IMP-symbol-277-is-sugar $a #Notation ( \kore-symbol-LblisStateCellOpt ptn0 ) ( \app \kore-symbol-LblisStateCellOpt-symbol ptn0 ) $.
IMP-symbol-277-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisStateCellOpt ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisStmt(SortK{}): SortBool{} $)
$c \kore-symbol-LblisStmt \kore-symbol-LblisStmt-symbol $.
IMP-symbol-278-is-symbol $a #Symbol \kore-symbol-LblisStmt-symbol $.
IMP-symbol-278-is-pattern $a #Pattern ( \kore-symbol-LblisStmt ptn0 ) $.
IMP-symbol-278-is-sugar $a #Notation ( \kore-symbol-LblisStmt ptn0 ) ( \app \kore-symbol-LblisStmt-symbol ptn0 ) $.
IMP-symbol-278-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisStmt ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisStream(SortK{}): SortBool{} $)
$c \kore-symbol-LblisStream \kore-symbol-LblisStream-symbol $.
IMP-symbol-279-is-symbol $a #Symbol \kore-symbol-LblisStream-symbol $.
IMP-symbol-279-is-pattern $a #Pattern ( \kore-symbol-LblisStream ptn0 ) $.
IMP-symbol-279-is-sugar $a #Notation ( \kore-symbol-LblisStream ptn0 ) ( \app \kore-symbol-LblisStream-symbol ptn0 ) $.
IMP-symbol-279-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisStream ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisString(SortK{}): SortBool{} $)
$c \kore-symbol-LblisString \kore-symbol-LblisString-symbol $.
IMP-symbol-280-is-symbol $a #Symbol \kore-symbol-LblisString-symbol $.
IMP-symbol-280-is-pattern $a #Pattern ( \kore-symbol-LblisString ptn0 ) $.
IMP-symbol-280-is-sugar $a #Notation ( \kore-symbol-LblisString ptn0 ) ( \app \kore-symbol-LblisString-symbol ptn0 ) $.
IMP-symbol-280-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisString ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisTCell(SortK{}): SortBool{} $)
$c \kore-symbol-LblisTCell \kore-symbol-LblisTCell-symbol $.
IMP-symbol-281-is-symbol $a #Symbol \kore-symbol-LblisTCell-symbol $.
IMP-symbol-281-is-pattern $a #Pattern ( \kore-symbol-LblisTCell ptn0 ) $.
IMP-symbol-281-is-sugar $a #Notation ( \kore-symbol-LblisTCell ptn0 ) ( \app \kore-symbol-LblisTCell-symbol ptn0 ) $.
IMP-symbol-281-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisTCell ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisTCellFragment(SortK{}): SortBool{} $)
$c \kore-symbol-LblisTCellFragment \kore-symbol-LblisTCellFragment-symbol $.
IMP-symbol-282-is-symbol $a #Symbol \kore-symbol-LblisTCellFragment-symbol $.
IMP-symbol-282-is-pattern $a #Pattern ( \kore-symbol-LblisTCellFragment ptn0 ) $.
IMP-symbol-282-is-sugar $a #Notation ( \kore-symbol-LblisTCellFragment ptn0 ) ( \app \kore-symbol-LblisTCellFragment-symbol ptn0 ) $.
IMP-symbol-282-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisTCellFragment ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblisTCellOpt(SortK{}): SortBool{} $)
$c \kore-symbol-LblisTCellOpt \kore-symbol-LblisTCellOpt-symbol $.
IMP-symbol-283-is-symbol $a #Symbol \kore-symbol-LblisTCellOpt-symbol $.
IMP-symbol-283-is-pattern $a #Pattern ( \kore-symbol-LblisTCellOpt ptn0 ) $.
IMP-symbol-283-is-sugar $a #Notation ( \kore-symbol-LblisTCellOpt ptn0 ) ( \app \kore-symbol-LblisTCellOpt-symbol ptn0 ) $.
IMP-symbol-283-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-LblisTCellOpt ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map(SortMap{}): SortSet{} $)
$c \kore-symbol-Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map \kore-symbol-Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map-symbol $.
IMP-symbol-284-is-symbol $a #Symbol \kore-symbol-Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map-symbol $.
IMP-symbol-284-is-pattern $a #Pattern ( \kore-symbol-Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map ptn0 ) $.
IMP-symbol-284-is-sugar $a #Notation ( \kore-symbol-Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map ptn0 ) ( \app \kore-symbol-Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map-symbol ptn0 ) $.
IMP-symbol-284-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-Lblkeys'LParUndsRParUnds'MAP'Unds'Set'Unds'Map ptn0 ) \kore-sort-SortSet ) ) $.

$( symbol Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map(SortMap{}): SortList{} $)
$c \kore-symbol-Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map \kore-symbol-Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map-symbol $.
IMP-symbol-285-is-symbol $a #Symbol \kore-symbol-Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map-symbol $.
IMP-symbol-285-is-pattern $a #Pattern ( \kore-symbol-Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map ptn0 ) $.
IMP-symbol-285-is-sugar $a #Notation ( \kore-symbol-Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map ptn0 ) ( \app \kore-symbol-Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map-symbol ptn0 ) $.
IMP-symbol-285-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-Lblkeys'Unds'list'LParUndsRParUnds'MAP'Unds'List'Unds'Map ptn0 ) \kore-sort-SortList ) ) $.

$( symbol LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String(SortString{}): SortInt{} $)
$c \kore-symbol-LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String \kore-symbol-LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol $.
IMP-symbol-286-is-symbol $a #Symbol \kore-symbol-LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol $.
IMP-symbol-286-is-pattern $a #Pattern ( \kore-symbol-LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) $.
IMP-symbol-286-is-sugar $a #Notation ( \kore-symbol-LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) ( \app \kore-symbol-LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol ptn0 ) $.
IMP-symbol-286-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LbllengthString'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int(SortInt{}): SortInt{} $)
$c \kore-symbol-Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int \kore-symbol-Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int-symbol $.
IMP-symbol-287-is-symbol $a #Symbol \kore-symbol-Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int-symbol $.
IMP-symbol-287-is-pattern $a #Pattern ( \kore-symbol-Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int ptn0 ) $.
IMP-symbol-287-is-sugar $a #Notation ( \kore-symbol-Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int ptn0 ) ( \app \kore-symbol-Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int-symbol ptn0 ) $.
IMP-symbol-287-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbllog2Int'LParUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem(SortInt{}, SortKItem{}): SortArray{} $)
$c \kore-symbol-LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem \kore-symbol-LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-288-is-symbol $a #Symbol \kore-symbol-LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-288-is-pattern $a #Pattern ( \kore-symbol-LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem ptn0 ptn1 ) $.
IMP-symbol-288-is-sugar $a #Notation ( \kore-symbol-LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem-symbol ptn0 ) ptn1 ) $.
IMP-symbol-288-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-LblmakeArray'LParUndsCommUndsRParUnds'ARRAY-IN-K'Unds'Array'Unds'Int'Unds'KItem ptn0 ptn1 ) \kore-sort-SortArray ) ) $.

$( symbol LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem(SortInt{}, SortKItem{}): SortList{} $)
$c \kore-symbol-LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem \kore-symbol-LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-289-is-symbol $a #Symbol \kore-symbol-LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem-symbol $.
IMP-symbol-289-is-pattern $a #Pattern ( \kore-symbol-LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ) $.
IMP-symbol-289-is-sugar $a #Notation ( \kore-symbol-LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem-symbol ptn0 ) ptn1 ) $.
IMP-symbol-289-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortKItem ) ) ( \in-sort ( \kore-symbol-LblmakeList'LParUndsCommUndsRParUnds'LIST'Unds'List'Unds'Int'Unds'KItem ptn0 ptn1 ) \kore-sort-SortList ) ) $.

$( symbol LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int \kore-symbol-LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-290-is-symbol $a #Symbol \kore-symbol-LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-290-is-pattern $a #Pattern ( \kore-symbol-LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-290-is-sugar $a #Notation ( \kore-symbol-LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-290-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblmaxInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int(SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int \kore-symbol-LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-291-is-symbol $a #Symbol \kore-symbol-LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-291-is-pattern $a #Pattern ( \kore-symbol-LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) $.
IMP-symbol-291-is-sugar $a #Notation ( \kore-symbol-LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) $.
IMP-symbol-291-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblminInt'LParUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ) \kore-sort-SortInt ) ) $.

$( symbol LblnewUUID'Unds'STRING-COMMON'Unds'String(): SortString{} $)
$c \kore-symbol-LblnewUUID'Unds'STRING-COMMON'Unds'String \kore-symbol-LblnewUUID'Unds'STRING-COMMON'Unds'String-symbol $.
IMP-symbol-292-is-symbol $a #Symbol \kore-symbol-LblnewUUID'Unds'STRING-COMMON'Unds'String-symbol $.
IMP-symbol-292-is-pattern $a #Pattern \kore-symbol-LblnewUUID'Unds'STRING-COMMON'Unds'String $.
IMP-symbol-292-is-sugar $a #Notation \kore-symbol-LblnewUUID'Unds'STRING-COMMON'Unds'String \kore-symbol-LblnewUUID'Unds'STRING-COMMON'Unds'String-symbol $.
IMP-symbol-292-sorting $a |- ( \in-sort \kore-symbol-LblnewUUID'Unds'STRING-COMMON'Unds'String \kore-sort-SortString ) $.

$( symbol LblnoGeneratedCounterCell(): SortGeneratedCounterCellOpt{} $)
$c \kore-symbol-LblnoGeneratedCounterCell \kore-symbol-LblnoGeneratedCounterCell-symbol $.
IMP-symbol-293-is-symbol $a #Symbol \kore-symbol-LblnoGeneratedCounterCell-symbol $.
IMP-symbol-293-is-pattern $a #Pattern \kore-symbol-LblnoGeneratedCounterCell $.
IMP-symbol-293-is-sugar $a #Notation \kore-symbol-LblnoGeneratedCounterCell \kore-symbol-LblnoGeneratedCounterCell-symbol $.
IMP-symbol-293-sorting $a |- ( \in-sort \kore-symbol-LblnoGeneratedCounterCell \kore-sort-SortGeneratedCounterCellOpt ) $.

$( symbol LblnoKCell(): SortKCellOpt{} $)
$c \kore-symbol-LblnoKCell \kore-symbol-LblnoKCell-symbol $.
IMP-symbol-294-is-symbol $a #Symbol \kore-symbol-LblnoKCell-symbol $.
IMP-symbol-294-is-pattern $a #Pattern \kore-symbol-LblnoKCell $.
IMP-symbol-294-is-sugar $a #Notation \kore-symbol-LblnoKCell \kore-symbol-LblnoKCell-symbol $.
IMP-symbol-294-sorting $a |- ( \in-sort \kore-symbol-LblnoKCell \kore-sort-SortKCellOpt ) $.

$( symbol LblnoStateCell(): SortStateCellOpt{} $)
$c \kore-symbol-LblnoStateCell \kore-symbol-LblnoStateCell-symbol $.
IMP-symbol-295-is-symbol $a #Symbol \kore-symbol-LblnoStateCell-symbol $.
IMP-symbol-295-is-pattern $a #Pattern \kore-symbol-LblnoStateCell $.
IMP-symbol-295-is-sugar $a #Notation \kore-symbol-LblnoStateCell \kore-symbol-LblnoStateCell-symbol $.
IMP-symbol-295-sorting $a |- ( \in-sort \kore-symbol-LblnoStateCell \kore-sort-SortStateCellOpt ) $.

$( symbol LblnoTCell(): SortTCellOpt{} $)
$c \kore-symbol-LblnoTCell \kore-symbol-LblnoTCell-symbol $.
IMP-symbol-296-is-symbol $a #Symbol \kore-symbol-LblnoTCell-symbol $.
IMP-symbol-296-is-pattern $a #Pattern \kore-symbol-LblnoTCell $.
IMP-symbol-296-is-sugar $a #Notation \kore-symbol-LblnoTCell \kore-symbol-LblnoTCell-symbol $.
IMP-symbol-296-sorting $a |- ( \in-sort \kore-symbol-LblnoTCell \kore-sort-SortTCellOpt ) $.

$( symbol LblnotBool'Unds'(SortBool{}): SortBool{} $)
$c \kore-symbol-LblnotBool'Unds' \kore-symbol-LblnotBool'Unds'-symbol $.
IMP-symbol-297-is-symbol $a #Symbol \kore-symbol-LblnotBool'Unds'-symbol $.
IMP-symbol-297-is-pattern $a #Pattern ( \kore-symbol-LblnotBool'Unds' ptn0 ) $.
IMP-symbol-297-is-sugar $a #Notation ( \kore-symbol-LblnotBool'Unds' ptn0 ) ( \app \kore-symbol-LblnotBool'Unds'-symbol ptn0 ) $.
IMP-symbol-297-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortBool ) ( \in-sort ( \kore-symbol-LblnotBool'Unds' ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String(SortString{}): SortInt{} $)
$c \kore-symbol-LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String \kore-symbol-LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol $.
IMP-symbol-298-is-symbol $a #Symbol \kore-symbol-LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol $.
IMP-symbol-298-is-pattern $a #Pattern ( \kore-symbol-LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) $.
IMP-symbol-298-is-sugar $a #Notation ( \kore-symbol-LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) ( \app \kore-symbol-LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String-symbol ptn0 ) $.
IMP-symbol-298-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ( \kore-symbol-LblordChar'LParUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblproject'ColnHash'tempFile'Coln'fd(SortIOFile{}): SortInt{} $)
$c \kore-symbol-Lblproject'ColnHash'tempFile'Coln'fd \kore-symbol-Lblproject'ColnHash'tempFile'Coln'fd-symbol $.
IMP-symbol-299-is-symbol $a #Symbol \kore-symbol-Lblproject'ColnHash'tempFile'Coln'fd-symbol $.
IMP-symbol-299-is-pattern $a #Pattern ( \kore-symbol-Lblproject'ColnHash'tempFile'Coln'fd ptn0 ) $.
IMP-symbol-299-is-sugar $a #Notation ( \kore-symbol-Lblproject'ColnHash'tempFile'Coln'fd ptn0 ) ( \app \kore-symbol-Lblproject'ColnHash'tempFile'Coln'fd-symbol ptn0 ) $.
IMP-symbol-299-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortIOFile ) ( \in-sort ( \kore-symbol-Lblproject'ColnHash'tempFile'Coln'fd ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblproject'ColnHash'tempFile'Coln'path(SortIOFile{}): SortString{} $)
$c \kore-symbol-Lblproject'ColnHash'tempFile'Coln'path \kore-symbol-Lblproject'ColnHash'tempFile'Coln'path-symbol $.
IMP-symbol-300-is-symbol $a #Symbol \kore-symbol-Lblproject'ColnHash'tempFile'Coln'path-symbol $.
IMP-symbol-300-is-pattern $a #Pattern ( \kore-symbol-Lblproject'ColnHash'tempFile'Coln'path ptn0 ) $.
IMP-symbol-300-is-sugar $a #Notation ( \kore-symbol-Lblproject'ColnHash'tempFile'Coln'path ptn0 ) ( \app \kore-symbol-Lblproject'ColnHash'tempFile'Coln'path-symbol ptn0 ) $.
IMP-symbol-300-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortIOFile ) ( \in-sort ( \kore-symbol-Lblproject'ColnHash'tempFile'Coln'path ptn0 ) \kore-sort-SortString ) ) $.

$( symbol Lblproject'ColnHash'unknownIOError'Coln'errno(SortIOError{}): SortInt{} $)
$c \kore-symbol-Lblproject'ColnHash'unknownIOError'Coln'errno \kore-symbol-Lblproject'ColnHash'unknownIOError'Coln'errno-symbol $.
IMP-symbol-301-is-symbol $a #Symbol \kore-symbol-Lblproject'ColnHash'unknownIOError'Coln'errno-symbol $.
IMP-symbol-301-is-pattern $a #Pattern ( \kore-symbol-Lblproject'ColnHash'unknownIOError'Coln'errno ptn0 ) $.
IMP-symbol-301-is-sugar $a #Notation ( \kore-symbol-Lblproject'ColnHash'unknownIOError'Coln'errno ptn0 ) ( \app \kore-symbol-Lblproject'ColnHash'unknownIOError'Coln'errno-symbol ptn0 ) $.
IMP-symbol-301-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortIOError ) ( \in-sort ( \kore-symbol-Lblproject'ColnHash'unknownIOError'Coln'errno ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblproject'Coln'AExp(SortK{}): SortAExp{} $)
$c \kore-symbol-Lblproject'Coln'AExp \kore-symbol-Lblproject'Coln'AExp-symbol $.
IMP-symbol-302-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'AExp-symbol $.
IMP-symbol-302-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'AExp ptn0 ) $.
IMP-symbol-302-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'AExp ptn0 ) ( \app \kore-symbol-Lblproject'Coln'AExp-symbol ptn0 ) $.
IMP-symbol-302-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'AExp ptn0 ) \kore-sort-SortAExp ) ) $.

$( symbol Lblproject'Coln'Array(SortK{}): SortArray{} $)
$c \kore-symbol-Lblproject'Coln'Array \kore-symbol-Lblproject'Coln'Array-symbol $.
IMP-symbol-303-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Array-symbol $.
IMP-symbol-303-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Array ptn0 ) $.
IMP-symbol-303-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Array ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Array-symbol ptn0 ) $.
IMP-symbol-303-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Array ptn0 ) \kore-sort-SortArray ) ) $.

$( symbol Lblproject'Coln'BExp(SortK{}): SortBExp{} $)
$c \kore-symbol-Lblproject'Coln'BExp \kore-symbol-Lblproject'Coln'BExp-symbol $.
IMP-symbol-304-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'BExp-symbol $.
IMP-symbol-304-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'BExp ptn0 ) $.
IMP-symbol-304-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'BExp ptn0 ) ( \app \kore-symbol-Lblproject'Coln'BExp-symbol ptn0 ) $.
IMP-symbol-304-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'BExp ptn0 ) \kore-sort-SortBExp ) ) $.

$( symbol Lblproject'Coln'Block(SortK{}): SortBlock{} $)
$c \kore-symbol-Lblproject'Coln'Block \kore-symbol-Lblproject'Coln'Block-symbol $.
IMP-symbol-305-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Block-symbol $.
IMP-symbol-305-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Block ptn0 ) $.
IMP-symbol-305-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Block ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Block-symbol ptn0 ) $.
IMP-symbol-305-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Block ptn0 ) \kore-sort-SortBlock ) ) $.

$( symbol Lblproject'Coln'Bool(SortK{}): SortBool{} $)
$c \kore-symbol-Lblproject'Coln'Bool \kore-symbol-Lblproject'Coln'Bool-symbol $.
IMP-symbol-306-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Bool-symbol $.
IMP-symbol-306-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Bool ptn0 ) $.
IMP-symbol-306-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Bool ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Bool-symbol ptn0 ) $.
IMP-symbol-306-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Bool ptn0 ) \kore-sort-SortBool ) ) $.

$( symbol Lblproject'Coln'Float(SortK{}): SortFloat{} $)
$c \kore-symbol-Lblproject'Coln'Float \kore-symbol-Lblproject'Coln'Float-symbol $.
IMP-symbol-307-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Float-symbol $.
IMP-symbol-307-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Float ptn0 ) $.
IMP-symbol-307-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Float ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Float-symbol ptn0 ) $.
IMP-symbol-307-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Float ptn0 ) \kore-sort-SortFloat ) ) $.

$( symbol Lblproject'Coln'GeneratedCounterCell(SortK{}): SortGeneratedCounterCell{} $)
$c \kore-symbol-Lblproject'Coln'GeneratedCounterCell \kore-symbol-Lblproject'Coln'GeneratedCounterCell-symbol $.
IMP-symbol-308-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'GeneratedCounterCell-symbol $.
IMP-symbol-308-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'GeneratedCounterCell ptn0 ) $.
IMP-symbol-308-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'GeneratedCounterCell ptn0 ) ( \app \kore-symbol-Lblproject'Coln'GeneratedCounterCell-symbol ptn0 ) $.
IMP-symbol-308-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'GeneratedCounterCell ptn0 ) \kore-sort-SortGeneratedCounterCell ) ) $.

$( symbol Lblproject'Coln'GeneratedCounterCellOpt(SortK{}): SortGeneratedCounterCellOpt{} $)
$c \kore-symbol-Lblproject'Coln'GeneratedCounterCellOpt \kore-symbol-Lblproject'Coln'GeneratedCounterCellOpt-symbol $.
IMP-symbol-309-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'GeneratedCounterCellOpt-symbol $.
IMP-symbol-309-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'GeneratedCounterCellOpt ptn0 ) $.
IMP-symbol-309-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'GeneratedCounterCellOpt ptn0 ) ( \app \kore-symbol-Lblproject'Coln'GeneratedCounterCellOpt-symbol ptn0 ) $.
IMP-symbol-309-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'GeneratedCounterCellOpt ptn0 ) \kore-sort-SortGeneratedCounterCellOpt ) ) $.

$( symbol Lblproject'Coln'GeneratedTopCell(SortK{}): SortGeneratedTopCell{} $)
$c \kore-symbol-Lblproject'Coln'GeneratedTopCell \kore-symbol-Lblproject'Coln'GeneratedTopCell-symbol $.
IMP-symbol-310-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'GeneratedTopCell-symbol $.
IMP-symbol-310-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'GeneratedTopCell ptn0 ) $.
IMP-symbol-310-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'GeneratedTopCell ptn0 ) ( \app \kore-symbol-Lblproject'Coln'GeneratedTopCell-symbol ptn0 ) $.
IMP-symbol-310-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'GeneratedTopCell ptn0 ) \kore-sort-SortGeneratedTopCell ) ) $.

$( symbol Lblproject'Coln'GeneratedTopCellFragment(SortK{}): SortGeneratedTopCellFragment{} $)
$c \kore-symbol-Lblproject'Coln'GeneratedTopCellFragment \kore-symbol-Lblproject'Coln'GeneratedTopCellFragment-symbol $.
IMP-symbol-311-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'GeneratedTopCellFragment-symbol $.
IMP-symbol-311-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'GeneratedTopCellFragment ptn0 ) $.
IMP-symbol-311-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'GeneratedTopCellFragment ptn0 ) ( \app \kore-symbol-Lblproject'Coln'GeneratedTopCellFragment-symbol ptn0 ) $.
IMP-symbol-311-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'GeneratedTopCellFragment ptn0 ) \kore-sort-SortGeneratedTopCellFragment ) ) $.

$( symbol Lblproject'Coln'IOError(SortK{}): SortIOError{} $)
$c \kore-symbol-Lblproject'Coln'IOError \kore-symbol-Lblproject'Coln'IOError-symbol $.
IMP-symbol-312-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'IOError-symbol $.
IMP-symbol-312-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'IOError ptn0 ) $.
IMP-symbol-312-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'IOError ptn0 ) ( \app \kore-symbol-Lblproject'Coln'IOError-symbol ptn0 ) $.
IMP-symbol-312-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'IOError ptn0 ) \kore-sort-SortIOError ) ) $.

$( symbol Lblproject'Coln'IOFile(SortK{}): SortIOFile{} $)
$c \kore-symbol-Lblproject'Coln'IOFile \kore-symbol-Lblproject'Coln'IOFile-symbol $.
IMP-symbol-313-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'IOFile-symbol $.
IMP-symbol-313-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'IOFile ptn0 ) $.
IMP-symbol-313-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'IOFile ptn0 ) ( \app \kore-symbol-Lblproject'Coln'IOFile-symbol ptn0 ) $.
IMP-symbol-313-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'IOFile ptn0 ) \kore-sort-SortIOFile ) ) $.

$( symbol Lblproject'Coln'IOInt(SortK{}): SortIOInt{} $)
$c \kore-symbol-Lblproject'Coln'IOInt \kore-symbol-Lblproject'Coln'IOInt-symbol $.
IMP-symbol-314-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'IOInt-symbol $.
IMP-symbol-314-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'IOInt ptn0 ) $.
IMP-symbol-314-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'IOInt ptn0 ) ( \app \kore-symbol-Lblproject'Coln'IOInt-symbol ptn0 ) $.
IMP-symbol-314-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'IOInt ptn0 ) \kore-sort-SortIOInt ) ) $.

$( symbol Lblproject'Coln'IOString(SortK{}): SortIOString{} $)
$c \kore-symbol-Lblproject'Coln'IOString \kore-symbol-Lblproject'Coln'IOString-symbol $.
IMP-symbol-315-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'IOString-symbol $.
IMP-symbol-315-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'IOString ptn0 ) $.
IMP-symbol-315-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'IOString ptn0 ) ( \app \kore-symbol-Lblproject'Coln'IOString-symbol ptn0 ) $.
IMP-symbol-315-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'IOString ptn0 ) \kore-sort-SortIOString ) ) $.

$( symbol Lblproject'Coln'Id(SortK{}): SortId{} $)
$c \kore-symbol-Lblproject'Coln'Id \kore-symbol-Lblproject'Coln'Id-symbol $.
IMP-symbol-316-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Id-symbol $.
IMP-symbol-316-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Id ptn0 ) $.
IMP-symbol-316-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Id ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Id-symbol ptn0 ) $.
IMP-symbol-316-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Id ptn0 ) \kore-sort-SortId ) ) $.

$( symbol Lblproject'Coln'Ids(SortK{}): SortIds{} $)
$c \kore-symbol-Lblproject'Coln'Ids \kore-symbol-Lblproject'Coln'Ids-symbol $.
IMP-symbol-317-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Ids-symbol $.
IMP-symbol-317-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Ids ptn0 ) $.
IMP-symbol-317-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Ids ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Ids-symbol ptn0 ) $.
IMP-symbol-317-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Ids ptn0 ) \kore-sort-SortIds ) ) $.

$( symbol Lblproject'Coln'Int(SortK{}): SortInt{} $)
$c \kore-symbol-Lblproject'Coln'Int \kore-symbol-Lblproject'Coln'Int-symbol $.
IMP-symbol-318-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Int-symbol $.
IMP-symbol-318-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Int ptn0 ) $.
IMP-symbol-318-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Int ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Int-symbol ptn0 ) $.
IMP-symbol-318-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Int ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblproject'Coln'K(SortK{}): SortK{} $)
$c \kore-symbol-Lblproject'Coln'K \kore-symbol-Lblproject'Coln'K-symbol $.
IMP-symbol-319-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'K-symbol $.
IMP-symbol-319-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'K ptn0 ) $.
IMP-symbol-319-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'K ptn0 ) ( \app \kore-symbol-Lblproject'Coln'K-symbol ptn0 ) $.
IMP-symbol-319-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'K ptn0 ) \kore-sort-SortK ) ) $.

$( symbol Lblproject'Coln'KCell(SortK{}): SortKCell{} $)
$c \kore-symbol-Lblproject'Coln'KCell \kore-symbol-Lblproject'Coln'KCell-symbol $.
IMP-symbol-320-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'KCell-symbol $.
IMP-symbol-320-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'KCell ptn0 ) $.
IMP-symbol-320-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'KCell ptn0 ) ( \app \kore-symbol-Lblproject'Coln'KCell-symbol ptn0 ) $.
IMP-symbol-320-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'KCell ptn0 ) \kore-sort-SortKCell ) ) $.

$( symbol Lblproject'Coln'KCellOpt(SortK{}): SortKCellOpt{} $)
$c \kore-symbol-Lblproject'Coln'KCellOpt \kore-symbol-Lblproject'Coln'KCellOpt-symbol $.
IMP-symbol-321-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'KCellOpt-symbol $.
IMP-symbol-321-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'KCellOpt ptn0 ) $.
IMP-symbol-321-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'KCellOpt ptn0 ) ( \app \kore-symbol-Lblproject'Coln'KCellOpt-symbol ptn0 ) $.
IMP-symbol-321-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'KCellOpt ptn0 ) \kore-sort-SortKCellOpt ) ) $.

$( symbol Lblproject'Coln'KItem(SortK{}): SortKItem{} $)
$c \kore-symbol-Lblproject'Coln'KItem \kore-symbol-Lblproject'Coln'KItem-symbol $.
IMP-symbol-322-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'KItem-symbol $.
IMP-symbol-322-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'KItem ptn0 ) $.
IMP-symbol-322-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'KItem ptn0 ) ( \app \kore-symbol-Lblproject'Coln'KItem-symbol ptn0 ) $.
IMP-symbol-322-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'KItem ptn0 ) \kore-sort-SortKItem ) ) $.

$( symbol Lblproject'Coln'KResult(SortK{}): SortKResult{} $)
$c \kore-symbol-Lblproject'Coln'KResult \kore-symbol-Lblproject'Coln'KResult-symbol $.
IMP-symbol-323-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'KResult-symbol $.
IMP-symbol-323-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'KResult ptn0 ) $.
IMP-symbol-323-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'KResult ptn0 ) ( \app \kore-symbol-Lblproject'Coln'KResult-symbol ptn0 ) $.
IMP-symbol-323-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'KResult ptn0 ) \kore-sort-SortKResult ) ) $.

$( symbol Lblproject'Coln'List(SortK{}): SortList{} $)
$c \kore-symbol-Lblproject'Coln'List \kore-symbol-Lblproject'Coln'List-symbol $.
IMP-symbol-324-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'List-symbol $.
IMP-symbol-324-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'List ptn0 ) $.
IMP-symbol-324-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'List ptn0 ) ( \app \kore-symbol-Lblproject'Coln'List-symbol ptn0 ) $.
IMP-symbol-324-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'List ptn0 ) \kore-sort-SortList ) ) $.

$( symbol Lblproject'Coln'Map(SortK{}): SortMap{} $)
$c \kore-symbol-Lblproject'Coln'Map \kore-symbol-Lblproject'Coln'Map-symbol $.
IMP-symbol-325-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Map-symbol $.
IMP-symbol-325-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Map ptn0 ) $.
IMP-symbol-325-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Map ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Map-symbol ptn0 ) $.
IMP-symbol-325-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Map ptn0 ) \kore-sort-SortMap ) ) $.

$( symbol Lblproject'Coln'Pgm(SortK{}): SortPgm{} $)
$c \kore-symbol-Lblproject'Coln'Pgm \kore-symbol-Lblproject'Coln'Pgm-symbol $.
IMP-symbol-326-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Pgm-symbol $.
IMP-symbol-326-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Pgm ptn0 ) $.
IMP-symbol-326-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Pgm ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Pgm-symbol ptn0 ) $.
IMP-symbol-326-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Pgm ptn0 ) \kore-sort-SortPgm ) ) $.

$( symbol Lblproject'Coln'Set(SortK{}): SortSet{} $)
$c \kore-symbol-Lblproject'Coln'Set \kore-symbol-Lblproject'Coln'Set-symbol $.
IMP-symbol-327-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Set-symbol $.
IMP-symbol-327-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Set ptn0 ) $.
IMP-symbol-327-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Set ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Set-symbol ptn0 ) $.
IMP-symbol-327-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Set ptn0 ) \kore-sort-SortSet ) ) $.

$( symbol Lblproject'Coln'StateCell(SortK{}): SortStateCell{} $)
$c \kore-symbol-Lblproject'Coln'StateCell \kore-symbol-Lblproject'Coln'StateCell-symbol $.
IMP-symbol-328-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'StateCell-symbol $.
IMP-symbol-328-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'StateCell ptn0 ) $.
IMP-symbol-328-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'StateCell ptn0 ) ( \app \kore-symbol-Lblproject'Coln'StateCell-symbol ptn0 ) $.
IMP-symbol-328-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'StateCell ptn0 ) \kore-sort-SortStateCell ) ) $.

$( symbol Lblproject'Coln'StateCellOpt(SortK{}): SortStateCellOpt{} $)
$c \kore-symbol-Lblproject'Coln'StateCellOpt \kore-symbol-Lblproject'Coln'StateCellOpt-symbol $.
IMP-symbol-329-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'StateCellOpt-symbol $.
IMP-symbol-329-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'StateCellOpt ptn0 ) $.
IMP-symbol-329-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'StateCellOpt ptn0 ) ( \app \kore-symbol-Lblproject'Coln'StateCellOpt-symbol ptn0 ) $.
IMP-symbol-329-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'StateCellOpt ptn0 ) \kore-sort-SortStateCellOpt ) ) $.

$( symbol Lblproject'Coln'Stmt(SortK{}): SortStmt{} $)
$c \kore-symbol-Lblproject'Coln'Stmt \kore-symbol-Lblproject'Coln'Stmt-symbol $.
IMP-symbol-330-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Stmt-symbol $.
IMP-symbol-330-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Stmt ptn0 ) $.
IMP-symbol-330-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Stmt ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Stmt-symbol ptn0 ) $.
IMP-symbol-330-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Stmt ptn0 ) \kore-sort-SortStmt ) ) $.

$( symbol Lblproject'Coln'Stream(SortK{}): SortStream{} $)
$c \kore-symbol-Lblproject'Coln'Stream \kore-symbol-Lblproject'Coln'Stream-symbol $.
IMP-symbol-331-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'Stream-symbol $.
IMP-symbol-331-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'Stream ptn0 ) $.
IMP-symbol-331-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'Stream ptn0 ) ( \app \kore-symbol-Lblproject'Coln'Stream-symbol ptn0 ) $.
IMP-symbol-331-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'Stream ptn0 ) \kore-sort-SortStream ) ) $.

$( symbol Lblproject'Coln'String(SortK{}): SortString{} $)
$c \kore-symbol-Lblproject'Coln'String \kore-symbol-Lblproject'Coln'String-symbol $.
IMP-symbol-332-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'String-symbol $.
IMP-symbol-332-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'String ptn0 ) $.
IMP-symbol-332-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'String ptn0 ) ( \app \kore-symbol-Lblproject'Coln'String-symbol ptn0 ) $.
IMP-symbol-332-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'String ptn0 ) \kore-sort-SortString ) ) $.

$( symbol Lblproject'Coln'TCell(SortK{}): SortTCell{} $)
$c \kore-symbol-Lblproject'Coln'TCell \kore-symbol-Lblproject'Coln'TCell-symbol $.
IMP-symbol-333-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'TCell-symbol $.
IMP-symbol-333-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'TCell ptn0 ) $.
IMP-symbol-333-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'TCell ptn0 ) ( \app \kore-symbol-Lblproject'Coln'TCell-symbol ptn0 ) $.
IMP-symbol-333-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'TCell ptn0 ) \kore-sort-SortTCell ) ) $.

$( symbol Lblproject'Coln'TCellFragment(SortK{}): SortTCellFragment{} $)
$c \kore-symbol-Lblproject'Coln'TCellFragment \kore-symbol-Lblproject'Coln'TCellFragment-symbol $.
IMP-symbol-334-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'TCellFragment-symbol $.
IMP-symbol-334-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'TCellFragment ptn0 ) $.
IMP-symbol-334-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'TCellFragment ptn0 ) ( \app \kore-symbol-Lblproject'Coln'TCellFragment-symbol ptn0 ) $.
IMP-symbol-334-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'TCellFragment ptn0 ) \kore-sort-SortTCellFragment ) ) $.

$( symbol Lblproject'Coln'TCellOpt(SortK{}): SortTCellOpt{} $)
$c \kore-symbol-Lblproject'Coln'TCellOpt \kore-symbol-Lblproject'Coln'TCellOpt-symbol $.
IMP-symbol-335-is-symbol $a #Symbol \kore-symbol-Lblproject'Coln'TCellOpt-symbol $.
IMP-symbol-335-is-pattern $a #Pattern ( \kore-symbol-Lblproject'Coln'TCellOpt ptn0 ) $.
IMP-symbol-335-is-sugar $a #Notation ( \kore-symbol-Lblproject'Coln'TCellOpt ptn0 ) ( \app \kore-symbol-Lblproject'Coln'TCellOpt-symbol ptn0 ) $.
IMP-symbol-335-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortK ) ( \in-sort ( \kore-symbol-Lblproject'Coln'TCellOpt ptn0 ) \kore-sort-SortTCellOpt ) ) $.

$( symbol LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int(SortInt{}): SortInt{} $)
$c \kore-symbol-LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int \kore-symbol-LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int-symbol $.
IMP-symbol-336-is-symbol $a #Symbol \kore-symbol-LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int-symbol $.
IMP-symbol-336-is-pattern $a #Pattern ( \kore-symbol-LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int ptn0 ) $.
IMP-symbol-336-is-sugar $a #Notation ( \kore-symbol-LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int ptn0 ) ( \app \kore-symbol-LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int-symbol ptn0 ) $.
IMP-symbol-336-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-LblrandInt'LParUndsRParUnds'INT'Unds'Int'Unds'Int ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set(SortMap{}, SortSet{}): SortMap{} $)
$c \kore-symbol-LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set \kore-symbol-LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set-symbol $.
IMP-symbol-337-is-symbol $a #Symbol \kore-symbol-LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set-symbol $.
IMP-symbol-337-is-pattern $a #Pattern ( \kore-symbol-LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set ptn0 ptn1 ) $.
IMP-symbol-337-is-sugar $a #Notation ( \kore-symbol-LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set-symbol ptn0 ) ptn1 ) $.
IMP-symbol-337-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortSet ) ) ( \in-sort ( \kore-symbol-LblremoveAll'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Set ptn0 ptn1 ) \kore-sort-SortMap ) ) $.

$( symbol Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int(SortString{}, SortString{}, SortString{}, SortInt{}): SortString{} $)
$c \kore-symbol-Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int \kore-symbol-Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-338-is-symbol $a #Symbol \kore-symbol-Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-338-is-pattern $a #Pattern ( \kore-symbol-Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ptn3 ) $.
IMP-symbol-338-is-sugar $a #Notation ( \kore-symbol-Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ptn3 ) ( \app ( \app ( \app ( \app \kore-symbol-Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) ptn3 ) $.
IMP-symbol-338-sorting $a |- ( \imp ( \and ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortString ) ) ( \in-sort ptn3 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-Lblreplace'LParUndsCommUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ptn3 ) \kore-sort-SortString ) ) $.

$( symbol LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String(SortString{}, SortString{}, SortString{}): SortString{} $)
$c \kore-symbol-LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String \kore-symbol-LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String-symbol $.
IMP-symbol-339-is-symbol $a #Symbol \kore-symbol-LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String-symbol $.
IMP-symbol-339-is-pattern $a #Pattern ( \kore-symbol-LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String ptn0 ptn1 ptn2 ) $.
IMP-symbol-339-is-sugar $a #Notation ( \kore-symbol-LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-339-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-LblreplaceAll'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String ptn0 ptn1 ptn2 ) \kore-sort-SortString ) ) $.

$( symbol LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String(SortString{}, SortString{}, SortString{}): SortString{} $)
$c \kore-symbol-LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String \kore-symbol-LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String-symbol $.
IMP-symbol-340-is-symbol $a #Symbol \kore-symbol-LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String-symbol $.
IMP-symbol-340-is-pattern $a #Pattern ( \kore-symbol-LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String ptn0 ptn1 ptn2 ) $.
IMP-symbol-340-is-sugar $a #Notation ( \kore-symbol-LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-340-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortString ) ) ( \in-sort ( \kore-symbol-LblreplaceFirst'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'String'Unds'String ptn0 ptn1 ptn2 ) \kore-sort-SortString ) ) $.

$( symbol LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int(SortString{}, SortString{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int \kore-symbol-LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-341-is-symbol $a #Symbol \kore-symbol-LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-341-is-pattern $a #Pattern ( \kore-symbol-LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) $.
IMP-symbol-341-is-sugar $a #Notation ( \kore-symbol-LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-341-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblrfindChar'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) \kore-sort-SortInt ) ) $.

$( symbol LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int(SortString{}, SortString{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int \kore-symbol-LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-342-is-symbol $a #Symbol \kore-symbol-LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol $.
IMP-symbol-342-is-pattern $a #Pattern ( \kore-symbol-LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) $.
IMP-symbol-342-is-sugar $a #Notation ( \kore-symbol-LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-342-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortString ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblrfindString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'Int'Unds'String'Unds'String'Unds'Int ptn0 ptn1 ptn2 ) \kore-sort-SortInt ) ) $.

$( symbol LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int(SortInt{}, SortInt{}, SortInt{}): SortInt{} $)
$c \kore-symbol-LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int \kore-symbol-LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-343-is-symbol $a #Symbol \kore-symbol-LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int-symbol $.
IMP-symbol-343-is-pattern $a #Pattern ( \kore-symbol-LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) $.
IMP-symbol-343-is-sugar $a #Notation ( \kore-symbol-LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-343-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblsignExtendBitRangeInt'LParUndsCommUndsCommUndsRParUnds'INT-COMMON'Unds'Int'Unds'Int'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) \kore-sort-SortInt ) ) $.

$( symbol Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List(SortList{}): SortInt{} $)
$c \kore-symbol-Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List \kore-symbol-Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List-symbol $.
IMP-symbol-344-is-symbol $a #Symbol \kore-symbol-Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List-symbol $.
IMP-symbol-344-is-pattern $a #Pattern ( \kore-symbol-Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List ptn0 ) $.
IMP-symbol-344-is-sugar $a #Notation ( \kore-symbol-Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List ptn0 ) ( \app \kore-symbol-Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List-symbol ptn0 ) $.
IMP-symbol-344-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ( \kore-symbol-Lblsize'LParUndsRParUnds'LIST'Unds'Int'Unds'List ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map(SortMap{}): SortInt{} $)
$c \kore-symbol-Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map \kore-symbol-Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map-symbol $.
IMP-symbol-345-is-symbol $a #Symbol \kore-symbol-Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map-symbol $.
IMP-symbol-345-is-pattern $a #Pattern ( \kore-symbol-Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map ptn0 ) $.
IMP-symbol-345-is-sugar $a #Notation ( \kore-symbol-Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map ptn0 ) ( \app \kore-symbol-Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map-symbol ptn0 ) $.
IMP-symbol-345-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-Lblsize'LParUndsRParUnds'MAP'Unds'Int'Unds'Map ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set(SortSet{}): SortInt{} $)
$c \kore-symbol-Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set \kore-symbol-Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set-symbol $.
IMP-symbol-346-is-symbol $a #Symbol \kore-symbol-Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set-symbol $.
IMP-symbol-346-is-pattern $a #Pattern ( \kore-symbol-Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set ptn0 ) $.
IMP-symbol-346-is-sugar $a #Notation ( \kore-symbol-Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set ptn0 ) ( \app \kore-symbol-Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set-symbol ptn0 ) $.
IMP-symbol-346-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortSet ) ( \in-sort ( \kore-symbol-Lblsize'LParUndsRParUnds'SET'Unds'Int'Unds'Set ptn0 ) \kore-sort-SortInt ) ) $.

$( symbol LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int(SortInt{}): SortK{} $)
$c \kore-symbol-LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int \kore-symbol-LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int-symbol $.
IMP-symbol-347-is-symbol $a #Symbol \kore-symbol-LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int-symbol $.
IMP-symbol-347-is-pattern $a #Pattern ( \kore-symbol-LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int ptn0 ) $.
IMP-symbol-347-is-sugar $a #Notation ( \kore-symbol-LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int ptn0 ) ( \app \kore-symbol-LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int-symbol ptn0 ) $.
IMP-symbol-347-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-LblsrandInt'LParUndsRParUnds'INT'Unds'K'Unds'Int ptn0 ) \kore-sort-SortK ) ) $.

$( symbol LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int(SortString{}, SortInt{}, SortInt{}): SortString{} $)
$c \kore-symbol-LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int \kore-symbol-LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int-symbol $.
IMP-symbol-348-is-symbol $a #Symbol \kore-symbol-LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int-symbol $.
IMP-symbol-348-is-pattern $a #Pattern ( \kore-symbol-LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) $.
IMP-symbol-348-is-sugar $a #Notation ( \kore-symbol-LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-348-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortString ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortInt ) ) ( \in-sort ( \kore-symbol-LblsubstrString'LParUndsCommUndsCommUndsRParUnds'STRING-COMMON'Unds'String'Unds'String'Unds'Int'Unds'Int ptn0 ptn1 ptn2 ) \kore-sort-SortString ) ) $.

$( symbol LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List(SortArray{}, SortInt{}, SortList{}): SortArray{} $)
$c \kore-symbol-LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List \kore-symbol-LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List-symbol $.
IMP-symbol-349-is-symbol $a #Symbol \kore-symbol-LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List-symbol $.
IMP-symbol-349-is-pattern $a #Pattern ( \kore-symbol-LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List ptn0 ptn1 ptn2 ) $.
IMP-symbol-349-is-sugar $a #Notation ( \kore-symbol-LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-349-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortArray ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortList ) ) ( \in-sort ( \kore-symbol-LblupdateArray'LParUndsCommUndsCommUndsRParUnds'ARRAY-SYNTAX'Unds'Array'Unds'Array'Unds'Int'Unds'List ptn0 ptn1 ptn2 ) \kore-sort-SortArray ) ) $.

$( symbol LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List(SortList{}, SortInt{}, SortList{}): SortList{} $)
$c \kore-symbol-LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List \kore-symbol-LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List-symbol $.
IMP-symbol-350-is-symbol $a #Symbol \kore-symbol-LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List-symbol $.
IMP-symbol-350-is-pattern $a #Pattern ( \kore-symbol-LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List ptn0 ptn1 ptn2 ) $.
IMP-symbol-350-is-sugar $a #Notation ( \kore-symbol-LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List ptn0 ptn1 ptn2 ) ( \app ( \app ( \app \kore-symbol-LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List-symbol ptn0 ) ptn1 ) ptn2 ) $.
IMP-symbol-350-sorting $a |- ( \imp ( \and ( \and ( \in-sort ptn0 \kore-sort-SortList ) ( \in-sort ptn1 \kore-sort-SortInt ) ) ( \in-sort ptn2 \kore-sort-SortList ) ) ( \in-sort ( \kore-symbol-LblupdateList'LParUndsCommUndsCommUndsRParUnds'LIST'Unds'List'Unds'List'Unds'Int'Unds'List ptn0 ptn1 ptn2 ) \kore-sort-SortList ) ) $.

$( symbol LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map(SortMap{}, SortMap{}): SortMap{} $)
$c \kore-symbol-LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map \kore-symbol-LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map-symbol $.
IMP-symbol-351-is-symbol $a #Symbol \kore-symbol-LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map-symbol $.
IMP-symbol-351-is-pattern $a #Pattern ( \kore-symbol-LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map ptn0 ptn1 ) $.
IMP-symbol-351-is-sugar $a #Notation ( \kore-symbol-LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map-symbol ptn0 ) ptn1 ) $.
IMP-symbol-351-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ptn1 \kore-sort-SortMap ) ) ( \in-sort ( \kore-symbol-LblupdateMap'LParUndsCommUndsRParUnds'MAP'Unds'Map'Unds'Map'Unds'Map ptn0 ptn1 ) \kore-sort-SortMap ) ) $.

$( symbol Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map(SortMap{}): SortList{} $)
$c \kore-symbol-Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map \kore-symbol-Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map-symbol $.
IMP-symbol-352-is-symbol $a #Symbol \kore-symbol-Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map-symbol $.
IMP-symbol-352-is-pattern $a #Pattern ( \kore-symbol-Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map ptn0 ) $.
IMP-symbol-352-is-sugar $a #Notation ( \kore-symbol-Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map ptn0 ) ( \app \kore-symbol-Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map-symbol ptn0 ) $.
IMP-symbol-352-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortMap ) ( \in-sort ( \kore-symbol-Lblvalues'LParUndsRParUnds'MAP'Unds'List'Unds'Map ptn0 ) \kore-sort-SortList ) ) $.

$( symbol Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block(SortBExp{}, SortBlock{}): SortStmt{} $)
$c \kore-symbol-Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block \kore-symbol-Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block-symbol $.
IMP-symbol-353-is-symbol $a #Symbol \kore-symbol-Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block-symbol $.
IMP-symbol-353-is-pattern $a #Pattern ( \kore-symbol-Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block ptn0 ptn1 ) $.
IMP-symbol-353-is-sugar $a #Notation ( \kore-symbol-Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block ptn0 ptn1 ) ( \app ( \app \kore-symbol-Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block-symbol ptn0 ) ptn1 ) $.
IMP-symbol-353-sorting $a |- ( \imp ( \and ( \in-sort ptn0 \kore-sort-SortBExp ) ( \in-sort ptn1 \kore-sort-SortBlock ) ) ( \in-sort ( \kore-symbol-Lblwhile'LParUndsRParUndsUnds'IMP-SYNTAX'Unds'Stmt'Unds'BExp'Unds'Block ptn0 ptn1 ) \kore-sort-SortStmt ) ) $.

$( symbol Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt(SortStmt{}): SortBlock{} $)
$c \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt-symbol $.
IMP-symbol-354-is-symbol $a #Symbol \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt-symbol $.
IMP-symbol-354-is-pattern $a #Pattern ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ptn0 ) $.
IMP-symbol-354-is-sugar $a #Notation ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ptn0 ) ( \app \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt-symbol ptn0 ) $.
IMP-symbol-354-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortStmt ) ( \in-sort ( \kore-symbol-Lbl'LBraUndsRBraUnds'IMP-SYNTAX'Unds'Block'Unds'Stmt ptn0 ) \kore-sort-SortBlock ) ) $.

$( symbol Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block(): SortBlock{} $)
$c \kore-symbol-Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block \kore-symbol-Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block-symbol $.
IMP-symbol-355-is-symbol $a #Symbol \kore-symbol-Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block-symbol $.
IMP-symbol-355-is-pattern $a #Pattern \kore-symbol-Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block $.
IMP-symbol-355-is-sugar $a #Notation \kore-symbol-Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block \kore-symbol-Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block-symbol $.
IMP-symbol-355-sorting $a |- ( \in-sort \kore-symbol-Lbl'LBraRBraUnds'IMP-SYNTAX'Unds'Block \kore-sort-SortBlock ) $.

$( symbol Lbl'Tild'Int'Unds'(SortInt{}): SortInt{} $)
$c \kore-symbol-Lbl'Tild'Int'Unds' \kore-symbol-Lbl'Tild'Int'Unds'-symbol $.
IMP-symbol-356-is-symbol $a #Symbol \kore-symbol-Lbl'Tild'Int'Unds'-symbol $.
IMP-symbol-356-is-pattern $a #Pattern ( \kore-symbol-Lbl'Tild'Int'Unds' ptn0 ) $.
IMP-symbol-356-is-sugar $a #Notation ( \kore-symbol-Lbl'Tild'Int'Unds' ptn0 ) ( \app \kore-symbol-Lbl'Tild'Int'Unds'-symbol ptn0 ) $.
IMP-symbol-356-sorting $a |- ( \imp ( \in-sort ptn0 \kore-sort-SortInt ) ( \in-sort ( \kore-symbol-Lbl'Tild'Int'Unds' ptn0 ) \kore-sort-SortInt ) ) $.
