$[ /home/xc93/csl-demo/theory/prelude.mm $]

$( adding 1 new metavariable(s) $)
$v xX0 $.
xX0-variable $f #Variable xX0 $.

$( adding 1 new metavariable(s) $)
$v ptn0 $.
ptn0-pattern $f #Pattern ptn0 $.

$( adding 1 new metavariable(s) $)
$v ptn1 $.
ptn1-pattern $f #Pattern ptn1 $.

$( adding 3 new metavariable(s) $)
$v ptn2 ptn3 ptn4 $.
ptn2-pattern $f #Pattern ptn2 $.
ptn3-pattern $f #Pattern ptn3 $.
ptn4-pattern $f #Pattern ptn4 $.

$( adding 4 new metavariable(s) $)
$v kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 $.
kore-sort-var-R-elementvariable $f #ElementVariable kore-sort-var-R $.
kore-element-var-VE0-elementvariable $f #ElementVariable kore-element-var-VE0 $.
kore-element-var-VE1-elementvariable $f #ElementVariable kore-element-var-VE1 $.
kore-element-var-VE2-elementvariable $f #ElementVariable kore-element-var-VE2 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 $.

$( adding 2 new metavariable(s) $)
$v kore-element-var-VE4 kore-element-var-VE3 $.
kore-element-var-VE4-elementvariable $f #ElementVariable kore-element-var-VE4 $.
kore-element-var-VE3-elementvariable $f #ElementVariable kore-element-var-VE3 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 $.

$( adding 3 new metavariable(s) $)
$v kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 $.
kore-element-var-V0-elementvariable $f #ElementVariable kore-element-var-V0 $.
kore-element-var-V1-elementvariable $f #ElementVariable kore-element-var-V1 $.
kore-element-var-V2-elementvariable $f #ElementVariable kore-element-var-V2 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 $.

$( adding 1 new metavariable(s) $)
$v kore-sort-var-To $.
kore-sort-var-To-elementvariable $f #ElementVariable kore-sort-var-To $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To $.

$( adding 1 new metavariable(s) $)
$v kore-sort-var-From $.
kore-sort-var-From-elementvariable $f #ElementVariable kore-sort-var-From $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From $.

$( adding 4 new metavariable(s) $)
$v ptn5 ptn6 ptn7 ptn8 $.
ptn5-pattern $f #Pattern ptn5 $.
ptn6-pattern $f #Pattern ptn6 $.
ptn7-pattern $f #Pattern ptn7 $.
ptn8-pattern $f #Pattern ptn8 $.

$( adding 1 new metavariable(s) $)
$v kore-sort-var-SortSort $.
kore-sort-var-SortSort-elementvariable $f #ElementVariable kore-sort-var-SortSort $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort $.

$( adding 2 new metavariable(s) $)
$v kore-element-var-Val kore-element-var-From $.
kore-element-var-Val-elementvariable $f #ElementVariable kore-element-var-Val $.
kore-element-var-From-elementvariable $f #ElementVariable kore-element-var-From $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-K0 $.
kore-element-var-K0-elementvariable $f #ElementVariable kore-element-var-K0 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-K1 $.
kore-element-var-K1-elementvariable $f #ElementVariable kore-element-var-K1 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-K2 $.
kore-element-var-K2-elementvariable $f #ElementVariable kore-element-var-K2 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-K3 $.
kore-element-var-K3-elementvariable $f #ElementVariable kore-element-var-K3 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-K $.
kore-element-var-K-elementvariable $f #ElementVariable kore-element-var-K $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K $.

$( adding 3 new metavariable(s) $)
$v kore-sort-var-Q0 kore-element-var-VS0 kore-element-var-VS1 $.
kore-sort-var-Q0-elementvariable $f #ElementVariable kore-sort-var-Q0 $.
kore-element-var-VS0-setvariable $f #SetVariable kore-element-var-VS0 $.
kore-element-var-VS1-setvariable $f #SetVariable kore-element-var-VS1 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 $.

$( adding 2 new metavariable(s) $)
$v kore-sort-var-x0 kore-element-var-x1 $.
kore-sort-var-x0-elementvariable $f #ElementVariable kore-sort-var-x0 $.
kore-element-var-x1-elementvariable $f #ElementVariable kore-element-var-x1 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-VE5 $.
kore-element-var-VE5-elementvariable $f #ElementVariable kore-element-var-VE5 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 kore-element-var-VE5 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-VE6 $.
kore-element-var-VE6-elementvariable $f #ElementVariable kore-element-var-VE6 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 kore-element-var-VE5 kore-element-var-VE6 $.

$( adding 29 new metavariable(s) $)
$v kore-element-var-VE15 kore-element-var-VE11 kore-element-var-VE29 kore-element-var-VE25 kore-element-var-VE16 kore-element-var-VE17 kore-element-var-VE7 kore-element-var-VE18 kore-element-var-VE21 kore-element-var-VE19 kore-element-var-VE30 kore-element-var-VE27 kore-element-var-VE24 kore-element-var-VE31 kore-element-var-VE23 kore-element-var-VE8 kore-element-var-VE32 kore-element-var-VE35 kore-element-var-VE10 kore-element-var-VE28 kore-element-var-VE12 kore-element-var-VE34 kore-element-var-VE20 kore-element-var-VE13 kore-element-var-VE33 kore-element-var-VE14 kore-element-var-VE22 kore-element-var-VE9 kore-element-var-VE26 $.
kore-element-var-VE15-elementvariable $f #ElementVariable kore-element-var-VE15 $.
kore-element-var-VE11-elementvariable $f #ElementVariable kore-element-var-VE11 $.
kore-element-var-VE29-elementvariable $f #ElementVariable kore-element-var-VE29 $.
kore-element-var-VE25-elementvariable $f #ElementVariable kore-element-var-VE25 $.
kore-element-var-VE16-elementvariable $f #ElementVariable kore-element-var-VE16 $.
kore-element-var-VE17-elementvariable $f #ElementVariable kore-element-var-VE17 $.
kore-element-var-VE7-elementvariable $f #ElementVariable kore-element-var-VE7 $.
kore-element-var-VE18-elementvariable $f #ElementVariable kore-element-var-VE18 $.
kore-element-var-VE21-elementvariable $f #ElementVariable kore-element-var-VE21 $.
kore-element-var-VE19-elementvariable $f #ElementVariable kore-element-var-VE19 $.
kore-element-var-VE30-elementvariable $f #ElementVariable kore-element-var-VE30 $.
kore-element-var-VE27-elementvariable $f #ElementVariable kore-element-var-VE27 $.
kore-element-var-VE24-elementvariable $f #ElementVariable kore-element-var-VE24 $.
kore-element-var-VE31-elementvariable $f #ElementVariable kore-element-var-VE31 $.
kore-element-var-VE23-elementvariable $f #ElementVariable kore-element-var-VE23 $.
kore-element-var-VE8-elementvariable $f #ElementVariable kore-element-var-VE8 $.
kore-element-var-VE32-elementvariable $f #ElementVariable kore-element-var-VE32 $.
kore-element-var-VE35-elementvariable $f #ElementVariable kore-element-var-VE35 $.
kore-element-var-VE10-elementvariable $f #ElementVariable kore-element-var-VE10 $.
kore-element-var-VE28-elementvariable $f #ElementVariable kore-element-var-VE28 $.
kore-element-var-VE12-elementvariable $f #ElementVariable kore-element-var-VE12 $.
kore-element-var-VE34-elementvariable $f #ElementVariable kore-element-var-VE34 $.
kore-element-var-VE20-elementvariable $f #ElementVariable kore-element-var-VE20 $.
kore-element-var-VE13-elementvariable $f #ElementVariable kore-element-var-VE13 $.
kore-element-var-VE33-elementvariable $f #ElementVariable kore-element-var-VE33 $.
kore-element-var-VE14-elementvariable $f #ElementVariable kore-element-var-VE14 $.
kore-element-var-VE22-elementvariable $f #ElementVariable kore-element-var-VE22 $.
kore-element-var-VE9-elementvariable $f #ElementVariable kore-element-var-VE9 $.
kore-element-var-VE26-elementvariable $f #ElementVariable kore-element-var-VE26 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 kore-element-var-VE5 kore-element-var-VE6 kore-element-var-VE15 kore-element-var-VE11 kore-element-var-VE29 kore-element-var-VE25 kore-element-var-VE16 kore-element-var-VE17 kore-element-var-VE7 kore-element-var-VE18 kore-element-var-VE21 kore-element-var-VE19 kore-element-var-VE30 kore-element-var-VE27 kore-element-var-VE24 kore-element-var-VE31 kore-element-var-VE23 kore-element-var-VE8 kore-element-var-VE32 kore-element-var-VE35 kore-element-var-VE10 kore-element-var-VE28 kore-element-var-VE12 kore-element-var-VE34 kore-element-var-VE20 kore-element-var-VE13 kore-element-var-VE33 kore-element-var-VE14 kore-element-var-VE22 kore-element-var-VE9 kore-element-var-VE26 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-VS2 $.
kore-element-var-VS2-setvariable $f #SetVariable kore-element-var-VS2 $.

$( adding 4 new metavariable(s) $)
$v kore-sort-var-S3 kore-sort-var-S2 kore-sort-var-S1 kore-element-var-T $.
kore-sort-var-S3-elementvariable $f #ElementVariable kore-sort-var-S3 $.
kore-sort-var-S2-elementvariable $f #ElementVariable kore-sort-var-S2 $.
kore-sort-var-S1-elementvariable $f #ElementVariable kore-sort-var-S1 $.
kore-element-var-T-elementvariable $f #ElementVariable kore-element-var-T $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 kore-element-var-VE5 kore-element-var-VE6 kore-element-var-VE15 kore-element-var-VE11 kore-element-var-VE29 kore-element-var-VE25 kore-element-var-VE16 kore-element-var-VE17 kore-element-var-VE7 kore-element-var-VE18 kore-element-var-VE21 kore-element-var-VE19 kore-element-var-VE30 kore-element-var-VE27 kore-element-var-VE24 kore-element-var-VE31 kore-element-var-VE23 kore-element-var-VE8 kore-element-var-VE32 kore-element-var-VE35 kore-element-var-VE10 kore-element-var-VE28 kore-element-var-VE12 kore-element-var-VE34 kore-element-var-VE20 kore-element-var-VE13 kore-element-var-VE33 kore-element-var-VE14 kore-element-var-VE22 kore-element-var-VE9 kore-element-var-VE26 kore-sort-var-S3 kore-sort-var-S2 kore-sort-var-S1 kore-element-var-T $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-x0 $.
kore-element-var-x0-elementvariable $f #ElementVariable kore-element-var-x0 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 kore-element-var-VE5 kore-element-var-VE6 kore-element-var-VE15 kore-element-var-VE11 kore-element-var-VE29 kore-element-var-VE25 kore-element-var-VE16 kore-element-var-VE17 kore-element-var-VE7 kore-element-var-VE18 kore-element-var-VE21 kore-element-var-VE19 kore-element-var-VE30 kore-element-var-VE27 kore-element-var-VE24 kore-element-var-VE31 kore-element-var-VE23 kore-element-var-VE8 kore-element-var-VE32 kore-element-var-VE35 kore-element-var-VE10 kore-element-var-VE28 kore-element-var-VE12 kore-element-var-VE34 kore-element-var-VE20 kore-element-var-VE13 kore-element-var-VE33 kore-element-var-VE14 kore-element-var-VE22 kore-element-var-VE9 kore-element-var-VE26 kore-sort-var-S3 kore-sort-var-S2 kore-sort-var-S1 kore-element-var-T kore-element-var-x0 $.

$( adding 1 new metavariable(s) $)
$v kore-element-var-x2 $.
kore-element-var-x2-elementvariable $f #ElementVariable kore-element-var-x2 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 kore-element-var-VE5 kore-element-var-VE6 kore-element-var-VE15 kore-element-var-VE11 kore-element-var-VE29 kore-element-var-VE25 kore-element-var-VE16 kore-element-var-VE17 kore-element-var-VE7 kore-element-var-VE18 kore-element-var-VE21 kore-element-var-VE19 kore-element-var-VE30 kore-element-var-VE27 kore-element-var-VE24 kore-element-var-VE31 kore-element-var-VE23 kore-element-var-VE8 kore-element-var-VE32 kore-element-var-VE35 kore-element-var-VE10 kore-element-var-VE28 kore-element-var-VE12 kore-element-var-VE34 kore-element-var-VE20 kore-element-var-VE13 kore-element-var-VE33 kore-element-var-VE14 kore-element-var-VE22 kore-element-var-VE9 kore-element-var-VE26 kore-sort-var-S3 kore-sort-var-S2 kore-sort-var-S1 kore-element-var-T kore-element-var-x0 kore-element-var-x2 $.

$( adding 1 new metavariable(s) $)
$v kore-sort-var-x1 $.
kore-sort-var-x1-elementvariable $f #ElementVariable kore-sort-var-x1 $.
$d x y z w x0 x1 x2 x3 s0 s1 s2 s3 kore-sort-var-R kore-element-var-VE0 kore-element-var-VE1 kore-element-var-VE2 kore-element-var-VE4 kore-element-var-VE3 kore-element-var-V0 kore-element-var-V1 kore-element-var-V2 kore-sort-var-To kore-sort-var-From kore-sort-var-SortSort kore-element-var-Val kore-element-var-From kore-element-var-K0 kore-element-var-K1 kore-element-var-K2 kore-element-var-K3 kore-element-var-K kore-sort-var-Q0 kore-sort-var-x0 kore-element-var-x1 kore-element-var-VE5 kore-element-var-VE6 kore-element-var-VE15 kore-element-var-VE11 kore-element-var-VE29 kore-element-var-VE25 kore-element-var-VE16 kore-element-var-VE17 kore-element-var-VE7 kore-element-var-VE18 kore-element-var-VE21 kore-element-var-VE19 kore-element-var-VE30 kore-element-var-VE27 kore-element-var-VE24 kore-element-var-VE31 kore-element-var-VE23 kore-element-var-VE8 kore-element-var-VE32 kore-element-var-VE35 kore-element-var-VE10 kore-element-var-VE28 kore-element-var-VE12 kore-element-var-VE34 kore-element-var-VE20 kore-element-var-VE13 kore-element-var-VE33 kore-element-var-VE14 kore-element-var-VE22 kore-element-var-VE9 kore-element-var-VE26 kore-sort-var-S3 kore-sort-var-S2 kore-sort-var-S1 kore-element-var-T kore-element-var-x0 kore-element-var-x2 kore-sort-var-x1 $.
